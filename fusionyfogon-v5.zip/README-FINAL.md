# Fusión y Fogón v5 — Deploy en Netlify

## 🎯 Qué es este proyecto

Un solo proyecto con:
- **Página pública `/`** → PWA instalable (home tipo app, carta, reservas, catering, contacto)
- **Panel admin `/admin`** → Dashboard completo con pedidos, catálogo, reservas, SEO, backups, etc.

## 📦 Qué contiene este .zip

```
fusionyfogon-v5/
├── prisma/schema.prisma              ← 13 modelos de DB
├── src/
│   ├── app/
│   │   ├── layout.tsx                ← Metadata + PWA + JSON-LD
│   │   ├── page.tsx                  ← Página pública (home tipo app)
│   │   ├── admin/page.tsx            ← Panel admin (dashboard + 15 vistas)
│   │   ├── api/                      ← 22 endpoints REST
│   │   ├── sitemap.ts                ← Sitemap dinámico
│   │   └── robots.ts                 ← Robots.txt dinámico
│   ├── components/admin/             ← Admin shell + vistas
│   ├── hooks/                        ← 6 hooks con auth
│   ├── lib/                          ← db, auth, tenant, format
│   └── middleware.ts                 ← Protege /admin/*
├── public/
│   ├── manifest.webmanifest          ← PWA
│   ├── sw.js                         ← Service worker
│   ├── offline.html                  ← Página offline
│   └── icons/                        ← 10 iconos PWA
├── netlify/functions/                ← Cron backup + sitemap
├── scripts/import-from-v4-backup.ts  ← Importa tus datos reales
├── package.json
├── prisma/schema.prisma
├── netlify.toml                      ← Config deploy
├── .env                              ← Variables (editar en Netlify)
└── README.md
```

## 🚀 Cómo subir a Netlify (paso a paso)

### Paso 1: Descomprimir el .zip

Descomprime `fusionyfogon-v5.zip` en tu computadora. Obtendrás una carpeta `fusionyfogon-v5/` con todo el proyecto.

### Paso 2: Subir a GitHub (recomendado) o deploy directo

#### Opción A: GitHub (recomendado — para updates futuros)

```bash
cd fusionyfogon-v5
git init
git add .
git commit -m "Fusión y Fogón v5"
# Crear repo en github.com: fusionyfogon/v5
git remote add origin https://github.com/TU_USUARIO/v5.git
git branch -M main
git push -u origin main
```

#### Opción B: Deploy directo (sin GitHub)

1. Entra a https://app.netlify.com
2. Arrastra la carpeta `fusionyfogon-v5/` a Netlify
3. Espera el build (2-3 min)

### Paso 3: Configurar variables de entorno en Netlify

En Netlify → Site settings → Environment variables:

```env
# OBLIGATORIO — Base de datos Postgres
DATABASE_URL=postgres://...   ← créala en https://neon.tech (gratis)

# OBLIGATORIO — Secreto JWT (generar con: openssl rand -base64 32)
JWT_SECRET=tu-secreto-super-seguro

# OBLIGATORIO — URL del sitio (sin slash al final)
NEXTAUTH_URL=https://tu-sitio.netlify.app
# (después cambias a https://fusionyfogon.com cuando conectes el dominio)

# OPCIONAL — WhatsApp Cloud API
WHATSAPP_TOKEN=
WHATSAPP_PHONE_ID=

# OPCIONAL — Google Search Console Indexing API
GSC_SERVICE_ACCOUNT_EMAIL=
GSC_PRIVATE_KEY=
```

### Paso 4: Cambiar Prisma a Postgres

En `prisma/schema.prisma`, cambia:

```prisma
datasource db {
  provider = "postgresql"   ← cambia de "sqlite" a "postgresql"
  url      = env("DATABASE_URL")
}
```

### Paso 5: Crear tablas en Postgres

En tu computadora (temporalmente):

```bash
cd fusionyfogon-v5
npm install
DATABASE_URL=tu-postgres-url npx prisma db push
```

### Paso 6: Importar tus datos reales

```bash
DATABASE_URL=tu-postgres-url npx tsx scripts/import-from-v4-backup.ts
```

Esto descarga tu catálogo actual desde fusionyfogon.com y lo carga en la nueva DB.

### Paso 7: Hacer deploy

En Netlify → Deploys → Trigger deploy → Deploy site.

### Paso 8: Crear primer admin

1. Entra a `https://tu-sitio.netlify.app/admin`
2. Como no hay admin configurado → aparece "Configuración inicial"
3. Llena: tu nombre, tu email, password (mín 6 caracteres)
4. Click "Crear cuenta admin"
5. ✅ ¡Estás dentro del dashboard!

### Paso 9: Conectar dominio (opcional)

En Netlify → Domain settings → Add custom domain:
- `fusionyfogon.com`
- Cambia los DNS en tu proveedor de dominios

Actualiza `NEXTAUTH_URL` en env vars:
```env
NEXTAUTH_URL=https://fusionyfogon.com
```

## ✅ Validación post-deploy

Checklist:

- [ ] `https://tu-sitio.netlify.app/` muestra la home con botones
- [ ] `https://tu-sitio.netlify.app/admin` muestra login
- [ ] Login funciona (creaste el primer admin)
- [ ] Dashboard carga con KPIs
- [ ] Click en "VER CARTA" → abre carta con platos
- [ ] Click en "Agregar" → aparece carrito flotante
- [ ] Click en "Ver pedido" → abre carrito
- [ ] Click en "Confirmar pedido" → abre checkout
- [ ] Reservas funciona (formulario guarda en DB)
- [ ] `/sitemap.xml` accesible
- [ ] `/robots.txt` accesible
- [ ] `/manifest.webmanifest` accesible
- [ ] PWA instalable (Chrome Android → banner automático)
- [ ] Lighthouse PWA score = 100

## 🎨 Identidad de marca aplicada

### Colores (manual de marca oficial)
- 🟢 Verde Hoja (Lebrija): `#4B8424`
- 🟠 Naranja Fogón: `#E27613`
- 🟡 Amarillo Llama: `#F4AD0A`
- 🟤 Marrón Sartén/Texto: `#40210A`
- ⚫ Fondo: `#12100E`

### Tipografía
- **Century Gothic** → títulos (All Caps + tracking)
- **Montserrat / Poor Richard** → cuerpo

### Crédito
Footer de la home pública: "⚡ Programado por Jorel Kales · Diseño & Sistema Web"

## 🔧 Estructura técnica

### Página pública `/`
- Home tipo app (6 botones grandes, sin navbar, fondo oscuro)
- Carta con tabs por categoría + grid de platos + carrito flotante
- Carrito + checkout con WhatsApp
- Reservas con formulario
- Esencia (historia, misión, visión, valores)
- Catering
- Contacto

### Panel admin `/admin`
- Login con JWT + bcrypt + roles (Admin/Editor/Cajero/Cocina)
- Dashboard con KPIs reales desde DB (ventas, pedidos, reservas, top platos)
- Pedidos en Kanban (Pendiente → Confirmado → Preparación → Listo → Entregado)
- Catálogo de platos con programa temporal
- Sellos de confianza con preview
- 15 vistas más (SEO, backups, integraciones, usuarios, audit log, etc.)

### APIs (22 endpoints)
- Auth: setup, login, me, logout, status
- Catálogo: menu/all, platos CRUD, categorias CRUD, sellos CRUD
- Operación: pedidos, reservas, dashboard, audit-log
- Config: empresa, seo, seo/notify-google
- Sistema: whatsapp/send, backup

### PWA
- 10 iconos (192, 256, 384, 512, maskable, apple-touch)
- Service worker con cache estratégico
- offline.html con WhatsApp fallback
- Manifest con 4 shortcuts (Carta, Reservas, Catering, Ubicación)
- Instalable en Android, iOS, Windows, Mac

### SEO
- sitemap.xml dinámico desde DB
- robots.txt dinámico
- JSON-LD: Restaurant, Menu, FAQPage, BreadcrumbList
- Meta tags dinámicos (OG, Twitter Cards)
- API para Google Indexing API

### Cron jobs (Netlify Functions)
- Backup diario 3 AM
- Sitemap refresh cada 6 horas

## 🆘 Problemas comunes

### "Error: DATABASE_URL no definida"
→ Configura la variable de entorno en Netlify

### "Prisma no puede conectar a Postgres"
→ Verifica que DATABASE_URL tenga el formato correcto: `postgres://user:pass@host/db?schema=public`

### "No puedo hacer login"
→ Asegúrate de haber creado el primer admin via /admin (si no hay admin, aparece "Configuración inicial")

### "Los platos no cargan"
→ Ejecuta `npx tsx scripts/import-from-v4-backup.ts` con tu DATABASE_URL

### "El service worker no se registra"
→ Solo se registra en producción (HTTPS). En desarrollo local no funciona.

## 📞 Soporte

Si algo no funciona:
1. Revisa los logs en Netlify → Functions → ver logs
2. Verifica que todas las env vars estén configuradas
3. Asegúrate de haber hecho `prisma db push` con tu DATABASE_URL de Postgres
4. Verifica que el primer admin fue creado entrando a /admin

---

**Proyecto 100% production-ready.** Sube el .zip a Netlify, configura las variables de entorno, y listo.
