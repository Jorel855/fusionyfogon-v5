import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  reactStrictMode: false,
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  // Compresión
  compress: true,
  // Powered By header (seguridad — no revelar versión)
  poweredByHeader: false,
  // Optimización de imágenes
  images: {
    formats: ["image/avif", "image/webp"],
    remotePatterns: [
      { protocol: "https", hostname: "images.unsplash.com" },
      { protocol: "https", hostname: "fusionyfogon.com" },
    ],
    minimumCacheTTL: 86400,
  },
  // Headers para CSP y seguridad
  async headers() {
    return [
      {
        source: "/sw.js",
        headers: [
          { key: "Cache-Control", value: "no-cache, no-store, must-revalidate" },
          { key: "Service-Worker-Allowed", value: "/" },
        ],
      },
      {
        source: "/manifest.webmanifest",
        headers: [
          { key: "Content-Type", value: "application/manifest+json" },
          { key: "Cache-Control", value: "public, max-age=3600" },
        ],
      },
    ];
  },
  // Redirects para URLs amigables
  async redirects() {
    return [
      { source: "/menu", destination: "/#carta", permanent: true },
      { source: "/reserva", destination: "/#reservas", permanent: true },
      { source: "/ubicacion", destination: "/#contacto", permanent: true },
      { source: "/whatsapp", destination: "https://wa.me/573508029292", permanent: true },
    ];
  },
};

export default nextConfig;
