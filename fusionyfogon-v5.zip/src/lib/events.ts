// Sistema de eventos en memoria para sincronización en tiempo real
// entre el panel admin y la web pública (Server-Sent Events)

type EventListener = (data: any) => void

class EventBus {
  private listeners: Map<string, Set<EventListener>> = new Map()

  subscribe(channel: string, listener: EventListener): () => void {
    if (!this.listeners.has(channel)) {
      this.listeners.set(channel, new Set())
    }
    this.listeners.get(channel)!.add(listener)
    return () => {
      this.listeners.get(channel)?.delete(listener)
    }
  }

  publish(channel: string, data: any): void {
    const channelListeners = this.listeners.get(channel)
    if (channelListeners) {
      channelListeners.forEach((listener) => {
        try {
          listener(data)
        } catch (e) {
          console.error('[EventBus] Error en listener:', e)
        }
      })
    }
    // También publica en canal global
    const globalListeners = this.listeners.get('*')
    if (globalListeners) {
      globalListeners.forEach((listener) => {
        try {
          listener({ channel, ...data })
        } catch (e) {
          console.error('[EventBus] Error en global listener:', e)
        }
      })
    }
  }
}

// Singleton — en serverless cada instancia tiene su propio bus,
// pero dentro de la misma función funciona perfecto
const globalForBus = globalThis as unknown as { eventBus: EventBus | undefined }
export const eventBus = globalForBus.eventBus ?? new EventBus()
if (process.env.NODE_ENV !== 'production') globalForBus.eventBus = eventBus

// Helpers para canales específicos
export const channels = {
  menuUpdated: 'menu:updated',       // cuando se edita/oculta/crea un plato
  sellosUpdated: 'sellos:updated',   // cuando se editan sellos
  pedidoCreated: 'pedido:created',   // cuando llega un pedido nuevo
  pedidoUpdated: 'pedido:updated',   // cuando cambia estado de pedido
  reservaCreated: 'reserva:created', // cuando llega una reserva nueva
  empresaUpdated: 'empresa:updated', // cuando se edita la config del negocio
}

export function emitMenuUpdated(tenantId: string, platoId?: string) {
  eventBus.publish(channels.menuUpdated, { tenantId, platoId, timestamp: Date.now() })
}

export function emitSellosUpdated(tenantId: string) {
  eventBus.publish(channels.sellosUpdated, { tenantId, timestamp: Date.now() })
}

export function emitPedidoCreated(tenantId: string, pedidoId: string) {
  eventBus.publish(channels.pedidoCreated, { tenantId, pedidoId, timestamp: Date.now() })
}

export function emitPedidoUpdated(tenantId: string, pedidoId: string, estado: string) {
  eventBus.publish(channels.pedidoUpdated, { tenantId, pedidoId, estado, timestamp: Date.now() })
}

export function emitReservaCreated(tenantId: string, reservaId: string) {
  eventBus.publish(channels.reservaCreated, { tenantId, reservaId, timestamp: Date.now() })
}

export function emitEmpresaUpdated(tenantId: string) {
  eventBus.publish(channels.empresaUpdated, { tenantId, timestamp: Date.now() })
}
