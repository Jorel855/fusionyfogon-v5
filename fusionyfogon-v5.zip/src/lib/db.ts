import { PrismaClient } from '@prisma/client'

// En desarrollo, siempre crear nueva instancia para evitar caché de schema viejo
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// Forzar regeneración del cliente si cambió el schema
const forceNew = process.env.NODE_ENV !== 'production' && process.env.FORCE_PRISMA_REFRESH

export const db =
  forceNew || !globalForPrisma.prisma
    ? new PrismaClient({
        log: process.env.NODE_ENV !== 'production' ? ['error', 'warn'] : ['error'],
      })
    : globalForPrisma.prisma

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db