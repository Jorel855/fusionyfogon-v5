import jwt from 'jsonwebtoken'
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-in-production'

export type Rol = 'Admin' | 'Editor' | 'Cajero' | 'Cocina'

export type AuthUser = {
  id: string
  email: string
  nombre: string
  rol: Rol
  tenantId: string
}

// Permisos por rol — qué puede hacer cada uno
const PERMISOS: Record<Rol, string[]> = {
  Admin: ['*'], // acceso total
  Editor: ['pedidos:read', 'pedidos:write', 'reservas:read', 'reservas:write', 'platos:read', 'platos:write', 'categorias:read', 'categorias:write', 'sellos:read', 'sellos:write', 'empresa:read', 'content:*'],
  Cajero: ['pedidos:read', 'pedidos:write', 'reservas:read', 'reservas:write'],
  Cocina: ['pedidos:read'],
}

export function hasPermission(rol: Rol, permission: string): boolean {
  const perms = PERMISOS[rol] || []
  if (perms.includes('*')) return true
  if (perms.includes('content:*') && permission.startsWith('content:')) return true
  return perms.includes(permission)
}

// Crea un JWT para un usuario
export function signToken(user: AuthUser): string {
  return jwt.sign(
    {
      sub: user.id,
      email: user.email,
      nombre: user.nombre,
      rol: user.rol,
      tenantId: user.tenantId,
    },
    JWT_SECRET,
    { expiresIn: '7d' }
  )
}

// Verifica un JWT y devuelve el usuario
export function verifyToken(token: string): AuthUser | null {
  try {
    const payload = jwt.verify(token, JWT_SECRET) as any
    return {
      id: payload.sub,
      email: payload.email,
      nombre: payload.nombre,
      rol: payload.rol as Rol,
      tenantId: payload.tenantId,
    }
  } catch {
    return null
  }
}

// Extrae el token del header Authorization: Bearer xxx
export function getTokenFromRequest(req: NextRequest): string | null {
  const auth = req.headers.get('authorization')
  if (!auth) return null
  if (!auth.startsWith('Bearer ')) return null
  return auth.slice(7)
}

// Helper para proteger APIs — usage:
//   const user = await requireRole(req, 'platos:write')
//   if (!user) return NextResponse.json({ ok: false, error: 'No autorizado' }, { status: 401 })
export async function requireRole(
  req: NextRequest,
  permission: string
): Promise<AuthUser | NextResponse> {
  const token = getTokenFromRequest(req)
  if (!token) {
    return NextResponse.json(
      { ok: false, error: 'No autenticado', code: 'NO_TOKEN' },
      { status: 401 }
    )
  }

  const user = verifyToken(token)
  if (!user) {
    return NextResponse.json(
      { ok: false, error: 'Token inválido', code: 'INVALID_TOKEN' },
      { status: 401 }
    )
  }

  if (!hasPermission(user.rol, permission)) {
    return NextResponse.json(
      { ok: false, error: 'Sin permisos suficientes', code: 'FORBIDDEN', required: permission, rol: user.rol },
      { status: 403 }
    )
  }

  // Actualiza ultimoAcceso (no esperamos — fire and forget)
  db.usuario
    .update({
      where: { id: user.id },
      data: { ultimoAcceso: new Date() },
    })
    .catch(() => {})

  return user
}

// Verifica si ya existe algún usuario admin (para saber si hay que hacer setup)
export async function hasAdminUser(): Promise<boolean> {
  const tenant = await ensureTenant()
  const count = await db.usuario.count({
    where: { tenantId: tenant.id, rol: 'Admin', activo: true },
  })
  return count > 0
}
