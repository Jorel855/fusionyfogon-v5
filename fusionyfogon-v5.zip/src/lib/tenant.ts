import { db } from '@/lib/db'

// Default tenant for Fusión y Fogón (single-tenant demo, ready for multi-tenant)
export const DEFAULT_TENANT_SLUG = 'fyf'

export async function getTenant(slug: string = DEFAULT_TENANT_SLUG) {
  return db.tenant.findUnique({
    where: { slug },
    include: { empresa: true },
  })
}

export async function ensureTenant(slug: string = DEFAULT_TENANT_SLUG) {
  let tenant = await db.tenant.findUnique({ where: { slug } })
  if (!tenant) {
    tenant = await db.tenant.create({
      data: {
        slug,
        nombre: 'Fusión y Fogón',
        rubro: 'restaurante',
        plan: 'pro',
        empresa: {
          create: {
            nombre: 'FUSIÓN Y FOGÓN',
            tagline: 'Sabores que unen culturas',
            telefono: '+57 350 802 9292',
            whatsapp: '+57 350 802 9292',
            email: 'contacto@fusionyfogon.com',
            direccion: 'Finca El Jazmín, Vereda Puyana, Lebrija - Santander',
            horarios: 'Jueves a Domingo y Festivos: 11:30 AM - 8:30 PM',
            dominioPrincipal: 'fusionyfogon.com',
            seoTitle: 'FUSIÓN Y FOGÓN | Ahumados & Experiencias. Lebrija, Santander',
            seoDescription:
              'Restaurante y charcutería artesanal en Lebrija, Santander. Ahumados a la leña de guayabo, costillares al barril, cóctel tropical y catering campestre. Pedidos por WhatsApp.',
            seoKeyword: 'ahumados lebrija',
          },
        },
      },
      include: { empresa: true },
    })
  }
  return tenant
}

// Format COP currency
export function formatCOP(cents: number): string {
  return new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    maximumFractionDigits: 0,
  }).format(cents / 100)
}

// Generate short order code (1023, 1024, ...)
export async function nextCodigo(tenantId: string, entidad: 'Pedido' | 'Reserva'): Promise<string> {
  const count = await (db[entidad.toLowerCase() as 'pedido' | 'reserva'] as any).count({
    where: { tenantId },
  })
  return String(1023 + count) // starts at 1023 for demo realism
}
