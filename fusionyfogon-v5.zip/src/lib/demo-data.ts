// Mock data inspired by the real Fusión y Fogón API response

export type Pedido = {
  id: string;
  cliente: string;
  telefono: string;
  direccion: string;
  detalle: string;
  total: number;
  estado: 'Pendiente' | 'Confirmado' | 'Preparacion' | 'Listo' | 'Entregado';
  fecha: string;
};

export type Reserva = {
  id: string;
  fecha: string; // ISO
  hora: string;
  personas: number;
  nombre: string;
  celular: string;
  estado: 'Pendiente' | 'Confirmada' | 'Cancelada';
};

export type Plato = {
  id: number;
  nombre: string;
  precio: number;
  categoria: string;
  badge?: string;
  descripcion: string;
  visible: boolean;
  imagen?: string;
  ventas: number;
  programa?: {
    activo: boolean;
    desde?: string;
    hasta?: string;
  };
};

export const PLATOS: Plato[] = [
  { id: 1, nombre: 'Lomo de cerdo Ahumado al Barril', precio: 21000, categoria: 'ahumados', badge: 'Especialidad', descripcion: '300g al vacío empacados', visible: true, ventas: 47 },
  { id: 2, nombre: 'Panceta Ultra-Crocante', precio: 34000, categoria: 'ahumados', badge: 'Más Pedido', descripcion: 'Cocción lenta con piel tostada crujiente y toque de sal marina.', visible: false, ventas: 12 },
  { id: 3, nombre: 'Chorizo Ahumado Artesanal (5 Unid)', precio: 14000, categoria: 'embutidos', badge: '100% Cerdo', descripcion: 'Elaboración propia con hierbas frescas y humo de madera nativa.', visible: true, ventas: 28 },
  { id: 4, nombre: 'Bondiola Braseada al Fogón', precio: 32000, categoria: 'cortes', descripcion: 'Cocción lenta 8h al fogón.', visible: false, ventas: 5 },
  { id: 5, nombre: 'Bebida Cítrica de la Huerta', precio: 7000, categoria: 'bebidas', descripcion: 'Limonada con hierbas frescas.', visible: false, ventas: 19 },
];

export const PEDIDOS: Pedido[] = [
  { id: '1791559191349v2s5', cliente: 'Jorel Kales', telefono: '+57 350 802 9292', direccion: 'Finca El Jazmín, Vereda Puyana', detalle: '1x Lomo de cerdo Ahumado al Barril', total: 21000, estado: 'Pendiente', fecha: '9/10/2026, 15:19:51' },
  { id: '1791559832410a8k3', cliente: 'María Camacho', telefono: '+57 311 555 1234', direccion: 'Calle 45 # 23-18, Bucaramanga', detalle: '2x Chorizo Artesanal · 1x Panceta', total: 62000, estado: 'Pendiente', fecha: '9/10/2026, 16:42:08' },
  { id: '1791559999812c5w7', cliente: 'Andrés Torres', telefono: '+57 320 888 4567', direccion: 'Cabecera del llano, Floridablanca', detalle: '1x Bondiola · 2x Bebida Cítrica', total: 46000, estado: 'Confirmado', fecha: '9/10/2026, 17:05:22' },
  { id: '1791560387124h1y9', cliente: 'Laura Gómez', telefono: '+57 314 222 7890', direccion: 'Provenza, Bucaramanga', detalle: '3x Lomo de cerdo Ahumado', total: 63000, estado: 'Preparacion', fecha: '9/10/2026, 17:48:11' },
  { id: '1791560723489p6z2', cliente: 'Carlos Méndez', telefono: '+57 301 999 3344', direccion: 'Recogida en finca', detalle: '1x Chorizo Artesanal', total: 14000, estado: 'Listo', fecha: '9/10/2026, 18:12:45' },
  { id: '1791560987654q4r5', cliente: 'Sofía R.', telefono: '+57 318 444 5566', direccion: 'Girón centro', detalle: '2x Lomo de cerdo · 1x Panceta', total: 76000, estado: 'Entregado', fecha: '8/10/2026, 20:15:30' },
];

export const RESERVAS: Reserva[] = [
  { id: 'r1', fecha: '2026-10-12', hora: '13:00', personas: 4, nombre: 'Familia Martínez', celular: '+57 311 555 0011', estado: 'Confirmada' },
  { id: 'r2', fecha: '2026-10-12', hora: '20:00', personas: 2, nombre: 'Pareja López', celular: '+57 320 888 2233', estado: 'Pendiente' },
  { id: 'r3', fecha: '2026-10-15', hora: '19:30', personas: 8, nombre: 'Cumpleaños Andrea', celular: '+57 314 222 4455', estado: 'Pendiente' },
  { id: 'r4', fecha: '2026-10-19', hora: '12:30', personas: 6, nombre: 'Grupo Camacho', celular: '+57 301 999 7788', estado: 'Confirmada' },
];

export const VENTAS_30_DIAS = Array.from({ length: 30 }, (_, i) => {
  const base = 180000 + Math.sin(i / 3) * 80000;
  const weekend = (i % 7 === 5 || i % 7 === 6) ? 120000 : 0;
  const noise = (Math.random() - 0.5) * 40000;
  const total = Math.max(0, Math.round(base + weekend + noise));
  return {
    dia: i + 1,
    fecha: `2026-09-${String(i + 1).padStart(2, '0')}`,
    total,
  };
});

// Heatmap: día (L-D) x hora
export const HORAS_PICO = {
  horas: ['12p', '1p', '2p', '6p', '7p', '8p'],
  dias: ['L', 'M', 'X', 'J', 'V', 'S', 'D'],
  // valores 0-4 (intensidad)
  data: [
    [1, 1, 1, 2, 3, 4, 4], // 12p
    [1, 1, 2, 3, 3, 4, 4], // 1p
    [0, 0, 1, 1, 2, 3, 3], // 2p
    [0, 0, 0, 1, 3, 4, 4], // 6p
    [0, 0, 0, 1, 3, 4, 4], // 7p
    [0, 0, 0, 1, 2, 3, 3], // 8p
  ],
};

export const TENANTS = [
  { id: 'fyf', nombre: 'Fusión y Fogón', rubro: 'Ahumadería · Lebrija', color: '#CC6600', plan: 'Pro' },
  { id: 'pizzeria', nombre: 'Don Luigi', rubro: 'Pizzería · Bucaramanga', color: '#DC2626', plan: 'Pro' },
  { id: 'cafe', nombre: 'Café Altura', rubro: 'Cafetería · Floridablanca', color: '#92400E', plan: 'Starter' },
  { id: 'nuevo', nombre: '+ Crear nuevo negocio', rubro: 'Plantilla en blanco', color: '#6B7280', plan: '', isCreate: true },
];

export const formatCOP = (n: number) =>
  new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(n);
