'use client';

import { useState } from 'react';
import { ChevronLeft, ChevronRight, Ban, Check, Download } from 'lucide-react';
import { RESERVAS } from '@/lib/demo-data';

const DIAS_SEMANA = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
const MESES = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

export function ReservasView() {
  const [mes, setMes] = useState(9); // Octubre (0-indexed)
  const [anio, setAnio] = useState(2026);

  const primerDia = new Date(anio, mes, 1).getDay();
  const diasEnMes = new Date(anio, mes + 1, 0).getDate();

  const celdas: (number | null)[] = [
    ...Array(primerDia).fill(null),
    ...Array.from({ length: diasEnMes }, (_, i) => i + 1),
  ];
  while (celdas.length % 7 !== 0) celdas.push(null);

  const reservasPorDia = (dia: number) => {
    const fechaStr = `${anio}-${String(mes + 1).padStart(2, '0')}-${String(dia).padStart(2, '0')}`;
    return RESERVAS.filter((r) => r.fecha === fechaStr);
  };

  const hoy = 9; // simulamos que hoy es 9 de octubre
  const proximasReservas = [...RESERVAS].sort((a, b) => a.fecha.localeCompare(b.fecha));

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Reservas</h1>
          <p className="text-sm text-muted-foreground mt-1">{RESERVAS.length} reservas en el mes</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="surface-2 text-xs px-3 py-2 rounded-lg hover:border-primary/30 flex items-center gap-1.5">
            <Ban className="w-3.5 h-3.5" /> Bloquear fecha
          </button>
          <button className="surface-2 p-2 rounded-lg hover:border-primary/30" title="Exportar CSV">
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        {/* Calendar */}
        <div className="surface rounded-xl p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">
              {MESES[mes]} {anio}
            </h2>
            <div className="flex items-center gap-1">
              <button
                onClick={() => {
                  if (mes === 0) {
                    setMes(11);
                    setAnio(anio - 1);
                  } else setMes(mes - 1);
                }}
                className="surface-2 p-1.5 rounded-md hover:border-primary/30"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  setMes(9);
                  setAnio(2026);
                }}
                className="text-xs px-3 py-1.5 surface-2 rounded-md hover:border-primary/30"
              >
                Hoy
              </button>
              <button
                onClick={() => {
                  if (mes === 11) {
                    setMes(0);
                    setAnio(anio + 1);
                  } else setMes(mes + 1);
                }}
                className="surface-2 p-1.5 rounded-md hover:border-primary/30"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-1 mb-2">
            {DIAS_SEMANA.map((d) => (
              <div key={d} className="text-center text-[10px] uppercase text-muted-foreground font-semibold py-1">
                {d}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {celdas.map((dia, i) => {
              if (dia === null) return <div key={i} />;
              const reservas = reservasPorDia(dia);
              const esHoy = dia === hoy && mes === 9;
              return (
                <div
                  key={i}
                  className={`min-h-[68px] p-1.5 rounded-lg surface-2 transition-colors ${
                    esHoy ? 'ring-2 ring-primary' : ''
                  } ${reservas.length > 0 ? 'cursor-pointer hover:border-primary/30' : ''}`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className={`text-xs font-medium ${esHoy ? 'text-primary' : 'text-foreground'}`}>
                      {dia}
                    </span>
                    {reservas.length > 0 && (
                      <span className="text-[9px] bg-primary/15 text-primary px-1 rounded-full font-bold">
                        {reservas.length}
                      </span>
                    )}
                  </div>
                  <div className="space-y-0.5">
                    {reservas.slice(0, 2).map((r) => (
                      <div
                        key={r.id}
                        className={`text-[9px] px-1 py-0.5 rounded truncate ${
                          r.estado === 'Confirmada'
                            ? 'bg-emerald-500/15 text-emerald-400'
                            : 'bg-amber-500/15 text-amber-400'
                        }`}
                      >
                        {r.hora} · {r.nombre.split(' ')[0]}
                      </div>
                    ))}
                    {reservas.length > 2 && (
                      <div className="text-[9px] text-muted-foreground px-1">+{reservas.length - 2} más</div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-4 flex items-center gap-4 text-[10px] text-muted-foreground">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500" /> Confirmada
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-amber-500" /> Pendiente
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-red-500" /> Bloqueada
            </span>
          </div>
        </div>

        {/* Lista próximas reservas */}
        <div className="surface rounded-xl p-5">
          <h2 className="text-sm font-semibold mb-3">Próximas reservas</h2>
          <div className="space-y-2 max-h-[480px] overflow-y-auto">
            {proximasReservas.map((r) => (
              <div key={r.id} className="surface-2 rounded-lg p-3">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="text-sm font-medium">{r.nombre}</p>
                    <p className="text-[10px] text-muted-foreground">
                      {r.personas} personas · {r.hora}
                    </p>
                  </div>
                  <span
                    className={`text-[9px] px-2 py-0.5 rounded-full font-medium ${
                      r.estado === 'Confirmada'
                        ? 'bg-emerald-500/15 text-emerald-400'
                        : 'bg-amber-500/15 text-amber-400'
                    }`}
                  >
                    {r.estado}
                  </span>
                </div>
                <p className="text-[10px] text-muted-foreground mb-2">
                  📅 {new Date(r.fecha + 'T00:00').toLocaleDateString('es-CO', { weekday: 'long', day: 'numeric', month: 'short' })}
                </p>
                <p className="text-[10px] text-muted-foreground mb-2">📞 {r.celular}</p>
                {r.estado === 'Pendiente' && (
                  <div className="flex gap-1">
                    <button className="flex-1 bg-emerald-500/15 text-emerald-400 text-[10px] py-1 rounded-md hover:bg-emerald-500 hover:text-white flex items-center justify-center gap-1">
                      <Check className="w-3 h-3" /> Confirmar
                    </button>
                    <button className="surface px-2 text-[10px] py-1 rounded-md hover:text-red-400 flex items-center gap-1">
                      <Ban className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Configuración */}
      <div className="surface rounded-xl p-5">
        <h2 className="text-sm font-semibold mb-3">Configuración de reservas</h2>
        <div className="grid sm:grid-cols-3 gap-3">
          <label className="block">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Máximo personas</span>
            <input
              type="number"
              defaultValue={12}
              className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
            />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Antelación mínima</span>
            <input
              type="text"
              defaultValue="2 horas"
              className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
            />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Título del modal</span>
            <input
              type="text"
              defaultValue="Reserva tu mesa en Fusión y Fogón"
              className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
            />
          </label>
        </div>
        <button className="mt-3 bg-primary text-primary-foreground text-xs font-medium px-4 py-2 rounded-lg hover:opacity-90">
          Guardar configuración
        </button>
      </div>
    </div>
  );
}
