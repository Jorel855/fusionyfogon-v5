'use client';

import { useState } from 'react';
import { Plus, Eye, EyeOff, Edit, Trash2, MoreVertical, Calendar, X, Check, AlertCircle, Loader2 } from 'lucide-react';
import { usePlatos, type Plato } from '@/hooks/use-platos';
import { formatCOP } from '@/lib/format';

const CATEGORIAS = [
  { id: 'ahumados', nombre: 'Ahumados', icono: '🥩' },
  { id: 'embutidos', nombre: 'Chorizos', icono: '🌭' },
  { id: 'cortes', nombre: 'Cortes', icono: '🔥' },
  { id: 'bebidas', nombre: 'Bebidas', icono: '🥤' },
];

type Programa = {
  activo: boolean;
  desde?: string;
  hasta?: string;
};

export function CatalogoView() {
  const { platos, loading, error, toggleVisible, actualizarPrograma, refetch } = usePlatos();
  const [scheduling, setScheduling] = useState<Plato | null>(null);

  const guardarPrograma = async (id: string, programa: Programa) => {
    await actualizarPrograma(id, programa);
    setScheduling(null);
  };

  const visiblesCount = platos.filter((p) => p.visible).length;

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 text-primary animate-spin" />
        <span className="ml-2 text-sm text-muted-foreground">Cargando platos desde DB...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="surface rounded-xl p-6 text-center">
        <p className="text-sm text-red-400 mb-3">Error: {error}</p>
        <button onClick={refetch} className="bg-primary text-primary-foreground text-sm px-4 py-2 rounded-lg">
          Reintentar
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Platos</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {platos.length} platos · {visiblesCount} visibles · {platos.length - visiblesCount} ocultos ·{' '}
            <span className="text-emerald-400">● datos en vivo</span>
          </p>
        </div>
        <button className="bg-primary text-primary-foreground text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90 flex items-center gap-2">
          <Plus className="w-4 h-4" /> Nuevo plato
        </button>
      </div>

      {/* Categorías chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <button className="surface-2 text-xs px-3 py-1.5 rounded-full border border-primary/30 text-primary font-medium whitespace-nowrap">
          Todos ({platos.length})
        </button>
        {CATEGORIAS.map((c) => {
          const count = platos.filter((p) => p.categoria?.slug === c.id).length;
          return (
            <button
              key={c.id}
              className="surface-2 text-xs px-3 py-1.5 rounded-full hover:border-primary/30 whitespace-nowrap flex items-center gap-1.5"
            >
              <span>{c.icono}</span>
              <span>{c.nombre}</span>
              <span className="text-muted-foreground">({count})</span>
            </button>
          );
        })}
      </div>

      {/* Grid de platos */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {platos.map((p) => (
          <div key={p.id} className="surface rounded-xl overflow-hidden group">
            <div className="aspect-[4/3] brand-gradient relative overflow-hidden">
              <div className="absolute inset-0 flex items-center justify-center text-6xl opacity-50">
                {p.categoria?.icono || '🍽️'}
              </div>
              {p.badge && (
                <span className="absolute top-2 left-2 bg-black/70 backdrop-blur text-[10px] font-bold px-2 py-1 rounded-full text-white">
                  {p.badge}
                </span>
              )}
              {!p.visible && (
                <div className="absolute inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center">
                  <div className="text-center">
                    <EyeOff className="w-6 h-6 text-white mx-auto mb-1" />
                    <span className="text-xs text-white font-medium">Oculto</span>
                  </div>
                </div>
              )}
              {p.programa?.activo && (
                <span className="absolute bottom-2 left-2 bg-blue-500/80 backdrop-blur text-[10px] font-bold px-2 py-1 rounded-full text-white flex items-center gap-1">
                  <Calendar className="w-2.5 h-2.5" /> Programado
                </span>
              )}
            </div>

            <div className="p-3">
              <div className="flex items-start justify-between gap-2 mb-1">
                <h3 className="text-sm font-medium leading-tight line-clamp-2">{p.nombre}</h3>
                <button className="text-muted-foreground hover:text-foreground">
                  <MoreVertical className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="text-[11px] text-muted-foreground line-clamp-2 mb-2">{p.descripcion}</p>
              <div className="flex items-center justify-between mb-2">
                <span className="text-base font-bold text-primary">{formatCOP(p.precio * 100)}</span>
                <span className="text-[10px] text-muted-foreground">{p.ventas} ventas</span>
              </div>

              <div className="grid grid-cols-4 gap-1 pt-2 border-t border-border">
                <button
                  className="surface-2 p-1.5 rounded-md hover:text-primary flex items-center justify-center"
                  title="Editar"
                >
                  <Edit className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => toggleVisible(p.id, !p.visible)}
                  className={`p-1.5 rounded-md flex items-center justify-center transition-colors ${
                    p.visible ? 'surface-2 hover:text-primary' : 'bg-amber-500/15 text-amber-400'
                  }`}
                  title={p.visible ? 'Ocultar' : 'Mostrar'}
                >
                  {p.visible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => setScheduling(p)}
                  className={`p-1.5 rounded-md flex items-center justify-center transition-colors ${
                    p.programa?.activo ? 'bg-blue-500/15 text-blue-400' : 'surface-2 hover:text-primary'
                  }`}
                  title="Programar visibilidad"
                >
                  <Calendar className="w-3.5 h-3.5" />
                </button>
                <button
                  className="surface-2 p-1.5 rounded-md hover:text-red-400 flex items-center justify-center"
                  title="Eliminar"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}

        <button className="surface rounded-xl border-2 border-dashed border-border hover:border-primary/40 transition-colors aspect-[4/3] flex flex-col items-center justify-center gap-2 text-muted-foreground hover:text-primary">
          <Plus className="w-8 h-8" />
          <span className="text-sm font-medium">Crear nuevo plato</span>
        </button>
      </div>

      {scheduling && (
        <SchedulingModal
          plato={scheduling}
          onClose={() => setScheduling(null)}
          onSave={(programa) => guardarPrograma(scheduling.id, programa)}
        />
      )}
    </div>
  );
}

function SchedulingModal({
  plato,
  onClose,
  onSave,
}: {
  plato: Plato;
  onClose: () => void;
  onSave: (programa: Programa) => void;
}) {
  const [activo, setActivo] = useState(plato.programa?.activo || false);
  const [desde, setDesde] = useState(plato.programa?.desde?.slice(0, 16) || '');
  const [hasta, setHasta] = useState(plato.programa?.hasta?.slice(0, 16) || '');

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="surface rounded-2xl p-6 max-w-md w-full">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-base font-semibold flex items-center gap-2">
              <Calendar className="w-4 h-4 text-primary" /> Programar visibilidad
            </h3>
            <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{plato.nombre}</p>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="surface-2 rounded-lg p-3 flex items-center gap-3 mb-4">
          <button
            onClick={() => setActivo(!activo)}
            className={`w-10 h-6 rounded-full transition-colors relative flex-shrink-0 ${
              activo ? 'bg-primary' : 'bg-muted'
            }`}
          >
            <span
              className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                activo ? 'translate-x-4' : 'translate-x-0.5'
              }`}
            />
          </button>
          <div className="flex-1">
            <p className="text-sm font-medium">Activar programación</p>
            <p className="text-[10px] text-muted-foreground">
              Cuando está activo, el plato se muestra solo entre las fechas indicadas
            </p>
          </div>
        </div>

        {activo && (
          <>
            <div className="space-y-3 mb-4">
              <label className="block">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                  Mostrar desde
                </span>
                <input
                  type="datetime-local"
                  value={desde}
                  onChange={(e) => setDesde(e.target.value)}
                  className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
                />
              </label>
              <label className="block">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                  Ocultar el
                </span>
                <input
                  type="datetime-local"
                  value={hasta}
                  onChange={(e) => setHasta(e.target.value)}
                  className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
                />
              </label>
            </div>

            <div className="surface-2 rounded-lg p-3 mb-4 flex items-start gap-2 text-xs">
              <AlertCircle className="w-3.5 h-3.5 text-blue-400 mt-0.5 flex-shrink-0" />
              <span className="text-muted-foreground">
                Fuera de este rango, el plato estará <strong className="text-foreground">oculto</strong> para los
                clientes. Útil para promociones, menús estacionales o platos de fin de semana.
              </span>
            </div>
          </>
        )}

        <div className="flex gap-2">
          <button
            onClick={onClose}
            className="flex-1 surface-2 text-sm py-2.5 rounded-lg hover:border-primary/30"
          >
            Cancelar
          </button>
          <button
            onClick={() => onSave({ activo, desde, hasta })}
            className="flex-1 bg-primary text-primary-foreground text-sm font-medium py-2.5 rounded-lg hover:opacity-90 flex items-center justify-center gap-2"
          >
            <Check className="w-4 h-4" /> Guardar
          </button>
        </div>
      </div>
    </div>
  );
}
