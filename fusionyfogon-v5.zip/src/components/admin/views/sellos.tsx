'use client';

import { useState } from 'react';
import { Plus, Eye, EyeOff, Edit, Trash2, ArrowUp, ArrowDown, Tag, Star, Loader2 } from 'lucide-react';
import { useSellos } from '@/hooks/use-sellos';

export function SellosView() {
  const { sellos, loading, toggleVisible, mover, refetch } = useSellos();
  const [editing, setEditing] = useState<{ id?: string; emoji: string; texto: string } | null>(null);

  const visiblesCount = sellos.filter((s) => s.visible).length;

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 text-primary animate-spin" />
        <span className="ml-2 text-sm text-muted-foreground">Cargando sellos desde DB...</span>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Tag className="w-6 h-6 text-primary" /> Sellos de confianza
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            {sellos.length} sellos · {visiblesCount} visibles ·{' '}
            <span className="text-emerald-400">● datos en vivo</span>
          </p>
        </div>
        <button
          onClick={() => setEditing({ emoji: '', texto: '' })}
          className="bg-primary text-primary-foreground text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90 flex items-center gap-2"
        >
          <Plus className="w-4 h-4" /> Crear sello
        </button>
      </div>

      <div className="surface rounded-xl p-4 flex items-start gap-3 text-xs">
        <Star className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
        <span className="text-muted-foreground">
          Los sellos de confianza son badges cortos que aparecen en el home para generar credibilidad. Mantén 3-5
          visibles para no saturar.
        </span>
      </div>

      {/* Lista de sellos */}
      <div className="space-y-2">
        {sellos.map((s, i) => (
          <div key={s.id} className={`surface rounded-xl p-3 flex items-center gap-3 ${!s.visible ? 'opacity-60' : ''}`}>
            <div className="flex flex-col gap-0.5">
              <button
                onClick={() => mover(s.id, 'up')}
                disabled={i === 0}
                className="surface p-0.5 rounded hover:text-primary disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ArrowUp className="w-3 h-3" />
              </button>
              <button
                onClick={() => mover(s.id, 'down')}
                disabled={i === sellos.length - 1}
                className="surface p-0.5 rounded hover:text-primary disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ArrowDown className="w-3 h-3" />
              </button>
            </div>

            <div className="w-12 h-12 rounded-lg surface-2 flex items-center justify-center text-2xl flex-shrink-0">
              {s.emoji}
            </div>

            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{s.texto}</p>
              <p className="text-[10px] text-muted-foreground">Posición {i + 1} · {s.visible ? 'Visible' : 'Oculto'}</p>
            </div>

            {s.visible ? (
              <span className="text-[9px] bg-emerald-500/15 text-emerald-400 px-1.5 py-0.5 rounded-full font-medium flex items-center gap-1">
                <Eye className="w-2.5 h-2.5" /> Visible
              </span>
            ) : (
              <span className="text-[9px] surface text-muted-foreground px-1.5 py-0.5 rounded-full font-medium flex items-center gap-1">
                <EyeOff className="w-2.5 h-2.5" /> Oculto
              </span>
            )}

            <div className="flex items-center gap-1">
              <button
                onClick={() => setEditing({ id: s.id, emoji: s.emoji, texto: s.texto })}
                className="surface p-1.5 rounded-md hover:text-primary"
                title="Editar"
              >
                <Edit className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => toggleVisible(s.id, !s.visible)}
                className={`p-1.5 rounded-md ${s.visible ? 'surface hover:text-primary' : 'bg-amber-500/15 text-amber-400'}`}
                title={s.visible ? 'Ocultar' : 'Mostrar'}
              >
                {s.visible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
              </button>
              <button className="surface p-1.5 rounded-md hover:text-red-400" title="Eliminar">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Preview */}
      <div className="surface rounded-xl p-5">
        <h2 className="text-sm font-semibold mb-3">Preview en el home</h2>
        <div className="surface-2 rounded-lg p-4 flex flex-wrap gap-2 justify-center">
          {sellos.filter((s) => s.visible).map((s) => (
            <div
              key={s.id}
              className="bg-primary/10 border border-primary/20 rounded-full px-3 py-1.5 flex items-center gap-1.5 text-xs"
            >
              <span className="text-base">{s.emoji}</span>
              <span className="font-medium">{s.texto}</span>
            </div>
          ))}
          {sellos.filter((s) => s.visible).length === 0 && (
            <p className="text-xs text-muted-foreground py-4">No hay sellos visibles</p>
          )}
        </div>
      </div>

      {/* Editor modal */}
      {editing && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="surface rounded-2xl p-6 max-w-md w-full">
            <h3 className="text-base font-semibold mb-4">{editing.id ? 'Editar sello' : 'Crear sello'}</h3>
            <div className="space-y-3">
              <label className="block">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Emoji</span>
                <input
                  type="text"
                  defaultValue={editing.emoji}
                  placeholder="🔥"
                  className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-2xl text-center focus:outline-none focus:border-primary/40"
                />
              </label>
              <label className="block">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Texto del sello</span>
                <input
                  type="text"
                  defaultValue={editing.texto}
                  placeholder="100% natural, sin conservantes"
                  className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
                />
              </label>
            </div>
            <div className="flex gap-2 mt-5">
              <button
                onClick={() => setEditing(null)}
                className="flex-1 surface-2 text-sm py-2.5 rounded-lg hover:border-primary/30"
              >
                Cancelar
              </button>
              <button
                onClick={async () => {
                  if (editing.id) {
                    // update
                    const emoji = (document.querySelector('input[placeholder="🔥"]') as HTMLInputElement)?.value || editing.emoji
                    const texto = (document.querySelector('input[placeholder="100% natural, sin conservantes"]') as HTMLInputElement)?.value || editing.texto
                    await fetch(`/api/sellos/${editing.id}`, {
                      method: 'PATCH',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ emoji, texto }),
                    })
                  } else {
                    // create
                    const emoji = (document.querySelector('input[placeholder="🔥"]') as HTMLInputElement)?.value
                    const texto = (document.querySelector('input[placeholder="100% natural, sin conservantes"]') as HTMLInputElement)?.value
                    if (emoji && texto) {
                      await fetch('/api/sellos', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ emoji, texto }),
                      })
                    }
                  }
                  setEditing(null)
                  refetch()
                }}
                className="flex-1 bg-primary text-primary-foreground text-sm font-medium py-2.5 rounded-lg hover:opacity-90 flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" /> Guardar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
