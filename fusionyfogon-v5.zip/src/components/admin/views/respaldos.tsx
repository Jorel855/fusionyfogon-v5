'use client';

import { useState } from 'react';
import {
  DatabaseBackup,
  Download,
  Upload,
  RotateCcw,
  Clock,
  HardDrive,
  Mail,
  Sheet,
  Check,
  AlertTriangle,
  History,
  Trash2,
} from 'lucide-react';

type Backup = {
  id: string;
  fecha: string;
  tipo: 'auto-diario' | 'auto-destructivo' | 'manual' | 'auto-email';
  autor: string;
  size: string;
  actual: boolean;
};

const HISTORIAL: Backup[] = [
  { id: 'b-001', fecha: '9/10/2026, 15:21:08', tipo: 'auto-destructivo', autor: 'Sistema', size: '8.2 MB', actual: false },
  { id: 'b-002', fecha: '9/10/2026, 14:55:33', tipo: 'manual', autor: 'Jorel Kales', size: '8.1 MB', actual: true },
  { id: 'b-003', fecha: '9/10/2026, 03:00:00', tipo: 'auto-diario', autor: 'Sistema', size: '8.1 MB', actual: false },
  { id: 'b-004', fecha: '8/10/2026, 03:00:00', tipo: 'auto-diario', autor: 'Sistema', size: '8.0 MB', actual: false },
  { id: 'b-005', fecha: '7/10/2026, 21:42:11', tipo: 'auto-destructivo', autor: 'Sistema', size: '7.9 MB', actual: false },
  { id: 'b-006', fecha: '7/10/2026, 03:00:00', tipo: 'auto-diario', autor: 'Sistema', size: '7.9 MB', actual: false },
  { id: 'b-007', fecha: '6/10/2026, 03:00:00', tipo: 'auto-diario', autor: 'Sistema', size: '7.8 MB', actual: false },
  { id: 'b-008', fecha: '5/10/2026, 03:00:00', tipo: 'auto-diario', autor: 'Sistema', size: '7.8 MB', actual: false },
  { id: 'b-009', fontSize: '12px', fecha: '4/10/2026, 11:18:42', tipo: 'manual', autor: 'Jorel Kales', size: '7.7 MB', actual: false } as Backup,
  { id: 'b-010', fecha: '4/10/2026, 03:00:00', tipo: 'auto-diario', autor: 'Sistema', size: '7.7 MB', actual: false },
];

const TIPO_LABELS: Record<Backup['tipo'], { label: string; color: string; bg: string }> = {
  'auto-diario': { label: 'Diario auto', color: '#10B981', bg: 'rgba(16,185,129,0.12)' },
  'auto-destructivo': { label: 'Pre-destructivo', color: '#F59E0B', bg: 'rgba(245,158,11,0.12)' },
  manual: { label: 'Manual', color: '#CC6600', bg: 'rgba(204,102,0,0.12)' },
  'auto-email': { label: 'Email semanal', color: '#3B82F6', bg: 'rgba(59,130,246,0.12)' },
};

export function RespaldosView() {
  const [autoDiario, setAutoDiario] = useState(true);
  const [autoDestructivo, setAutoDestructivo] = useState(true);
  const [autoEmail, setAutoEmail] = useState(true);
  const [autoSheets, setAutoSheets] = useState(false);
  const [restoreConfirm, setRestoreConfirm] = useState<string | null>(null);

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Respaldos</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Almacenado en Netlify Blobs · 100% dentro de Netlify · Sin servicios externos
          </p>
        </div>
        <button className="bg-primary text-primary-foreground text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90 flex items-center gap-2">
          <DatabaseBackup className="w-4 h-4" /> Crear backup manual ahora
        </button>
      </div>

      {/* Status */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: 'Último backup', value: 'hace 2 horas', icon: Clock, status: 'ok' },
          { label: 'Almacenamiento', value: '8.2 MB / 100 GB', icon: HardDrive, status: 'ok', sub: '0.008% usado' },
          { label: 'Backups totales', value: '30', icon: History, status: 'ok', sub: 'rotación automática' },
          { label: 'Próximo auto', value: '10/10 03:00 AM', icon: DatabaseBackup, status: 'ok', sub: 'diario programado' },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="surface rounded-xl p-4">
              <div className="flex items-start justify-between mb-1">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{s.label}</span>
                <Icon className="w-3.5 h-3.5 text-primary" />
              </div>
              <p className="text-sm font-semibold">{s.value}</p>
              {s.sub && <p className="text-[10px] text-muted-foreground mt-0.5">{s.sub}</p>}
            </div>
          );
        })}
      </div>

      {/* Configuración automática */}
      <div className="surface rounded-xl p-5">
        <h2 className="text-sm font-semibold mb-4">Programación automática</h2>
        <div className="space-y-3">
          {/* Diario */}
          <div className="surface-2 rounded-lg p-3 flex items-center gap-3">
            <button
              onClick={() => setAutoDiario(!autoDiario)}
              className={`w-10 h-6 rounded-full transition-colors relative flex-shrink-0 ${
                autoDiario ? 'bg-primary' : 'bg-muted'
              }`}
            >
              <span
                className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                  autoDiario ? 'translate-x-4' : 'translate-x-0.5'
                }`}
              />
            </button>
            <div className="flex-1">
              <p className="text-sm font-medium">Snapshot diario</p>
              <p className="text-[10px] text-muted-foreground">
                Todos los días a las 3:00 AM America/Bogota · vía Netlify Scheduled Function
              </p>
            </div>
            <span className="text-[10px] bg-emerald-500/15 text-emerald-400 px-2 py-0.5 rounded-full font-medium">
              12 backups
            </span>
          </div>

          {/* Pre-destructivo */}
          <div className="surface-2 rounded-lg p-3 flex items-center gap-3">
            <button
              onClick={() => setAutoDestructivo(!autoDestructivo)}
              className={`w-10 h-6 rounded-full transition-colors relative flex-shrink-0 ${
                autoDestructivo ? 'bg-primary' : 'bg-muted'
              }`}
            >
              <span
                className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                  autoDestructivo ? 'translate-x-4' : 'translate-x-0.5'
                }`}
              />
            </button>
            <div className="flex-1">
              <p className="text-sm font-medium">Antes de cambios destructivos</p>
              <p className="text-[10px] text-muted-foreground">
                Auto-snapshot antes de eliminar platos, vaciar pedidos o cambiar el PIN
              </p>
            </div>
            <span className="text-[10px] bg-emerald-500/15 text-emerald-400 px-2 py-0.5 rounded-full font-medium">
              45 snapshots
            </span>
          </div>

          {/* Email semanal */}
          <div className="surface-2 rounded-lg p-3 flex items-center gap-3">
            <button
              onClick={() => setAutoEmail(!autoEmail)}
              className={`w-10 h-6 rounded-full transition-colors relative flex-shrink-0 ${
                autoEmail ? 'bg-primary' : 'bg-muted'
              }`}
            >
              <span
                className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                  autoEmail ? 'translate-x-4' : 'translate-x-0.5'
                }`}
              />
            </button>
            <div className="flex-1">
              <p className="text-sm font-medium flex items-center gap-2">
                <Mail className="w-3.5 h-3.5" /> Backup semanal a email
              </p>
              <p className="text-[10px] text-muted-foreground">
                Cada domingo a jorel@fusionyfogon.com · adjunta JSON + resumen
              </p>
            </div>
            <span className="text-[10px] bg-emerald-500/15 text-emerald-400 px-2 py-0.5 rounded-full font-medium">
              Activo
            </span>
          </div>

          {/* Sheets mensual */}
          <div className="surface-2 rounded-lg p-3 flex items-center gap-3">
            <button
              onClick={() => setAutoSheets(!autoSheets)}
              className={`w-10 h-6 rounded-full transition-colors relative flex-shrink-0 ${
                autoSheets ? 'bg-primary' : 'bg-muted'
              }`}
            >
              <span
                className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                  autoSheets ? 'translate-x-4' : 'translate-x-0.5'
                }`}
              />
            </button>
            <div className="flex-1">
              <p className="text-sm font-medium flex items-center gap-2">
                <Sheet className="w-3.5 h-3.5" /> Resumen mensual a Google Sheets
              </p>
              <p className="text-[10px] text-muted-foreground">
                Hoja de cálculo con pedidos, reservas y ventas del mes · requiere conectar Google Account
              </p>
            </div>
            <span className="text-[10px] bg-amber-500/15 text-amber-400 px-2 py-0.5 rounded-full font-medium">
              Opcional
            </span>
          </div>
        </div>
      </div>

      {/* Historial */}
      <div className="surface rounded-xl p-5">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold flex items-center gap-2">
            <History className="w-4 h-4" /> Historial de respaldos (últimos 30)
          </h2>
          <span className="text-[10px] text-muted-foreground">Rotación: más antiguos se borran automáticamente</span>
        </div>
        <div className="space-y-1 max-h-96 overflow-y-auto">
          {HISTORIAL.map((b) => {
            const tipo = TIPO_LABELS[b.tipo];
            return (
              <div
                key={b.id}
                className={`surface-2 rounded-lg p-3 flex items-center gap-3 ${
                  b.actual ? 'ring-1 ring-primary/40' : ''
                }`}
              >
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ background: tipo.bg, color: tipo.color }}
                >
                  <DatabaseBackup className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium flex items-center gap-2">
                    {b.fecha}
                    {b.actual && (
                      <span className="text-[9px] bg-primary text-primary-foreground px-1.5 py-0.5 rounded-full font-bold">
                        ACTUAL
                      </span>
                    )}
                  </p>
                  <p className="text-[10px] text-muted-foreground">
                    {b.autor} · {b.size}
                  </p>
                </div>
                <span
                  className="text-[10px] font-medium px-2 py-0.5 rounded-full whitespace-nowrap"
                  style={{ background: tipo.bg, color: tipo.color }}
                >
                  {tipo.label}
                </span>
                <div className="flex items-center gap-1">
                  <button className="surface p-1.5 rounded-md hover:text-primary" title="Descargar">
                    <Download className="w-3.5 h-3.5" />
                  </button>
                  {!b.actual && (
                    <button
                      onClick={() => setRestoreConfirm(b.id)}
                      className="surface p-1.5 rounded-md hover:text-primary"
                      title="Restaurar"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Restore confirm */}
      {restoreConfirm && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="surface rounded-2xl p-6 max-w-md w-full">
            <div className="w-12 h-12 rounded-full bg-amber-500/15 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-6 h-6 text-amber-400" />
            </div>
            <h3 className="text-lg font-semibold text-center mb-2">¿Restaurar este respaldo?</h3>
            <p className="text-sm text-muted-foreground text-center mb-5">
              Se reemplazará el estado actual por la versión del <strong>{HISTORIAL.find((b) => b.id === restoreConfirm)?.fecha}</strong>.
              No se pierde nada: el estado actual se guarda automáticamente como nuevo backup antes de la restauración.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setRestoreConfirm(null)}
                className="flex-1 surface-2 text-sm py-2.5 rounded-lg hover:border-primary/30"
              >
                Cancelar
              </button>
              <button
                onClick={() => setRestoreConfirm(null)}
                className="flex-1 bg-primary text-primary-foreground text-sm font-medium py-2.5 rounded-lg hover:opacity-90 flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" /> Restaurar ahora
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Importar / Exportar */}
      <div className="surface rounded-xl p-5">
        <h2 className="text-sm font-semibold mb-3">Importar / Exportar manual</h2>
        <div className="grid sm:grid-cols-2 gap-3">
          <button className="surface-2 rounded-lg p-4 hover:border-primary/30 transition-colors text-left">
            <Download className="w-5 h-5 text-primary mb-2" />
            <p className="text-sm font-medium">Descargar JSON completo</p>
            <p className="text-[10px] text-muted-foreground mt-1">
              Exporta todo el estado actual (menú, pedidos, reservas, config) en un archivo .json
            </p>
          </button>
          <button className="surface-2 rounded-lg p-4 hover:border-primary/30 transition-colors text-left">
            <Upload className="w-5 h-5 text-primary mb-2" />
            <p className="text-sm font-medium">Restaurar desde archivo</p>
            <p className="text-[10px] text-muted-foreground mt-1">
              Sube un .json de respaldo previo · se crea snapshot automático antes de aplicar
            </p>
          </button>
        </div>
      </div>

      {/* Info banner */}
      <div className="surface rounded-xl p-4 flex items-start gap-3 text-xs">
        <div className="w-8 h-8 rounded-lg bg-primary/15 flex items-center justify-center flex-shrink-0">
          <Check className="w-4 h-4 text-primary" />
        </div>
        <div className="text-muted-foreground">
          <strong className="text-foreground">100% dentro de Netlify.</strong> Los respaldos se guardan en Netlify
          Blobs (mismo servicio donde ya está tu app). Sin costos adicionales, sin servicios externos, sin
          configuración DNS. Rotación automática mantiene los últimos 30 backups. La función programada corre vía{' '}
          <code className="surface-2 px-1 py-0.5 rounded text-primary">netlify/functions/scheduled-backup.ts</code>{' '}
          con un cron diario.
        </div>
      </div>
    </div>
  );
}
