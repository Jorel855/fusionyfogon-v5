'use client';

import { useState } from 'react';
import {
  Eye,
  EyeOff,
  Calendar,
  Users,
  Layout,
  Package,
  Tag,
  Sparkles,
  ChefHat,
  Image as ImageIcon,
  CalendarCheck,
  ShoppingCart,
  Info,
  Check,
  AlertTriangle,
  Lock,
  Shield,
} from 'lucide-react';

type ModuloKey =
  | 'catalogo'
  | 'pedidos'
  | 'reservas'
  | 'catering'
  | 'esencia'
  | 'galeria'
  | 'pestanas'
  | 'sellos'
  | 'whatsapp'
  | 'ubicacion';

type Modulo = {
  key: ModuloKey;
  nombre: string;
  descripcion: string;
  icon: React.ComponentType<{ className?: string }>;
  activo: boolean;
  programable: boolean;
  itemsOcultos: number;
  itemsTotales: number;
  rolesPermitidos: ('Admin' | 'Editor' | 'Cajero' | 'Cocina')[];
};

const MODULOS: Modulo[] = [
  {
    key: 'catalogo',
    nombre: 'Catálogo (platos/servicios)',
    descripcion: 'Lista de productos del negocio con fotos, precios y badges',
    icon: Package,
    activo: true,
    programable: true,
    itemsOcultos: 3,
    itemsTotales: 5,
    rolesPermitidos: ['Admin', 'Editor'],
  },
  {
    key: 'pedidos',
    nombre: 'Pedidos online',
    descripcion: 'Carrito + checkout + estados + WhatsApp automático',
    icon: ShoppingCart,
    activo: true,
    programable: false,
    itemsOcultos: 0,
    itemsTotales: 1,
    rolesPermitidos: ['Admin', 'Editor', 'Cajero', 'Cocina'],
  },
  {
    key: 'reservas',
    nombre: 'Reservas / Citas',
    descripcion: 'Calendario de reservas con confirmación',
    icon: CalendarCheck,
    activo: true,
    programable: true,
    itemsOcultos: 0,
    itemsTotales: 1,
    rolesPermitidos: ['Admin', 'Editor', 'Cajero'],
  },
  {
    key: 'catering',
    nombre: 'Catering / Eventos',
    descripcion: 'Pestaña con servicios de catering y eventos',
    icon: ChefHat,
    activo: true,
    programable: true,
    itemsOcultos: 0,
    itemsTotales: 2,
    rolesPermitidos: ['Admin', 'Editor'],
  },
  {
    key: 'esencia',
    nombre: 'Esencia (Misión/Visión)',
    descripcion: 'Pestaña con historia, misión, visión del negocio',
    icon: Sparkles,
    activo: true,
    programable: false,
    itemsOcultos: 0,
    itemsTotales: 5,
    rolesPermitidos: ['Admin', 'Editor'],
  },
  {
    key: 'galeria',
    nombre: 'Galería de fotos',
    descripcion: 'Álbum visual con drag & drop',
    icon: ImageIcon,
    activo: false,
    programable: true,
    itemsOcultos: 0,
    itemsTotales: 0,
    rolesPermitidos: ['Admin', 'Editor'],
  },
  {
    key: 'pestanas',
    nombre: 'Pestañas extras',
    descripcion: 'Pestañas personalizadas con contenido libre',
    icon: Layout,
    activo: false,
    programable: true,
    itemsOcultos: 0,
    itemsTotales: 0,
    rolesPermitidos: ['Admin', 'Editor'],
  },
  {
    key: 'sellos',
    nombre: 'Sellos de confianza',
    descripcion: 'Badges editables (100% cerdo, hecho en casa, etc)',
    icon: Tag,
    activo: true,
    programable: false,
    itemsOcultos: 0,
    itemsTotales: 3,
    rolesPermitidos: ['Admin', 'Editor'],
  },
  {
    key: 'whatsapp',
    nombre: 'WhatsApp directo',
    descripcion: 'Botón flotante de WhatsApp — siempre visible (no se puede ocultar)',
    icon: ShoppingCart,
    activo: true,
    programable: false,
    itemsOcultos: 0,
    itemsTotales: 1,
    rolesPermitidos: ['Admin', 'Editor', 'Cajero', 'Cocina'],
  },
  {
    key: 'ubicacion',
    nombre: 'Contacto y ubicación',
    descripcion: 'Dirección, horarios, mapa — siempre visible para SEO local',
    icon: Calendar,
    activo: true,
    programable: false,
    itemsOcultos: 0,
    itemsTotales: 1,
    rolesPermitidos: ['Admin', 'Editor'],
  },
];

const ROLES = ['Admin', 'Editor', 'Cajero', 'Cocina'] as const;
const ROLE_COLORS: Record<string, string> = {
  Admin: '#CC6600',
  Editor: '#3B82F6',
  Cajero: '#10B981',
  Cocina: '#A855F7',
};

const MODULO_NO_OCULTABLE: ModuloKey[] = ['whatsapp', 'ubicacion'];

export function VisibilidadPermisosView() {
  const [modulos, setModulos] = useState(MODULOS);

  const toggleModulo = (key: ModuloKey) => {
    if (MODULO_NO_OCULTABLE.includes(key)) return;
    setModulos((m) => m.map((x) => (x.key === key ? { ...x, activo: !x.activo } : x)));
  };

  const toggleRol = (key: ModuloKey, rol: string) => {
    setModulos((m) =>
      m.map((x) => {
        if (x.key !== key) return x;
        const has = x.rolesPermitidos.includes(rol as any);
        return {
          ...x,
          rolesPermitidos: has
            ? x.rolesPermitidos.filter((r) => r !== rol)
            : [...x.rolesPermitidos, rol as any],
        };
      })
    );
  };

  const visiblesCount = modulos.filter((m) => m.activo).length;
  const programablesCount = modulos.filter((m) => m.programable).length;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <Eye className="w-6 h-6 text-primary" />
          Visibilidad & Permisos
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Controla qué pestañas, módulos e items ven tus clientes y qué puede hacer cada rol de usuario
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="surface rounded-xl p-4">
          <Eye className="w-5 h-5 text-emerald-400 mb-1" />
          <p className="text-2xl font-bold">{visiblesCount}</p>
          <p className="text-[10px] text-muted-foreground">módulos visibles</p>
        </div>
        <div className="surface rounded-xl p-4">
          <EyeOff className="w-5 h-5 text-muted-foreground mb-1" />
          <p className="text-2xl font-bold">{modulos.length - visiblesCount}</p>
          <p className="text-[10px] text-muted-foreground">módulos ocultos</p>
        </div>
        <div className="surface rounded-xl p-4">
          <Calendar className="w-5 h-5 text-primary mb-1" />
          <p className="text-2xl font-bold">{programablesCount}</p>
          <p className="text-[10px] text-muted-foreground">programables temporalmente</p>
        </div>
        <div className="surface rounded-xl p-4">
          <Users className="w-5 h-5 text-blue-400 mb-1" />
          <p className="text-2xl font-bold">4</p>
          <p className="text-[10px] text-muted-foreground">roles definidos</p>
        </div>
      </div>

      {/* Reglas de visibilidad por item */}
      <div className="surface rounded-xl p-5">
        <h2 className="text-sm font-semibold mb-1 flex items-center gap-2">
          <Layout className="w-4 h-4" /> Módulos y pestañas
        </h2>
        <p className="text-xs text-muted-foreground mb-4">
          Activa o desactiva cada módulo. Los items dentro de cada módulo se controlan individualmente desde su propia
          vista (Catálogo, Esencia, etc.)
        </p>

        <div className="space-y-2">
          {modulos.map((m) => {
            const Icon = m.icon;
            const isNoOcultable = MODULO_NO_OCULTABLE.includes(m.key);
            return (
              <div
                key={m.key}
                className={`surface-2 rounded-lg p-3 ${!m.activo ? 'opacity-60' : ''}`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                      m.activo ? 'bg-primary/15 text-primary' : 'surface text-muted-foreground'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm font-medium">{m.nombre}</p>
                      {isNoOcultable && (
                        <span
                          className="text-[9px] bg-amber-500/15 text-amber-400 px-1.5 py-0.5 rounded-full font-medium flex items-center gap-1"
                          title="Este módulo no se puede ocultar — es canal de fallback o requerido para SEO"
                        >
                          <Lock className="w-2.5 h-2.5" /> Siempre visible
                        </span>
                      )}
                      {m.programable && (
                        <span className="text-[9px] bg-blue-500/15 text-blue-400 px-1.5 py-0.5 rounded-full font-medium flex items-center gap-1">
                          <Calendar className="w-2.5 h-2.5" /> Programable
                        </span>
                      )}
                      {m.itemsOcultos > 0 && (
                        <span className="text-[9px] surface px-1.5 py-0.5 rounded-full font-medium text-muted-foreground">
                          {m.itemsOcultos}/{m.itemsTotales} items ocultos
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-muted-foreground mt-0.5">{m.descripcion}</p>
                  </div>

                  {/* Toggle */}
                  <button
                    onClick={() => toggleModulo(m.key)}
                    disabled={isNoOcultable}
                    className={`w-10 h-6 rounded-full transition-colors relative flex-shrink-0 disabled:cursor-not-allowed ${
                      m.activo ? 'bg-primary' : 'bg-muted'
                    } ${isNoOcultable ? 'opacity-50' : ''}`}
                    title={isNoOcultable ? 'No se puede ocultar' : ''}
                  >
                    <span
                      className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                        m.activo ? 'translate-x-4' : 'translate-x-0.5'
                      }`}
                    />
                  </button>
                </div>

                {/* Roles */}
                <div className="mt-3 pt-3 border-t border-border flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] uppercase tracking-wider text-muted-foreground flex items-center gap-1">
                    <Shield className="w-3 h-3" /> Roles:
                  </span>
                  {ROLES.map((r) => {
                    const has = m.rolesPermitidos.includes(r);
                    return (
                      <button
                        key={r}
                        onClick={() => toggleRol(m.key, r)}
                        className={`text-[10px] px-2 py-0.5 rounded-full font-medium transition-colors ${
                          has ? 'text-white' : 'surface text-muted-foreground hover:text-foreground'
                        }`}
                        style={has ? { background: ROLE_COLORS[r] } : {}}
                      >
                        {has && <Check className="w-2.5 h-2.5 inline mr-0.5" />}
                        {r}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Programación temporal */}
      <div className="surface rounded-xl p-5">
        <h2 className="text-sm font-semibold mb-1 flex items-center gap-2">
          <Calendar className="w-4 h-4" /> Programación temporal activa
        </h2>
        <p className="text-xs text-muted-foreground mb-4">
          Items con visibilidad programada — se muestran/ocultan automáticamente en las fechas indicadas
        </p>

        <div className="space-y-2">
          <div className="surface-2 rounded-lg p-3 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500/15 text-amber-400 flex items-center justify-center flex-shrink-0">
              <Calendar className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium">🎨 Promo Halloween (pestaña extra)</p>
              <p className="text-[10px] text-muted-foreground">
                Visible del <strong>24/10/2026 00:00</strong> al <strong>31/10/2026 23:59</strong>
              </p>
            </div>
            <span className="text-[10px] bg-amber-500/15 text-amber-400 px-2 py-0.5 rounded-full font-medium">
              Programado
            </span>
            <button className="surface p-1.5 rounded-md hover:text-primary" title="Editar">
              ✏️
            </button>
          </div>

          <div className="surface-2 rounded-lg p-3 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-red-500/15 text-red-400 flex items-center justify-center flex-shrink-0">
              <Calendar className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium">🚫 Reservas bloqueadas (vacaciones)</p>
              <p className="text-[10px] text-muted-foreground">
                Reservas bloqueadas del <strong>24/12/2026</strong> al <strong>26/12/2026</strong>
              </p>
            </div>
            <span className="text-[10px] bg-red-500/15 text-red-400 px-2 py-0.5 rounded-full font-medium">
              Bloqueo
            </span>
            <button className="surface p-1.5 rounded-md hover:text-primary" title="Editar">
              ✏️
            </button>
          </div>

          <div className="surface-2 rounded-lg p-3 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/15 text-emerald-400 flex items-center justify-center flex-shrink-0">
              <Calendar className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium">🎄 Menú especial Navideño (categoría)</p>
              <p className="text-[10px] text-muted-foreground">
                Visible del <strong>15/12/2026 00:00</strong> al <strong>25/12/2026 23:59</strong>
              </p>
            </div>
            <span className="text-[10px] bg-emerald-500/15 text-emerald-400 px-2 py-0.5 rounded-full font-medium">
              Programado
            </span>
            <button className="surface p-1.5 rounded-md hover:text-primary" title="Editar">
              ✏️
            </button>
          </div>
        </div>

        <button className="mt-3 w-full surface-2 border border-dashed rounded-lg p-3 text-xs text-muted-foreground hover:text-primary hover:border-primary/30 transition-colors flex items-center justify-center gap-2">
          <Calendar className="w-4 h-4" /> + Crear nueva programación temporal
        </button>
      </div>

      {/* Reglas profesionales */}
      <div className="surface rounded-xl p-5">
        <h2 className="text-sm font-semibold mb-3 flex items-center gap-2">
          <Info className="w-4 h-4" /> Reglas profesionales aplicadas
        </h2>
        <div className="grid sm:grid-cols-2 gap-3 text-xs">
          <div className="surface-2 rounded-lg p-3 flex items-start gap-2">
            <Check className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-foreground">Mínimo 1 botón visible en home</p>
              <p className="text-muted-foreground mt-0.5">
                El sistema valida que nunca quedes con un home vacío. Si intentas ocultar el último botón, te avisa.
              </p>
            </div>
          </div>
          <div className="surface-2 rounded-lg p-3 flex items-start gap-2">
            <Check className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-foreground">WhatsApp siempre visible</p>
              <p className="text-muted-foreground mt-0.5">
                Es canal de fallback. No se puede ocultar — el cliente siempre debe poder contactarte.
              </p>
            </div>
          </div>
          <div className="surface-2 rounded-lg p-3 flex items-start gap-2">
            <Check className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-foreground">Ubicación siempre visible</p>
              <p className="text-muted-foreground mt-0.5">
                Google penaliza el SEO local si no hay NAP (Name, Address, Phone) visible. No se puede ocultar.
              </p>
            </div>
          </div>
          <div className="surface-2 rounded-lg p-3 flex items-start gap-2">
            <Check className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-foreground">4 roles predefinidos</p>
              <p className="text-muted-foreground mt-0.5">
                Admin, Editor, Cajero, Cocina. No roles custom — evita complejidad innecesaria.
              </p>
            </div>
          </div>
          <div className="surface-2 rounded-lg p-3 flex items-start gap-2">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-foreground">Programación con hora local</p>
              <p className="text-muted-foreground mt-0.5">
                Las fechas usan America/Bogota. Si viajas, no te confundas con zonas horarias.
              </p>
            </div>
          </div>
          <div className="surface-2 rounded-lg p-3 flex items-start gap-2">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-foreground">Visibilidad ≠ Permisos</p>
              <p className="text-muted-foreground mt-0.5">
                Visibilidad: qué ve el cliente en la web. Permisos: qué ve el staff en el panel. Independientes.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
