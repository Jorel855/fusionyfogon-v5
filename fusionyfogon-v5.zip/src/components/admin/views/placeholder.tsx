'use client';

import { Construction } from 'lucide-react';

export function PlaceholderView({ title, description }: { title: string; description: string }) {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
        <p className="text-sm text-muted-foreground mt-1">{description}</p>
      </div>
      <div className="surface rounded-xl p-12 flex flex-col items-center justify-center text-center min-h-[300px]">
        <div className="w-14 h-14 rounded-2xl surface-2 flex items-center justify-center mb-4">
          <Construction className="w-7 h-7 text-primary" />
        </div>
        <h3 className="text-base font-semibold mb-1">Módulo disponible en implementación real</h3>
        <p className="text-sm text-muted-foreground max-w-md">
          Esta sección es parte del plan de plantilla multi-tenant. En la demo se muestra el layout general; al
          implementar el proyecto completo, aquí vivirá el CRUD específico del módulo.
        </p>
        <div className="mt-4 flex flex-wrap gap-2 justify-center">
          <span className="text-[10px] surface-2 px-2 py-1 rounded-full">Layout listo</span>
          <span className="text-[10px] surface-2 px-2 py-1 rounded-full">Backend pendiente</span>
          <span className="text-[10px] surface-2 px-2 py-1 rounded-full">API REST + Prisma</span>
        </div>
      </div>
    </div>
  );
}
