'use client';

import { useState } from 'react';
import {
  Cloud,
  Database,
  Users,
  CreditCard,
  MessageCircle,
  Search,
  BarChart3,
  Image as ImageIcon,
  Plug,
  Check,
  AlertCircle,
  ExternalLink,
  Zap,
} from 'lucide-react';

type Integration = {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  status: 'connected' | 'partial' | 'disconnected';
  category: 'netlify' | 'payments' | 'comms' | 'marketing' | 'media';
  badge?: string;
  cta: string;
};

const INTEGRATIONS: Integration[] = [
  {
    id: 'netlify-blobs',
    name: 'Netlify Blobs',
    description: 'Almacenamiento de datos en vivo (menú, pedidos, reservas, config). 100GB gratis.',
    icon: Database,
    status: 'connected',
    category: 'netlify',
    badge: 'Activo · 8.2 MB',
    cta: 'Ver datos',
  },
  {
    id: 'netlify-identity',
    name: 'Netlify Identity',
    description: 'Autenticación de usuarios con email + roles (Admin, Editor, Cajero, Cocina).',
    icon: Users,
    status: 'connected',
    category: 'netlify',
    badge: '1 usuario activo',
    cta: 'Gestionar',
  },
  {
    id: 'netlify-functions',
    name: 'Netlify Functions',
    description: 'Backend serverless (fyf40). Migrado a TypeScript con SSE para live-updates.',
    icon: Zap,
    status: 'connected',
    category: 'netlify',
    badge: '6 endpoints',
    cta: 'Ver funciones',
  },
  {
    id: 'netlify-scheduled',
    name: 'Netlify Scheduled Functions',
    description: 'Cron jobs: backup diario 3AM, sitemap auto, sync Google Indexing.',
    icon: Cloud,
    status: 'partial',
    category: 'netlify',
    badge: '2/3 activos',
    cta: 'Configurar',
  },
  {
    id: 'wompi',
    name: 'Wompi (Bancolombia)',
    description: 'Pagos online: tarjetas, PSE, Nequi, Bancolombia transfiere. Comisión 2.9% + $900.',
    icon: CreditCard,
    status: 'disconnected',
    category: 'payments',
    cta: 'Conectar',
  },
  {
    id: 'mercadopago',
    name: 'Mercado Pago',
    description: 'Alternativa a Wompi. Sin mensualidad. Comisión 3.49%. Más rápido de aprobar.',
    icon: CreditCard,
    status: 'disconnected',
    category: 'payments',
    cta: 'Conectar',
  },
  {
    id: 'whatsapp-cloud',
    name: 'WhatsApp Cloud API',
    description: 'Notificaciones automáticas a clientes y admin. Plantillas pre-aprobadas por Meta.',
    icon: MessageCircle,
    status: 'connected',
    category: 'comms',
    badge: '247 msgs este mes',
    cta: 'Configurar plantillas',
  },
  {
    id: 'gsc',
    name: 'Google Search Console',
    description: 'Indexación automática vía Indexing API. Sitemap submit. Monitoreo de posición.',
    icon: Search,
    status: 'disconnected',
    category: 'marketing',
    cta: 'Conectar cuenta',
  },
  {
    id: 'ga4',
    name: 'Google Analytics 4',
    description: 'Métricas en dashboard: visitas, conversión, fuentes de tráfico.',
    icon: BarChart3,
    status: 'disconnected',
    category: 'marketing',
    cta: 'Conectar',
  },
  {
    id: 'cloudinary',
    name: 'Cloudinary',
    description: 'CDN de imágenes con resize automático y WebP. Reemplaza base64 por URLs optimizadas.',
    icon: ImageIcon,
    status: 'disconnected',
    category: 'media',
    badge: 'Hoy: base64 en JSON',
    cta: 'Conectar',
  },
];

const CATEGORIES = [
  { id: 'netlify', label: 'Netlify', icon: Cloud, color: '#00C7B7' },
  { id: 'payments', label: 'Pagos', icon: CreditCard, color: '#CC6600' },
  { id: 'comms', label: 'Comunicación', icon: MessageCircle, color: '#10B981' },
  { id: 'marketing', label: 'Marketing', icon: BarChart3, color: '#3B82F6' },
  { id: 'media', label: 'Media', icon: ImageIcon, color: '#A855F7' },
];

const STATUS_STYLES = {
  connected: { label: 'Conectado', color: '#10B981', bg: 'rgba(16,185,129,0.12)' },
  partial: { label: 'Parcial', color: '#F59E0B', bg: 'rgba(245,158,11,0.12)' },
  disconnected: { label: 'No conectado', color: '#A8978A', bg: 'rgba(168,151,138,0.12)' },
};

export function IntegracionesView() {
  const [activeCat, setActiveCat] = useState<string>('netlify');

  const filtered = INTEGRATIONS.filter((i) => i.category === activeCat);
  const connectedCount = INTEGRATIONS.filter((i) => i.status === 'connected').length;

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Integraciones</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {connectedCount} de {INTEGRATIONS.length} conectadas · Stack 100% dentro de Netlify
          </p>
        </div>
        <a
          href="https://app.netlify.com"
          target="_blank"
          rel="noreferrer"
          className="surface-2 text-xs px-3 py-2 rounded-lg hover:border-primary/30 flex items-center gap-1.5"
        >
          <ExternalLink className="w-3.5 h-3.5" /> Abrir Netlify Dashboard
        </a>
      </div>

      {/* Stack diagram */}
      <div className="surface rounded-xl p-5">
        <h2 className="text-sm font-semibold mb-3">Arquitectura del stack</h2>
        <div className="flex items-center gap-2 overflow-x-auto pb-2 text-xs">
          <div className="surface-2 rounded-lg p-3 flex-shrink-0 min-w-[120px]">
            <p className="font-semibold text-primary">🌐 PWA</p>
            <p className="text-[10px] text-muted-foreground mt-1">Next.js deployado en Netlify</p>
          </div>
          <span className="text-muted-foreground">→</span>
          <div className="surface-2 rounded-lg p-3 flex-shrink-0 min-w-[120px]">
            <p className="font-semibold text-primary">⚡ Functions</p>
            <p className="text-[10px] text-muted-foreground mt-1">fyf40 (TypeScript) + SSE</p>
          </div>
          <span className="text-muted-foreground">→</span>
          <div className="surface-2 rounded-lg p-3 flex-shrink-0 min-w-[120px]">
            <p className="font-semibold text-primary">💾 Blobs</p>
            <p className="text-[10px] text-muted-foreground mt-1">Datos en vivo (JSON)</p>
          </div>
          <span className="text-muted-foreground">→</span>
          <div className="surface-2 rounded-lg p-3 flex-shrink-0 min-w-[120px]">
            <p className="font-semibold text-primary">🔐 Identity</p>
            <p className="text-[10px] text-muted-foreground mt-1">Auth + roles</p>
          </div>
          <span className="text-muted-foreground">→</span>
          <div className="surface-2 rounded-lg p-3 flex-shrink-0 min-w-[120px]">
            <p className="font-semibold text-primary">🕐 Scheduled</p>
            <p className="text-[10px] text-muted-foreground mt-1">Backups + sitemap</p>
          </div>
        </div>
        <div className="mt-3 p-3 surface-2 rounded-lg flex items-start gap-2 text-xs">
          <Check className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
          <span className="text-muted-foreground">
            <strong className="text-foreground">Cero servicios externos obligatorios.</strong> Wompi, WhatsApp Cloud,
            GSC, GA4 y Cloudinary son complementos opcionales — la app funciona sin ellos.
          </span>
        </div>
      </div>

      {/* Category tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {CATEGORIES.map((cat) => {
          const Icon = cat.icon;
          const isActive = activeCat === cat.id;
          const count = INTEGRATIONS.filter((i) => i.category === cat.id).length;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCat(cat.id)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm whitespace-nowrap transition-colors ${
                isActive ? 'surface-2 border border-primary/30 text-primary font-medium' : 'surface-2 hover:border-primary/20'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{cat.label}</span>
              <span className="text-[10px] text-muted-foreground">({count})</span>
            </button>
          );
        })}
      </div>

      {/* Integration cards */}
      <div className="grid sm:grid-cols-2 gap-4">
        {filtered.map((int) => {
          const Icon = int.icon;
          const status = STATUS_STYLES[int.status];
          const cat = CATEGORIES.find((c) => c.id === int.category)!;
          return (
            <div key={int.id} className="surface rounded-xl p-5">
              <div className="flex items-start gap-3 mb-3">
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ background: `${cat.color}15`, color: cat.color }}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-sm font-semibold">{int.name}</h3>
                    <span
                      className="text-[10px] font-medium px-2 py-0.5 rounded-full whitespace-nowrap flex items-center gap-1"
                      style={{ background: status.bg, color: status.color }}
                    >
                      {int.status === 'connected' && <Check className="w-2.5 h-2.5" />}
                      {int.status === 'partial' && <AlertCircle className="w-2.5 h-2.5" />}
                      {status.label}
                    </span>
                  </div>
                  {int.badge && <p className="text-[10px] text-muted-foreground mt-0.5">{int.badge}</p>}
                </div>
              </div>
              <p className="text-xs text-muted-foreground mb-4 leading-relaxed">{int.description}</p>
              <button
                className={`w-full text-xs font-medium py-2 rounded-lg transition-colors ${
                  int.status === 'connected'
                    ? 'surface-2 hover:border-primary/30'
                    : 'bg-primary text-primary-foreground hover:opacity-90'
                }`}
              >
                {int.cta}
              </button>
            </div>
          );
        })}
      </div>

      {/* Netlify account info */}
      <div className="surface rounded-xl p-5">
        <div className="flex items-start justify-between mb-3">
          <h2 className="text-sm font-semibold flex items-center gap-2">
            <Cloud className="w-4 h-4 text-[#00C7B7]" /> Cuenta Netlify
          </h2>
          <span className="text-[10px] bg-[#00C7B7]/15 text-[#00C7B7] px-2 py-0.5 rounded-full font-medium">
            Plan Free
          </span>
        </div>
        <div className="grid sm:grid-cols-3 gap-3 text-xs">
          <div className="surface-2 rounded-lg p-3">
            <p className="text-muted-foreground text-[10px] uppercase">Sitio</p>
            <p className="font-medium mt-1">fusionyfogon.com</p>
          </div>
          <div className="surface-2 rounded-lg p-3">
            <p className="text-muted-foreground text-[10px] uppercase">Functions este mes</p>
            <p className="font-medium mt-1">12.4k / 125k</p>
          </div>
          <div className="surface-2 rounded-lg p-3">
            <p className="text-muted-foreground text-[10px] uppercase">Bandwidth</p>
            <p className="font-medium mt-1">2.1 GB / 100 GB</p>
          </div>
        </div>
      </div>
    </div>
  );
}
