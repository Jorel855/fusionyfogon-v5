'use client';

import { useState } from 'react';
import { Plus, Eye, EyeOff, Edit, Trash2, Calendar, ExternalLink, X, Check, Layout } from 'lucide-react';

type Pestana = {
  id: string;
  titulo: string;
  visible: boolean;
  programaActivo: boolean;
  contenido: string;
  tieneYoutube: boolean;
  tieneBoton: boolean;
};

const PESTANAS_INICIALES: Pestana[] = [
  {
    id: 'p1',
    titulo: 'Promo Halloween',
    visible: false,
    programaActivo: true,
    contenido: 'Menú especial de Halloween con ahumados temáticos',
    tieneYoutube: false,
    tieneBoton: true,
  },
  {
    id: 'p2',
    titulo: 'Eventos privados',
    visible: true,
    programaActivo: false,
    contenido: 'Organiza tu evento en nuestra finca',
    tieneYoutube: true,
    tieneBoton: true,
  },
];

export function PestanasView() {
  const [pestanas, setPestanas] = useState(PESTANAS_INICIALES);
  const [editing, setEditing] = useState<Pestana | null>(null);

  const toggleVisible = (id: string) => {
    setPestanas((p) => p.map((x) => (x.id === id ? { ...x, visible: !x.visible } : x)));
  };

  const visiblesCount = pestanas.filter((p) => p.visible).length;

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Layout className="w-6 h-6 text-primary" /> Pestañas extras
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            {pestanas.length} pestañas · {visiblesCount} visibles · {pestanas.length - visiblesCount} ocultas
          </p>
        </div>
        <button className="bg-primary text-primary-foreground text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90 flex items-center gap-2">
          <Plus className="w-4 h-4" /> Crear pestaña
        </button>
      </div>

      {/* Info banner */}
      <div className="surface rounded-xl p-4 flex items-start gap-3 text-xs">
        <Layout className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
        <span className="text-muted-foreground">
          Las pestañas extras son secciones personalizadas del home con contenido libre: título, texto, imagen, video
          de YouTube y botón de enlace. Úsalas para promociones, eventos, blog, galería especial, etc.
        </span>
      </div>

      {/* Lista de pestañas */}
      <div className="space-y-2">
        {pestanas.length === 0 && (
          <div className="surface rounded-xl p-8 text-center text-sm text-muted-foreground">
            No hay pestañas extras. Click en "Crear pestaña" para empezar.
          </div>
        )}
        {pestanas.map((p) => (
          <div key={p.id} className={`surface rounded-xl p-4 ${!p.visible ? 'opacity-60' : ''}`}>
            <div className="flex items-center gap-3">
              <div
                className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  p.visible ? 'bg-primary/15 text-primary' : 'surface text-muted-foreground'
                }`}
              >
                <Layout className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="text-sm font-medium">{p.titulo}</p>
                  {p.visible ? (
                    <span className="text-[9px] bg-emerald-500/15 text-emerald-400 px-1.5 py-0.5 rounded-full font-medium flex items-center gap-1">
                      <Eye className="w-2.5 h-2.5" /> Visible
                    </span>
                  ) : (
                    <span className="text-[9px] surface text-muted-foreground px-1.5 py-0.5 rounded-full font-medium flex items-center gap-1">
                      <EyeOff className="w-2.5 h-2.5" /> Oculta
                    </span>
                  )}
                  {p.programaActivo && (
                    <span className="text-[9px] bg-blue-500/15 text-blue-400 px-1.5 py-0.5 rounded-full font-medium flex items-center gap-1">
                      <Calendar className="w-2.5 h-2.5" /> Programada
                    </span>
                  )}
                  {p.tieneYoutube && (
                    <span className="text-[9px] bg-red-500/15 text-red-400 px-1.5 py-0.5 rounded-full font-medium">
                      ▶ YouTube
                    </span>
                  )}
                  {p.tieneBoton && (
                    <span className="text-[9px] surface text-muted-foreground px-1.5 py-0.5 rounded-full font-medium">
                      🔗 Botón
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-muted-foreground mt-0.5 line-clamp-1">{p.contenido}</p>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setEditing(p)}
                  className="surface p-1.5 rounded-md hover:text-primary"
                  title="Editar"
                >
                  <Edit className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => toggleVisible(p.id)}
                  className={`p-1.5 rounded-md ${
                    p.visible ? 'surface hover:text-primary' : 'bg-amber-500/15 text-amber-400'
                  }`}
                  title={p.visible ? 'Ocultar' : 'Mostrar'}
                >
                  {p.visible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                </button>
                <button
                  className="surface p-1.5 rounded-md hover:text-red-400"
                  title="Eliminar"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Editor modal */}
      {editing && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="surface rounded-2xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-base font-semibold">Editar pestaña</h3>
              <button onClick={() => setEditing(null)} className="text-muted-foreground hover:text-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <label className="block">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Título</span>
                <input
                  type="text"
                  defaultValue={editing.titulo}
                  className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
                />
              </label>

              <label className="block">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Contenido</span>
                <textarea
                  defaultValue={editing.contenido}
                  rows={4}
                  className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm resize-none focus:outline-none focus:border-primary/40"
                />
              </label>

              <div className="grid grid-cols-2 gap-3">
                <label className="block">
                  <span className="text-[10px] uppercase tracking-wider text-muted-foreground">URL YouTube (opcional)</span>
                  <input
                    type="text"
                    placeholder="https://youtube.com/watch?v=..."
                    className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
                  />
                </label>
                <label className="block">
                  <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Texto botón enlace</span>
                  <input
                    type="text"
                    placeholder="Ver más"
                    className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
                  />
                </label>
              </div>

              {/* Programación */}
              <div className="surface-2 rounded-lg p-3">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1">
                  <Calendar className="w-3 h-3" /> Programación temporal
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <label className="block">
                    <span className="text-[10px] text-muted-foreground">Mostrar desde</span>
                    <input
                      type="datetime-local"
                      className="surface-2 w-full mt-1 px-2 py-1.5 rounded-md text-xs focus:outline-none focus:border-primary/40"
                    />
                  </label>
                  <label className="block">
                    <span className="text-[10px] text-muted-foreground">Ocultar el</span>
                    <input
                      type="datetime-local"
                      className="surface-2 w-full mt-1 px-2 py-1.5 rounded-md text-xs focus:outline-none focus:border-primary/40"
                    />
                  </label>
                </div>
              </div>

              <label className="flex items-center gap-2 text-xs">
                <input type="checkbox" defaultChecked={editing.tieneBoton} className="w-3.5 h-3.5" />
                <span>Abrir enlace en pestaña nueva</span>
              </label>
            </div>

            <div className="flex gap-2 mt-5">
              <button
                onClick={() => setEditing(null)}
                className="flex-1 surface-2 text-sm py-2.5 rounded-lg hover:border-primary/30"
              >
                Cancelar
              </button>
              <button
                onClick={() => setEditing(null)}
                className="flex-1 bg-primary text-primary-foreground text-sm font-medium py-2.5 rounded-lg hover:opacity-90 flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" /> Guardar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
