'use client';

import { Search, Download, RefreshCw, MoreVertical, Clock, MapPin, Phone, MessageCircle, Check, Send, Loader2 } from 'lucide-react';
import { usePedidos, type Pedido } from '@/hooks/use-pedidos';

const COLUMNAS: { key: Pedido['estado']; label: string; color: string; bg: string }[] = [
  { key: 'Pendiente', label: 'Pendiente', color: '#EF4444', bg: 'rgba(239, 68, 68, 0.08)' },
  { key: 'Confirmado', label: 'Confirmado', color: '#F59E0B', bg: 'rgba(245, 158, 11, 0.08)' },
  { key: 'Preparacion', label: 'En preparación', color: '#3B82F6', bg: 'rgba(59, 130, 246, 0.08)' },
  { key: 'Listo', label: 'Listo', color: '#10B981', bg: 'rgba(16, 185, 129, 0.08)' },
  { key: 'Entregado', label: 'Entregado', color: '#A8978A', bg: 'rgba(168, 151, 138, 0.08)' },
];

const WHATSAPP_STATUS: Record<string, 'sent' | 'delivered' | 'read' | 'pending'> = {
  // demo: todos los pedidos reales que vengan se marcan como "delivered"
};

export function PedidosView() {
  const { pedidos, loading, error, refetch, cambiarEstado } = usePedidos();
  const search = '';

  const filtered = pedidos.filter((p) =>
    [p.cliente, p.codigo, p.detalle, p.direccion || '']
      .some((s) => s.toLowerCase().includes(search.toLowerCase()))
  );

  const mover = async (id: string, nuevoEstado: Pedido['estado']) => {
    await cambiarEstado(id, nuevoEstado);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 text-primary animate-spin" />
        <span className="ml-2 text-sm text-muted-foreground">Cargando pedidos reales...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="surface rounded-xl p-6 text-center">
        <p className="text-sm text-red-400 mb-3">Error: {error}</p>
        <button onClick={refetch} className="bg-primary text-primary-foreground text-sm px-4 py-2 rounded-lg">
          Reintentar
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Pedidos</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {pedidos.length} pedidos · {pedidos.filter((p) => p.estado === 'Pendiente').length} pendientes ·{' '}
            <span className="text-emerald-400">● datos en vivo desde DB</span>
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={refetch} className="surface-2 p-2 rounded-lg hover:border-primary/30" title="Actualizar">
            <RefreshCw className="w-4 h-4" />
          </button>
          <button className="surface-2 p-2 rounded-lg hover:border-primary/30" title="Exportar CSV">
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Banner: datos reales */}
      <div className="surface rounded-xl p-4 flex items-start gap-3 text-xs bg-emerald-500/5 border-emerald-500/20">
        <div className="w-8 h-8 rounded-lg bg-emerald-500/15 flex items-center justify-center flex-shrink-0">
          <Check className="w-4 h-4 text-emerald-400" />
        </div>
        <div>
          <p className="text-emerald-400 font-medium">Conectado a base de datos real (Prisma + SQLite)</p>
          <p className="text-muted-foreground mt-0.5">
            Estos pedidos vienen de la API <code className="text-primary">/api/pedidos</code>. Cuando cambias el estado,
            se actualiza en la DB y se registra en el audit log. En producción (Netlify) usará Postgres en vez de SQLite.
          </p>
        </div>
      </div>

      {/* Kanban */}
      <div className="flex gap-4 overflow-x-auto pb-4 -mx-4 px-4 lg:-mx-8 lg:px-8">
        {COLUMNAS.map((col) => {
          const items = filtered.filter((p) => p.estado === col.key);
          const total = items.reduce((a, b) => a + b.total, 0);
          return (
            <div key={col.key} className="flex-shrink-0 w-72 surface rounded-xl p-3">
              <div className="flex items-center justify-between mb-3 px-1">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full" style={{ background: col.color }} />
                  <span className="text-sm font-semibold">{col.label}</span>
                  <span className="text-xs text-muted-foreground surface-2 px-1.5 py-0.5 rounded-full">
                    {items.length}
                  </span>
                </div>
                {items.length > 0 && (
                  <span className="text-[10px] text-muted-foreground">
                    ${total.toLocaleString('es-CO')}
                  </span>
                )}
              </div>
              <div
                className="space-y-2 min-h-[120px] rounded-lg p-1 transition-colors"
                style={{ background: col.bg }}
              >
                {items.length === 0 && (
                  <p className="text-xs text-muted-foreground text-center py-6 opacity-60">Sin pedidos</p>
                )}
                {items.map((p) => (
                  <div key={p.id} className="kanban-card surface-2 rounded-lg p-3 cursor-pointer">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg brand-gradient flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0">
                          {p.cliente.charAt(0)}
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-medium truncate">{p.cliente}</p>
                          <p className="text-[10px] text-muted-foreground">#{p.codigo}</p>
                        </div>
                      </div>
                      <button className="text-muted-foreground hover:text-foreground">
                        <MoreVertical className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <p className="text-xs text-foreground mb-2 line-clamp-2">{p.detalle}</p>

                    <div className="space-y-1 mb-2">
                      {p.direccion && (
                        <p className="text-[10px] text-muted-foreground flex items-start gap-1">
                          <MapPin className="w-3 h-3 mt-0.5 flex-shrink-0" />
                          <span className="truncate">{p.direccion}</span>
                        </p>
                      )}
                      {p.telefono && (
                        <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                          <Phone className="w-3 h-3" /> {p.telefono}
                        </p>
                      )}
                      <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {new Date(p.fecha).toLocaleString('es-CO')}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-border">
                      <span className="text-sm font-bold text-primary">
                        ${p.total.toLocaleString('es-CO')}
                      </span>
                      <WhatsAppBadge status={p.whatsappLeido ? 'read' : p.whatsappEnviado ? 'delivered' : 'pending'} />
                    </div>

                    {col.key !== 'Entregado' && (
                      <button
                        onClick={() => {
                          const idx = COLUMNAS.findIndex((c) => c.key === col.key);
                          if (idx < COLUMNAS.length - 1) {
                            mover(p.id, COLUMNAS[idx + 1].key);
                          }
                        }}
                        className="w-full mt-2 text-[11px] font-medium py-1.5 rounded-md hover:bg-primary/10 hover:text-primary transition-colors border border-border flex items-center justify-center gap-1.5"
                      >
                        <Send className="w-3 h-3" /> Mover a {COLUMNAS[COLUMNAS.findIndex((c) => c.key === col.key) + 1]?.label} · notifica WhatsApp
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <div className="surface rounded-xl p-4 flex items-center gap-3 text-xs text-muted-foreground">
        <span className="w-2 h-2 rounded-full bg-emerald-500 pulse-live" />
        Sincronización en tiempo real activa · Pedidos persistidos en SQLite · Cambios registrados en audit log
      </div>
    </div>
  );
}

function WhatsAppBadge({ status }: { status: 'sent' | 'delivered' | 'read' | 'pending' }) {
  const config = {
    sent: { label: 'Enviado', color: '#A8978A', bg: 'rgba(168,151,138,0.15)' },
    delivered: { label: 'Entregado', color: '#3B82F6', bg: 'rgba(59,130,246,0.15)' },
    read: { label: 'Leído', color: '#10B981', bg: 'rgba(16,185,129,0.15)' },
    pending: { label: 'Pendiente', color: '#F59E0B', bg: 'rgba(245,158,11,0.15)' },
  };
  const c = config[status];
  return (
    <span
      className="flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded-full"
      style={{ background: c.bg, color: c.color }}
      title={`WhatsApp: ${c.label}`}
    >
      <MessageCircle className="w-2.5 h-2.5" />
      {status === 'read' && <Check className="w-2.5 h-2.5 -ml-1.5" />}
      {c.label}
    </span>
  );
}
