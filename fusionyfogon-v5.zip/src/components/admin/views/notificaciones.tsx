'use client';

import { useState } from 'react';
import {
  MessageCircle,
  Send,
  Check,
  Clock,
  AlertCircle,
  TestTube,
  Smartphone,
  ArrowRight,
  Edit3,
  Save,
  X,
  Zap,
  RotateCcw,
} from 'lucide-react';

type Estado = 'Pendiente' | 'Confirmado' | 'Preparacion' | 'Listo' | 'Entregado' | 'Cancelado';

const ESTADOS: { key: Estado; color: string; bg: string; emoji: string; notifica: boolean }[] = [
  { key: 'Pendiente', color: '#EF4444', bg: 'rgba(239,68,68,0.12)', emoji: '🔴', notifica: true },
  { key: 'Confirmado', color: '#F59E0B', bg: 'rgba(245,158,11,0.12)', emoji: '🟡', notifica: true },
  { key: 'Preparacion', color: '#3B82F6', bg: 'rgba(59,130,246,0.12)', emoji: '🔵', notifica: true },
  { key: 'Listo', color: '#10B981', bg: 'rgba(16,185,129,0.12)', emoji: '🟢', notifica: true },
  { key: 'Entregado', color: '#A8978A', bg: 'rgba(168,151,138,0.12)', emoji: '⚫', notifica: false },
  { key: 'Cancelado', color: '#DC2626', bg: 'rgba(220,38,38,0.12)', emoji: '❌', notifica: true },
];

const PLANTILLAS_INICIALES: Record<Estado, { titulo: string; cuerpo: string; activa: boolean }> = {
  Pendiente: {
    titulo: 'Pedido recibido',
    cuerpo: '¡Hola {{nombre}}! 👋 Recibimos tu pedido #{{id}} por {{total}}. Lo estamos revisando y te confirmamos en breve. ¡Gracias por elegirnos! 🔥',
    activa: true,
  },
  Confirmado: {
    titulo: 'Pedido confirmado',
    cuerpo: '¡Listo {{nombre}}! ✅ Tu pedido #{{id}} está confirmado. Lo preparamos con todo el cariño. Tiempo estimado: {{tiempo}}. ¡Te avisamos cuando esté listo!',
    activa: true,
  },
  Preparacion: {
    titulo: 'En preparación',
    cuerpo: '{{nombre}}, tu pedido #{{id}} ya está en el fogón 🔥 ¡Humeando rico! Te avisamos cuando esté listo para recoger/entregar.',
    activa: true,
  },
  Listo: {
    titulo: 'Pedido listo',
    cuerpo: '¡Tu pedido #{{id}} está listo {{nombre}}! 🎉 Puedes pasar a recogerlo o está en camino. ¡Gracias! 🔥',
    activa: true,
  },
  Entregado: {
    titulo: 'Pedido entregado',
    cuerpo: '¡Esperamos que lo disfrutes {{nombre}}! 😊 ¿Nos dejas una reseña en Google? {{link_resena}} ¡Vuelve pronto!',
    activa: false,
  },
  Cancelado: {
    titulo: 'Pedido cancelado',
    cuerpo: '{{nombre}}, lamentablemente tuvimos que cancelar tu pedido #{{id}}. Motivo: {{motivo}}. Para reembolso o dudas, escríbenos. Disculpa las molestias.',
    activa: true,
  },
};

const VARIABLES = [
  { tag: '{{nombre}}', desc: 'Nombre del cliente' },
  { tag: '{{id}}', desc: 'ID corto del pedido' },
  { tag: '{{total}}', desc: 'Total formateado (COP)' },
  { tag: '{{detalle}}', desc: 'Lista de platos y cantidades' },
  { tag: '{{tiempo}}', desc: 'Tiempo estimado (editable)' },
  { tag: '{{direccion}}', desc: 'Dirección de entrega' },
  { tag: '{{motivo}}', desc: 'Motivo de cancelación' },
  { tag: '{{link_resena}}', desc: 'Link a Google Reviews' },
];

export function NotificacionesView() {
  const [plantillas, setPlantillas] = useState(PLANTILLAS_INICIALES);
  const [editando, setEditando] = useState<Estado | null>(null);
  const [testEnviado, setTestEnviado] = useState<Estado | null>(null);
  const [numeroTest, setNumeroTest] = useState('+57 350 802 9292');

  const toggleActiva = (estado: Estado) => {
    setPlantillas({
      ...plantillas,
      [estado]: { ...plantillas[estado], activa: !plantillas[estado].activa },
    });
  };

  const guardarPlantilla = (estado: Estado, cuerpo: string) => {
    setPlantillas({
      ...plantillas,
      [estado]: { ...plantillas[estado], cuerpo },
    });
    setEditando(null);
  };

  const enviarTest = (estado: Estado) => {
    setTestEnviado(estado);
    setTimeout(() => setTestEnviado(null), 3000);
  };

  const renderPreview = (cuerpo: string) => {
    return cuerpo
      .replace('{{nombre}}', 'María Camacho')
      .replace('{{id}}', '#1023')
      .replace('{{total}}', '$49.000')
      .replace('{{detalle}}', '1x Lomo ahumado, 2x Chorizo')
      .replace('{{tiempo}}', '30 minutos')
      .replace('{{direccion}}', 'Calle 45 # 23-18, Bucaramanga')
      .replace('{{motivo}}', 'Sin stock del producto')
      .replace('{{link_resena}}', 'g.page/r/fusion-fogon/review');
  };

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <MessageCircle className="w-6 h-6 text-emerald-400" />
            Notificaciones WhatsApp
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Mensajes automáticos a clientes cuando cambia el estado de su pedido · WhatsApp Cloud API
          </p>
        </div>
        <span className="text-[10px] bg-emerald-500/15 text-emerald-400 px-3 py-1.5 rounded-lg font-medium flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 pulse-live" />
          Conectado · 247 mensajes este mes
        </span>
      </div>

      {/* Flow diagram */}
      <div className="surface rounded-xl p-5">
        <h2 className="text-sm font-semibold mb-4">Cómo funciona el flujo</h2>
        <div className="flex items-center gap-2 overflow-x-auto pb-2">
          <div className="surface-2 rounded-lg p-3 flex-shrink-0 min-w-[140px]">
            <Smartphone className="w-5 h-5 text-primary mb-1" />
            <p className="text-xs font-medium">Cliente pide</p>
            <p className="text-[10px] text-muted-foreground">en la web</p>
          </div>
          <ArrowRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
          <div className="surface-2 rounded-lg p-3 flex-shrink-0 min-w-[140px]">
            <Clock className="w-5 h-5 text-red-400 mb-1" />
            <p className="text-xs font-medium">Pedido PENDIENTE</p>
            <p className="text-[10px] text-muted-foreground">→ 🔔 WhatsApp al cliente</p>
          </div>
          <ArrowRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
          <div className="surface-2 rounded-lg p-3 flex-shrink-0 min-w-[140px]">
            <Check className="w-5 h-5 text-amber-400 mb-1" />
            <p className="text-xs font-medium">Tú CONFIRMAS</p>
            <p className="text-[10px] text-muted-foreground">→ 🔔 WhatsApp al cliente</p>
          </div>
          <ArrowRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
          <div className="surface-2 rounded-lg p-3 flex-shrink-0 min-w-[140px]">
            <Zap className="w-5 h-5 text-blue-400 mb-1" />
            <p className="text-xs font-medium">EN PREPARACIÓN</p>
            <p className="text-[10px] text-muted-foreground">→ 🔔 WhatsApp al cliente</p>
          </div>
          <ArrowRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
          <div className="surface-2 rounded-lg p-3 flex-shrink-0 min-w-[140px]">
            <Check className="w-5 h-5 text-emerald-400 mb-1" />
            <p className="text-xs font-medium">LISTO</p>
            <p className="text-[10px] text-muted-foreground">→ 🔔 WhatsApp al cliente</p>
          </div>
        </div>
        <div className="mt-3 p-3 surface-2 rounded-lg flex items-start gap-2 text-xs">
          <Zap className="w-3.5 h-3.5 text-primary mt-0.5 flex-shrink-0" />
          <span className="text-muted-foreground">
            <strong className="text-foreground">Automático:</strong> cuando TÚ cambias el estado del pedido en el panel,
            el sistema envía el WhatsApp al cliente en segundos. No tienes que escribir nada.
          </span>
        </div>
      </div>

      {/* Plantillas por estado */}
      <div className="surface rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-semibold">Plantillas por estado</h2>
          <span className="text-[10px] text-muted-foreground">
            {Object.values(plantillas).filter((p) => p.activa).length} de {ESTADOS.length} activas
          </span>
        </div>

        <div className="space-y-2">
          {ESTADOS.map((est) => {
            const p = plantillas[est.key];
            const isEditing = editando === est.key;
            const isTestSent = testEnviado === est.key;
            return (
              <div
                key={est.key}
                className="surface-2 rounded-lg overflow-hidden"
                style={{ borderLeft: `3px solid ${est.color}` }}
              >
                <div className="p-3 flex items-center gap-3">
                  <span className="text-lg">{est.emoji}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium">{est.key}</p>
                      <span
                        className="text-[9px] px-1.5 py-0.5 rounded-full font-medium"
                        style={{ background: est.bg, color: est.color }}
                      >
                        {p.titulo}
                      </span>
                      {p.activa ? (
                        <span className="text-[9px] bg-emerald-500/15 text-emerald-400 px-1.5 py-0.5 rounded-full font-medium flex items-center gap-1">
                          <Check className="w-2.5 h-2.5" /> Activa
                        </span>
                      ) : (
                        <span className="text-[9px] surface text-muted-foreground px-1.5 py-0.5 rounded-full font-medium">
                          Pausada
                        </span>
                      )}
                    </div>
                    {!isEditing && (
                      <p className="text-[11px] text-muted-foreground mt-1 line-clamp-1">{p.cuerpo}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => toggleActiva(est.key)}
                      className={`w-9 h-5 rounded-full transition-colors relative flex-shrink-0 ${
                        p.activa ? 'bg-emerald-500' : 'bg-muted'
                      }`}
                    >
                      <span
                        className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${
                          p.activa ? 'translate-x-4' : 'translate-x-0.5'
                        }`}
                      />
                    </button>
                    <button
                      onClick={() => setEditando(isEditing ? null : est.key)}
                      className="surface p-1.5 rounded-md hover:text-primary"
                      title="Editar"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => enviarTest(est.key)}
                      className="surface p-1.5 rounded-md hover:text-primary"
                      title="Enviar test"
                    >
                      <TestTube className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Test enviado feedback */}
                {isTestSent && (
                  <div className="px-3 pb-2">
                    <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-md p-2 flex items-center gap-2 text-[11px] text-emerald-400">
                      <Check className="w-3 h-3" />
                      Mensaje de prueba enviado a {numeroTest} · revisa tu WhatsApp
                    </div>
                  </div>
                )}

                {/* Editor expandido */}
                {isEditing && (
                  <div className="p-3 pt-0 space-y-3">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                          Cuerpo del mensaje
                        </span>
                        <span className="text-[10px] text-muted-foreground">
                          {p.cuerpo.length} caracteres
                        </span>
                      </div>
                      <textarea
                        defaultValue={p.cuerpo}
                        id={`textarea-${est.key}`}
                        rows={3}
                        className="surface-2 w-full px-3 py-2 rounded-lg text-xs resize-none focus:outline-none focus:border-primary/40"
                      />
                    </div>

                    {/* Variables */}
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">
                        Variables disponibles (click para insertar)
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {VARIABLES.map((v) => (
                          <button
                            key={v.tag}
                            onClick={() => {
                              const ta = document.getElementById(`textarea-${est.key}`) as HTMLTextAreaElement;
                              if (ta) {
                                const start = ta.selectionStart;
                                const end = ta.selectionEnd;
                                const newText = ta.value.substring(0, start) + v.tag + ta.value.substring(end);
                                ta.value = newText;
                                ta.focus();
                                ta.setSelectionRange(start + v.tag.length, start + v.tag.length);
                              }
                            }}
                            className="text-[10px] surface px-2 py-1 rounded-md hover:bg-primary/10 hover:text-primary font-mono"
                            title={v.desc}
                          >
                            {v.tag}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Preview WhatsApp */}
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2">
                        Preview en WhatsApp
                      </p>
                      <div className="bg-[#0a1a14] rounded-lg p-3 max-w-xs">
                        <div className="bg-[#005c4b] text-white text-xs p-2.5 rounded-lg rounded-tr-none relative">
                          <p className="text-[10px] text-emerald-200 font-medium mb-1">{p.titulo}</p>
                          <p className="whitespace-pre-wrap">{renderPreview(p.cuerpo)}</p>
                          <p className="text-[9px] text-emerald-200/70 text-right mt-1">
                            3:25 PM ✓✓
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Acciones */}
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          const ta = document.getElementById(`textarea-${est.key}`) as HTMLTextAreaElement;
                          if (ta) guardarPlantilla(est.key, ta.value);
                        }}
                        className="bg-primary text-primary-foreground text-xs font-medium px-3 py-1.5 rounded-lg hover:opacity-90 flex items-center gap-1.5"
                      >
                        <Save className="w-3.5 h-3.5" /> Guardar plantilla
                      </button>
                      <button
                        onClick={() => setEditando(null)}
                        className="surface-2 text-xs px-3 py-1.5 rounded-lg hover:border-primary/30"
                      >
                        Cancelar
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Configuración avanzada */}
      <div className="grid lg:grid-cols-2 gap-4">
        {/* Número de prueba */}
        <div className="surface rounded-xl p-5">
          <h2 className="text-sm font-semibold mb-3 flex items-center gap-2">
            <TestTube className="w-4 h-4" /> Número de pruebas
          </h2>
          <p className="text-xs text-muted-foreground mb-3">
            Los mensajes de prueba se envían a este número (puedes usar tu propio celular para probar)
          </p>
          <input
            type="tel"
            value={numeroTest}
            onChange={(e) => setNumeroTest(e.target.value)}
            className="surface-2 w-full px-3 py-2 rounded-lg text-sm font-mono focus:outline-none focus:border-primary/40"
          />
          <div className="mt-3 flex gap-2">
            <button className="flex-1 bg-primary text-primary-foreground text-xs font-medium py-2 rounded-lg hover:opacity-90 flex items-center justify-center gap-1.5">
              <Send className="w-3.5 h-3.5" /> Enviar todos los tests
            </button>
            <button className="surface-2 text-xs px-3 py-2 rounded-lg hover:border-primary/30 flex items-center gap-1.5">
              <RotateCcw className="w-3.5 h-3.5" /> Reset
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="surface rounded-xl p-5">
          <h2 className="text-sm font-semibold mb-3">Estadísticas del mes</h2>
          <div className="grid grid-cols-2 gap-3">
            <div className="surface-2 rounded-lg p-3">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Enviados</p>
              <p className="text-2xl font-bold text-emerald-400">247</p>
              <p className="text-[10px] text-muted-foreground">de 1000 gratis</p>
            </div>
            <div className="surface-2 rounded-lg p-3">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Entregados</p>
              <p className="text-2xl font-bold">241</p>
              <p className="text-[10px] text-emerald-400">97.6%</p>
            </div>
            <div className="surface-2 rounded-lg p-3">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Leídos</p>
              <p className="text-2xl font-bold">198</p>
              <p className="text-[10px] text-muted-foreground">82.1%</p>
            </div>
            <div className="surface-2 rounded-lg p-3">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Costo mes</p>
              <p className="text-2xl font-bold text-primary">$0</p>
              <p className="text-[10px] text-muted-foreground">Free tier</p>
            </div>
          </div>
        </div>
      </div>

      {/* Info banner */}
      <div className="surface rounded-xl p-4 flex items-start gap-3 text-xs">
        <div className="w-8 h-8 rounded-lg bg-emerald-500/15 flex items-center justify-center flex-shrink-0">
          <MessageCircle className="w-4 h-4 text-emerald-400" />
        </div>
        <div className="text-muted-foreground">
          <strong className="text-foreground">WhatsApp Cloud API activo.</strong> Mensajes ilimitados hasta 1000
          conversaciones/mes (gratis). Después: ~$0.025 por conversación iniciada. Las plantillas ya están aprobadas
          por Meta. El cliente también puede responder al mensaje y te llega al panel → pestaña &quot;Bandeja de
          entrada&quot; (próximamente).
        </div>
      </div>
    </div>
  );
}
