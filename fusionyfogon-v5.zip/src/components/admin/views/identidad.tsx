'use client';

import { useState } from 'react';
import { Check, AlertTriangle, Upload, Type, Palette } from 'lucide-react';

const PALETA = [
  { nombre: 'Primario (Naranja CTA)', valor: '#CC6600' },
  { nombre: 'Secundario (Marrón)', valor: '#8B4513' },
  { nombre: 'Acento (Amarillo)', valor: '#FFD700' },
  { nombre: 'Fondo (Crema oscuro)', valor: '#12100E' },
  { nombre: 'Superficie', valor: '#1B1714' },
  { nombre: 'Texto principal', valor: '#F5EFE6' },
];

const TIPOGRAFIAS = {
  titulos: ['Playfair Display', 'Cormorant Garamond', 'Bebas Neue', 'Inter'],
  cuerpo: ['Inter', 'DM Sans', 'Geist Sans', 'Nunito'],
  acentos: ['Caveat', 'Pacifico', 'Dancing Script', 'Lobster'],
};

export function IdentidadView() {
  const [paleta, setPaleta] = useState(PALETA);
  const [tipografia, setTipografia] = useState({ titulos: 'Playfair Display', cuerpo: 'Inter', acentos: 'Caveat' });
  const [idioma, setIdioma] = useState('es-CO');
  const [moneda, setMoneda] = useState('COP');

  const contrast = (hex: string) => {
    // Simplificado para demo
    if (hex === '#CC6600') return { ratio: '3.84:1', status: 'warn' };
    if (hex === '#F5EFE6') return { ratio: '18.98:1', status: 'ok' };
    if (hex === '#8B4513') return { ratio: '8.24:1', status: 'ok' };
    return { ratio: '4.93:1', status: 'ok' };
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Identidad visual</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Define la marca del negocio — esta configuración hace la plantilla reutilizable para cualquier emprendimiento
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        {/* Datos del negocio */}
        <div className="surface rounded-xl p-5 lg:col-span-2 space-y-4">
          <h2 className="text-sm font-semibold">Datos del negocio</h2>

          <div className="grid sm:grid-cols-2 gap-3">
            <label className="block">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Nombre</span>
              <input
                type="text"
                defaultValue="FUSIÓN Y FOGÓN"
                className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm font-semibold focus:outline-none focus:border-primary/40"
              />
            </label>
            <label className="block">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Tagline</span>
              <input
                type="text"
                defaultValue="Sabores que unen culturas"
                className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
              />
            </label>
          </div>

          <div className="grid sm:grid-cols-3 gap-3">
            <label className="block">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Idioma</span>
              <select
                value={idioma}
                onChange={(e) => setIdioma(e.target.value)}
                className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
              >
                <option value="es-CO">Español (Colombia)</option>
                <option value="es-MX">Español (México)</option>
                <option value="en-US">English (US)</option>
                <option value="pt-BR">Português (Brasil)</option>
              </select>
            </label>
            <label className="block">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Moneda</span>
              <select
                value={moneda}
                onChange={(e) => setMoneda(e.target.value)}
                className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
              >
                <option value="COP">Peso colombiano (COP)</option>
                <option value="MXN">Peso mexicano (MXN)</option>
                <option value="USD">Dólar (USD)</option>
                <option value="BRL">Real (BRL)</option>
              </select>
            </label>
            <label className="block">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Zona horaria</span>
              <select className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40">
                <option>America/Bogota</option>
                <option>America/Mexico_City</option>
                <option>America/Sao_Paulo</option>
              </select>
            </label>
          </div>

          {/* Logo & favicon */}
          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Logo</span>
              <div className="mt-1 surface-2 rounded-lg p-3 flex items-center gap-3">
                <div className="w-14 h-14 rounded-lg brand-gradient flex items-center justify-center text-white text-2xl">
                  🔥
                </div>
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">logo-fyf.png · 8.2 KB</p>
                  <button className="text-xs text-primary hover:underline mt-1 flex items-center gap-1">
                    <Upload className="w-3 h-3" /> Cambiar
                  </button>
                </div>
              </div>
            </div>
            <div>
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Favicon</span>
              <div className="mt-1 surface-2 rounded-lg p-3 flex items-center gap-3">
                <div className="w-14 h-14 rounded-lg surface flex items-center justify-center text-2xl">
                  🔥
                </div>
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">favicon.ico · 4.1 KB</p>
                  <button className="text-xs text-primary hover:underline mt-1 flex items-center gap-1">
                    <Upload className="w-3 h-3" /> Cambiar
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Preview */}
        <div className="surface rounded-xl p-5">
          <h2 className="text-sm font-semibold mb-3">Vista previa</h2>
          <div className="aspect-square rounded-xl surface-2 flex flex-col items-center justify-center p-6 text-center">
            <div className="w-20 h-20 rounded-2xl brand-gradient flex items-center justify-center text-4xl mb-3 brand-glow">
              🔥
            </div>
            <p
              className="text-xl font-bold"
              style={{ fontFamily: tipografia.titulos, color: paleta[5].valor }}
            >
              FUSIÓN Y FOGÓN
            </p>
            <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: tipografia.acentos }}>
              Sabores que unen culturas
            </p>
            <button
              className="mt-4 text-xs font-medium px-4 py-2 rounded-lg text-white"
              style={{ background: paleta[0].valor }}
            >
              VER MENÚ
            </button>
          </div>
          <p className="text-[10px] text-muted-foreground mt-3 text-center">
            Así verán los clientes tu marca en la PWA
          </p>
        </div>
      </div>

      {/* Paleta */}
      <div className="surface rounded-xl p-5">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold flex items-center gap-2">
            <Palette className="w-4 h-4" /> Paleta de colores
          </h2>
          <button className="text-xs text-muted-foreground hover:text-foreground">↺ Restaurar oficiales</button>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {paleta.map((color, i) => {
            const c = contrast(color.valor);
            return (
              <div key={i} className="surface-2 rounded-lg p-3 flex items-center gap-3">
                <div
                  className="w-12 h-12 rounded-lg border border-border flex-shrink-0"
                  style={{ background: color.valor }}
                />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">{color.nombre}</p>
                  <input
                    type="text"
                    value={color.valor}
                    onChange={(e) => {
                      const nueva = [...paleta];
                      nueva[i] = { ...nueva[i], valor: e.target.value };
                      setPaleta(nueva);
                    }}
                    className="bg-transparent text-[11px] font-mono text-muted-foreground focus:outline-none w-full"
                  />
                  <p
                    className={`text-[9px] flex items-center gap-1 ${
                      c.status === 'ok' ? 'text-emerald-400' : 'text-amber-400'
                    }`}
                  >
                    {c.status === 'ok' ? <Check className="w-2.5 h-2.5" /> : <AlertTriangle className="w-2.5 h-2.5" />}
                    Contraste {c.ratio}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
        <div className="mt-3 p-3 surface-2 rounded-lg flex items-center gap-2 text-xs">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-muted-foreground">
            <strong className="text-amber-400">WCAG 2.1 AA:</strong> el texto sobre el naranja CTA tiene contraste 3.84:1
            (mínimo 4.5:1). Considera usar texto negro o un naranja más oscuro.
          </span>
        </div>
      </div>

      {/* Tipografía */}
      <div className="surface rounded-xl p-5">
        <h2 className="text-sm font-semibold mb-3 flex items-center gap-2">
          <Type className="w-4 h-4" /> Tipografía
        </h2>
        <div className="grid sm:grid-cols-3 gap-3">
          {Object.entries(TIPOGRAFIAS).map(([key, options]) => (
            <label key={key} className="block">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                {key === 'titulos' ? 'Títulos' : key === 'cuerpo' ? 'Cuerpo' : 'Acentos'}
              </span>
              <select
                value={tipografia[key as keyof typeof tipografia]}
                onChange={(e) => setTipografia({ ...tipografia, [key]: e.target.value })}
                className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
              >
                {options.map((o) => (
                  <option key={o}>{o}</option>
                ))}
              </select>
              <p
                className="text-2xl mt-2 text-center surface-2 rounded py-2"
                style={{ fontFamily: tipografia[key as keyof typeof tipografia] }}
              >
                Aa Bb Cc
              </p>
            </label>
          ))}
        </div>
      </div>

      <div className="flex justify-end">
        <button className="bg-primary text-primary-foreground text-sm font-medium px-6 py-2.5 rounded-lg hover:opacity-90">
          Guardar cambios
        </button>
      </div>
    </div>
  );
}
