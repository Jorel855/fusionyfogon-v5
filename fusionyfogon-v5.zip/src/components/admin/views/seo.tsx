'use client';

import { useState } from 'react';
import { Check, AlertCircle, RefreshCw, ExternalLink, Search, Code } from 'lucide-react';

const PAGES = [
  { slug: '/', title: 'Home', seo: { title: 'FUSIÓN Y FOGÓN | Ahumados & Experiencias. Lebrija, Santander', desc: 'Restaurante y charcutería artesanal en Lebrija, Santander. Ahumados a la leña de guayabo, costillares al barril, cóctel tropical y catering campestre. Pedidos por WhatsApp.', keyword: 'ahumados lebrija' } },
  { slug: '/p/lomo-ahumado-barril', title: 'Lomo de cerdo Ahumado al Barril', seo: { title: 'Lomo de Cerdo Ahumado al Barril | Fusión y Fogón', desc: 'Lomo de cerdo 300g ahumado al barril con leña de guayabo en Lebrija, Santander. Especialidad de la casa.', keyword: 'lomo ahumado cerdo' } },
  { slug: '/catering', title: 'Catering', seo: { title: 'Catering Campestre en Lebrija | Fusión y Fogón', desc: 'Servicio de catering con ahumados al barril en vivo y estación de charcutería para eventos en Santander.', keyword: 'catering santander' } },
];

export function SeoView() {
  const [page, setPage] = useState(0);
  const [title, setTitle] = useState(PAGES[0].seo.title);
  const [desc, setDesc] = useState(PAGES[0].seo.desc);
  const [keyword, setKeyword] = useState(PAGES[0].seo.keyword);

  const selectPage = (i: number) => {
    setPage(i);
    setTitle(PAGES[i].seo.title);
    setDesc(PAGES[i].seo.desc);
    setKeyword(PAGES[i].seo.keyword);
  };

  const titleLen = title.length;
  const descLen = desc.length;

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">SEO</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Optimización para buscadores · Positioning automático en Google
          </p>
        </div>
        <button className="bg-primary text-primary-foreground text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90 flex items-center gap-2">
          <RefreshCw className="w-4 h-4" /> Submit a Google
        </button>
      </div>

      {/* Status cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: 'Sitemap.xml', value: '12 URLs', status: 'ok', sub: 'hace 2 horas' },
          { label: 'Robots.txt', value: '✓ Configurado', status: 'ok', sub: 'Allow: /' },
          { label: 'JSON-LD', value: '4 schemas', status: 'ok', sub: 'Restaurant · Menu · FAQ · Breadcrumb' },
          { label: 'Google Search Console', value: 'No conectado', status: 'warn', sub: 'Conectar para indexación automática' },
        ].map((s) => (
          <div key={s.label} className="surface rounded-xl p-4">
            <div className="flex items-start justify-between mb-1">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{s.label}</span>
              {s.status === 'ok' ? (
                <Check className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
              )}
            </div>
            <p className={`text-sm font-semibold ${s.status === 'warn' ? 'text-amber-400' : ''}`}>{s.value}</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">{s.sub}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        {/* Páginas */}
        <div className="surface rounded-xl p-3 lg:col-span-1">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground px-2 py-1">Páginas</p>
          <div className="space-y-1">
            {PAGES.map((p, i) => (
              <button
                key={p.slug}
                onClick={() => selectPage(i)}
                className={`w-full text-left px-2 py-2 rounded-lg transition-colors ${
                  page === i ? 'bg-primary/10 border border-primary/20' : 'hover:bg-muted'
                }`}
              >
                <p className={`text-sm font-medium ${page === i ? 'text-primary' : ''}`}>{p.title}</p>
                <p className="text-[10px] text-muted-foreground font-mono truncate">{p.slug}</p>
              </button>
            ))}
            <button className="w-full text-left px-2 py-2 rounded-lg hover:bg-muted text-primary text-xs flex items-center gap-1.5">
              + Crear página
            </button>
          </div>
        </div>

        {/* Editor */}
        <div className="surface rounded-xl p-5 lg:col-span-2 space-y-4">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Título SEO</span>
              <span className={`text-[10px] ${titleLen > 60 ? 'text-amber-400' : 'text-emerald-400'}`}>
                {titleLen}/60
              </span>
            </div>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="surface-2 w-full px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Descripción</span>
              <span className={`text-[10px] ${descLen > 155 ? 'text-amber-400' : 'text-emerald-400'}`}>
                {descLen}/155
              </span>
            </div>
            <textarea
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
              rows={3}
              className="surface-2 w-full px-3 py-2 rounded-lg text-sm resize-none focus:outline-none focus:border-primary/40"
            />
          </div>

          <div>
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Keyword foco</span>
            <div className="relative mt-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                className="surface-2 w-full pl-9 pr-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
              />
            </div>
          </div>

          {/* Google preview */}
          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Preview en Google</p>
            <div className="surface-2 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-1">
                <div className="w-6 h-6 rounded-full brand-gradient flex items-center justify-center text-white text-[10px]">
                  F
                </div>
                <div>
                  <p className="text-xs text-foreground">Fusión y Fogón</p>
                  <p className="text-[10px] text-muted-foreground">https://fusionyfogon.com{PAGES[page].slug}</p>
                </div>
              </div>
              <p className="text-base text-[#1a0dab] dark:text-[#8ab4f8] hover:underline cursor-pointer leading-tight mt-2">
                {title}
              </p>
              <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{desc}</p>
            </div>
          </div>

          {/* JSON-LD */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground flex items-center gap-1">
                <Code className="w-3 h-3" /> JSON-LD generado
              </p>
              <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                <Check className="w-3 h-3" /> Válido
              </span>
            </div>
            <pre className="surface-2 rounded-lg p-3 text-[10px] font-mono text-emerald-400 overflow-x-auto max-h-40 overflow-y-auto">
{`{
  "@context": "https://schema.org",
  "@type": "Restaurant",
  "name": "Fusión y Fogón",
  "image": "https://fusionyfogon.com/icons/icon-512.png",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Lebrija",
    "addressRegion": "Santander",
    "addressCountry": "CO"
  },
  "servesCuisine": "Ahumados, Charcutería",
  "priceRange": "$$",
  "telephone": "+57 350 802 9292",
  "menu": "https://fusionyfogon.com/#carta",
  "acceptsReservations": "True",
  "openingHours": "Th-Su 11:30-20:30"
}`}
            </pre>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <button className="bg-primary text-primary-foreground text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90">
              Guardar SEO
            </button>
            <button
              onClick={async () => {
                const token = localStorage.getItem('fyf_admin_token')
                const res = await fetch('/api/seo/notify-google', {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                    ...(token ? { Authorization: `Bearer ${token}` } : {}),
                  },
                  body: JSON.stringify({ url: `https://fusionyfogon.com${PAGES[page].slug}` }),
                })
                const data = await res.json()
                if (data.ok) {
                  alert(data.demo ? 'Modo demo: Google Indexing API no configurada' : 'URL enviada a Google Indexing API')
                } else {
                  alert('Error: ' + data.error)
                }
              }}
              className="surface-2 text-sm px-4 py-2 rounded-lg hover:border-primary/30 flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Notify Google Indexing
            </button>
            <a
              href="https://fusionyfogon.com/sitemap.xml"
              target="_blank"
              rel="noreferrer"
              className="surface-2 text-sm px-4 py-2 rounded-lg hover:border-primary/30 flex items-center gap-1.5"
            >
              <ExternalLink className="w-3.5 h-3.5" /> Ver sitemap
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
