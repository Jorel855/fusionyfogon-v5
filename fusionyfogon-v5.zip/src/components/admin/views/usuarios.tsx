'use client';

import { useState } from 'react';
import { UserPlus, Shield, Clock, Check, X, History, MoreVertical, Loader2 } from 'lucide-react';
import { useAuditLog } from '@/hooks/use-audit-log';

type Usuario = {
  id: string;
  nombre: string;
  email: string;
  rol: 'Admin' | 'Editor' | 'Cajero' | 'Cocina';
  activo: boolean;
  ultimoAcceso: string;
  inicial: string;
  color: string;
};

const USUARIOS: Usuario[] = [
  { id: 'u1', nombre: 'Jorel Kales', email: 'jorel@fusionyfogon.com', rol: 'Admin', activo: true, ultimoAcceso: 'Ahora', inicial: 'JK', color: '#CC6600' },
];

const ROLES = [
  { nombre: 'Admin', descripcion: 'Acceso total a todos los módulos', permisos: ['Pedidos', 'Reservas', 'Catálogo', 'Contenido', 'Configuración', 'Usuarios'], count: 1, color: '#CC6600' },
  { nombre: 'Editor', descripcion: 'Edita catálogo y contenido, no configuración', permisos: ['Pedidos', 'Reservas', 'Catálogo', 'Contenido'], count: 0, color: '#3B82F6' },
  { nombre: 'Cajero', descripcion: 'Solo pedidos y reservas del día', permisos: ['Pedidos', 'Reservas'], count: 0, color: '#10B981' },
  { nombre: 'Cocina', descripcion: 'Solo ve pedidos en preparación', permisos: ['Pedidos (solo lectura)'], count: 0, color: '#A855F7' },
];

const TIPO_STYLES = {
  create: { color: '#10B981', bg: 'rgba(16,185,129,0.12)', label: '+' },
  update: { color: '#3B82F6', bg: 'rgba(59,130,246,0.12)', label: '✎' },
  delete: { color: '#EF4444', bg: 'rgba(239,68,68,0.12)', label: '−' },
  auth: { color: '#A855F7', bg: 'rgba(168,85,247,0.12)', label: '🔒' },
  config: { color: '#CC6600', bg: 'rgba(204,102,0,0.12)', label: '⚙' },
};

export function UsuariosView() {
  const [showInvite, setShowInvite] = useState(false);
  const { logs, loading } = useAuditLog(20);

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Usuarios y roles</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Autenticación vía Netlify Identity · 1 usuario activo ·{' '}
            <span className="text-emerald-400">● audit log en vivo</span>
          </p>
        </div>
        <button
          onClick={() => setShowInvite(true)}
          className="bg-primary text-primary-foreground text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90 flex items-center gap-2"
        >
          <UserPlus className="w-4 h-4" /> Invitar usuario
        </button>
      </div>

      {/* Usuarios */}
      <div className="surface rounded-xl p-5">
        <h2 className="text-sm font-semibold mb-3">Usuarios del sistema</h2>
        <div className="space-y-2">
          {USUARIOS.map((u) => (
            <div key={u.id} className="surface-2 rounded-lg p-3 flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                style={{ background: u.color }}
              >
                {u.inicial}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium">{u.nombre}</p>
                <p className="text-[10px] text-muted-foreground truncate">{u.email}</p>
              </div>
              <span className="text-[10px] bg-primary/15 text-primary px-2 py-1 rounded-full font-medium">{u.rol}</span>
              <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                <Clock className="w-3 h-3" /> {u.ultimoAcceso}
              </span>
              <span className="flex items-center gap-1 text-[10px] text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 pulse-live" /> Activo
              </span>
              <button className="text-muted-foreground hover:text-foreground p-1">
                <MoreVertical className="w-4 h-4" />
              </button>
            </div>
          ))}
          <button
            onClick={() => setShowInvite(true)}
            className="w-full surface-2 rounded-lg p-3 text-sm text-muted-foreground hover:text-primary hover:border-primary/30 transition-colors flex items-center justify-center gap-2 border border-dashed"
          >
            <UserPlus className="w-4 h-4" /> Invitar nuevo usuario por email
          </button>
        </div>
      </div>

      {/* Roles */}
      <div className="surface rounded-xl p-5">
        <h2 className="text-sm font-semibold mb-3 flex items-center gap-2">
          <Shield className="w-4 h-4" /> Roles disponibles
        </h2>
        <div className="grid sm:grid-cols-2 gap-3">
          {ROLES.map((r) => (
            <div key={r.nombre} className="surface-2 rounded-lg p-4">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span
                    className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold"
                    style={{ background: r.color }}
                  >
                    {r.nombre.charAt(0)}
                  </span>
                  <div>
                    <p className="text-sm font-semibold">{r.nombre}</p>
                    <p className="text-[10px] text-muted-foreground">{r.descripcion}</p>
                  </div>
                </div>
                <span className="text-[10px] text-muted-foreground">{r.count} usuario(s)</span>
              </div>
              <div className="flex flex-wrap gap-1 mt-3">
                {r.permisos.map((p) => (
                  <span key={p} className="text-[9px] surface px-2 py-0.5 rounded-full">{p}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Audit log real */}
      <div className="surface rounded-xl p-5">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold flex items-center gap-2">
            <History className="w-4 h-4" /> Audit log (desde DB)
          </h2>
          <span className="text-[10px] text-muted-foreground">{logs.length} entradas</span>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-5 h-5 text-primary animate-spin" />
          </div>
        ) : logs.length === 0 ? (
          <p className="text-xs text-muted-foreground text-center py-6">
            Sin registros aún. Cambia el estado de un pedido o edita un plato para ver actividad aquí.
          </p>
        ) : (
          <div className="space-y-1 max-h-80 overflow-y-auto">
            {logs.map((log) => {
              const t = (TIPO_STYLES as any)[log.accion] || TIPO_STYLES.update;
              return (
                <div key={log.id} className="surface-2 rounded-lg p-2.5 flex items-center gap-3">
                  <div
                    className="w-7 h-7 rounded-md flex items-center justify-center text-xs font-bold flex-shrink-0"
                    style={{ background: t.bg, color: t.color }}
                  >
                    {t.label}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs">
                      <span className="font-medium">{log.usuario}</span>{' '}
                      <span className="text-muted-foreground">{log.detalle}</span>
                    </p>
                  </div>
                  <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                    {new Date(log.fecha).toLocaleString('es-CO', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="surface rounded-xl p-4 flex items-start gap-3 text-xs">
        <div className="w-8 h-8 rounded-lg bg-[#00C7B7]/15 flex items-center justify-center flex-shrink-0">
          <Shield className="w-4 h-4 text-[#00C7B7]" />
        </div>
        <div className="text-muted-foreground">
          <strong className="text-foreground">Netlify Identity</strong> gestiona la autenticación. El PIN rápido del
          panel actual se conserva como atajo para staff en dispositivo compartido (caja).
        </div>
      </div>

      {showInvite && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="surface rounded-2xl p-6 max-w-md w-full">
            <h3 className="text-lg font-semibold mb-1">Invitar usuario</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Se enviará un email con enlace mágico vía Netlify Identity.
            </p>
            <div className="space-y-3">
              <label className="block">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Email</span>
                <input
                  type="email"
                  placeholder="colaborador@fusionyfogon.com"
                  className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
                />
              </label>
              <label className="block">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Rol</span>
                <select className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40">
                  <option>Admin</option>
                  <option>Editor</option>
                  <option>Cajero</option>
                  <option>Cocina</option>
                </select>
              </label>
            </div>
            <div className="flex gap-2 mt-5">
              <button
                onClick={() => setShowInvite(false)}
                className="flex-1 surface-2 text-sm py-2.5 rounded-lg hover:border-primary/30"
              >
                Cancelar
              </button>
              <button
                onClick={() => setShowInvite(false)}
                className="flex-1 bg-primary text-primary-foreground text-sm font-medium py-2.5 rounded-lg hover:opacity-90 flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" /> Enviar invitación
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

