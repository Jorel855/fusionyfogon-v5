'use client';

import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  ShoppingCart,
  CalendarCheck,
  Eye,
  ArrowRight,
  Plus,
  Ban,
  Eye as EyeIcon,
  Clock,
  Loader2,
} from 'lucide-react';
import { useDashboard } from '@/hooks/use-dashboard';
import { formatCOP } from '@/lib/format';

const HEATMAP_COLORS = ['rgba(204,102,0,0.08)', 'rgba(204,102,0,0.25)', 'rgba(204,102,0,0.5)', 'rgba(204,102,0,0.75)', 'rgba(204,102,0,1)'];

const HORAS_PICO = {
  horas: ['12p', '1p', '2p', '6p', '7p', '8p'],
  dias: ['L', 'M', 'X', 'J', 'V', 'S', 'D'],
  data: [
    [1, 1, 1, 2, 3, 4, 4],
    [1, 1, 2, 3, 3, 4, 4],
    [0, 0, 1, 1, 2, 3, 3],
    [0, 0, 0, 1, 3, 4, 4],
    [0, 0, 0, 1, 3, 4, 4],
    [0, 0, 0, 1, 2, 3, 3],
  ],
};

export function DashboardView({ onNavigate }: { onNavigate: (v: string) => void }) {
  const { data, loading, error } = useDashboard();

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 text-primary animate-spin" />
        <span className="ml-2 text-sm text-muted-foreground">Cargando dashboard desde DB...</span>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="surface rounded-xl p-6 text-center text-sm text-red-400">
        Error cargando dashboard: {error || 'desconocido'}
      </div>
    );
  }

  const kpis = [
    { label: 'Ventas hoy', value: formatCOP(data.kpis.ventasHoy), delta: data.kpis.ventasHoy > 0 ? '+12%' : '0%', deltaUp: data.kpis.ventasHoy > 0, icon: DollarSign, color: '#CC6600' },
    { label: 'Pedidos hoy', value: String(data.kpis.pedidosHoy), delta: data.kpis.pedidosHoy > 0 ? '+50%' : '0%', deltaUp: data.kpis.pedidosHoy > 0, icon: ShoppingCart, color: '#D97706' },
    { label: 'Reservas hoy', value: String(data.kpis.reservasHoy), delta: '—', deltaUp: null, icon: CalendarCheck, color: '#8B4513' },
    { label: 'Visitas hoy', value: String(data.kpis.visitasHoy), delta: '+8%', deltaUp: true, icon: Eye, color: '#6B3410' },
  ];

  const maxVentas = Math.max(...data.topPlatos.map((p) => p.ventas), 1);

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {new Date().toLocaleDateString('es-CO', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })} ·{' '}
            <span className="text-emerald-400">● datos en vivo desde DB</span>
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 text-xs text-muted-foreground surface-2 px-3 py-1.5 rounded-lg">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 pulse-live" />
            En vivo
          </span>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi) => {
          const Icon = kpi.icon;
          return (
            <div key={kpi.label} className="surface rounded-xl p-5">
              <div className="flex items-start justify-between mb-3">
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center"
                  style={{ background: `${kpi.color}20`, color: kpi.color }}
                >
                  <Icon className="w-5 h-5" />
                </div>
                {kpi.deltaUp !== null && (
                  <span
                    className={`flex items-center gap-0.5 text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                      kpi.deltaUp ? 'text-emerald-400 bg-emerald-500/10' : 'text-red-400 bg-red-500/10'
                    }`}
                  >
                    {kpi.deltaUp ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                    {kpi.delta}
                  </span>
                )}
              </div>
              <p className="text-2xl font-bold tracking-tight">{kpi.value}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{kpi.label}</p>
            </div>
          );
        })}
      </div>

      {/* Pedidos pendientes + Reservas próximas */}
      <div className="grid lg:grid-cols-2 gap-4">
        <div className="surface rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-red-500 pulse-live" />
              Pedidos pendientes
            </h2>
            <button
              onClick={() => onNavigate('pedidos')}
              className="text-xs text-primary hover:underline flex items-center gap-1"
            >
              Ver todos <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <div className="space-y-2">
            {data.pedidosPendientes.length === 0 && (
              <p className="text-sm text-muted-foreground py-6 text-center">No hay pedidos pendientes 🎉</p>
            )}
            {data.pedidosPendientes.map((p) => (
              <div key={p.id} className="surface-2 rounded-lg p-3 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg brand-gradient flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                  {p.cliente.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{p.cliente} · #{p.codigo}</p>
                  <p className="text-xs text-muted-foreground truncate">{p.detalle}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-sm font-bold text-primary">{formatCOP(p.total * 100)}</p>
                  <p className="text-[10px] text-muted-foreground">
                    {new Date(p.fecha).toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="surface rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold flex items-center gap-2">
              <CalendarCheck className="w-4 h-4 text-primary" />
              Próximas reservas
            </h2>
            <button
              onClick={() => onNavigate('reservas')}
              className="text-xs text-primary hover:underline flex items-center gap-1"
            >
              Ver calendario <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <div className="space-y-2">
            {data.proximasReservas.length === 0 && (
              <p className="text-sm text-muted-foreground py-6 text-center">No hay reservas próximas</p>
            )}
            {data.proximasReservas.map((r) => (
              <div key={r.id} className="surface-2 rounded-lg p-3 flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg surface text-center flex flex-col justify-center flex-shrink-0">
                  <p className="text-[9px] uppercase text-muted-foreground">
                    {new Date(r.fecha + 'T00:00').toLocaleDateString('es-CO', { month: 'short' })}
                  </p>
                  <p className="text-base font-bold leading-none">
                    {new Date(r.fecha + 'T00:00').getDate()}
                  </p>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{r.nombre} · {r.personas} personas</p>
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {r.hora} · {r.estado}
                  </p>
                </div>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                    r.estado === 'Confirmada'
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : 'bg-amber-500/15 text-amber-400'
                  }`}
                >
                  {r.estado}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sales chart + Top platos */}
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="surface rounded-xl p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold">Ventas últimos 30 días</h2>
              <p className="text-xs text-muted-foreground mt-0.5">
                Total: {formatCOP(data.ventas30dias.reduce((a, b) => a + b.total, 0) * 100)} · Promedio:{' '}
                {formatCOP((data.ventas30dias.reduce((a, b) => a + b.total, 0) / 30) * 100)}
              </p>
            </div>
          </div>
          <div className="h-64 -ml-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.ventas30dias}>
                <defs>
                  <linearGradient id="ventasGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#CC6600" stopOpacity={0.6} />
                    <stop offset="100%" stopColor="#CC6600" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(245,239,230,0.05)" />
                <XAxis
                  dataKey="fecha"
                  tick={{ fill: '#A8978A', fontSize: 10 }}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(v) => v.slice(8)}
                />
                <YAxis
                  tick={{ fill: '#A8978A', fontSize: 10 }}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(v) => `${v / 1000}k`}
                />
                <Tooltip
                  contentStyle={{
                    background: '#1B1714',
                    border: '1px solid rgba(204,102,0,0.3)',
                    borderRadius: '8px',
                    fontSize: '12px',
                  }}
                  labelStyle={{ color: '#A8978A' }}
                  formatter={(v: number) => [formatCOP(v * 100), 'Ventas']}
                />
                <Area
                  type="monotone"
                  dataKey="total"
                  stroke="#CC6600"
                  strokeWidth={2}
                  fill="url(#ventasGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="surface rounded-xl p-5">
          <h2 className="text-sm font-semibold mb-4">Top 5 platos</h2>
          <div className="space-y-3">
            {data.topPlatos.length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-6">Sin datos aún</p>
            )}
            {data.topPlatos.map((p, i) => (
              <div key={p.id}>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded surface-2 flex items-center justify-center text-[10px] font-bold text-primary">
                      {i + 1}
                    </span>
                    <span className="truncate font-medium">{p.nombre.split(' ').slice(0, 3).join(' ')}…</span>
                  </span>
                  <span className="text-muted-foreground">{p.ventas} ped.</span>
                </div>
                <div className="h-1.5 surface-2 rounded-full overflow-hidden">
                  <div
                    className="h-full brand-gradient rounded-full transition-all"
                    style={{ width: `${(p.ventas / maxVentas) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div className="surface rounded-xl p-5">
        <h2 className="text-sm font-semibold mb-3">Acciones rápidas</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {[
            { label: 'Nuevo plato', icon: Plus, view: 'catalogo-platos' },
            { label: 'Bloquear fecha', icon: Ban, view: 'reservas' },
            { label: 'Exportar CSV', icon: ArrowRight, view: 'pedidos' },
            { label: 'Editar SEO', icon: EyeIcon, view: 'config-seo' },
            { label: 'Cambiar marca', icon: ArrowRight, view: 'config-identidad' },
            { label: 'Ver respaldos', icon: Clock, view: 'config-respaldos' },
          ].map((a) => {
            const Icon = a.icon;
            return (
              <button
                key={a.label}
                onClick={() => onNavigate(a.view)}
                className="surface-2 rounded-lg p-3 hover:border-primary/30 transition-colors text-left"
              >
                <Icon className="w-4 h-4 text-primary mb-2" />
                <p className="text-xs font-medium">{a.label}</p>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
