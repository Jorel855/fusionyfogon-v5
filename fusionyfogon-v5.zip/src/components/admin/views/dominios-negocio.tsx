'use client';

import { useState } from 'react';
import {
  Globe,
  AlertCircle,
  Check,
  X,
  ArrowRight,
  Copy,
  ExternalLink,
  Rocket,
  Sparkles,
  UtensilsCrossed,
  Flower2,
  ShoppingBag,
  Building2,
  Wand2,
  ChevronRight,
  Info,
} from 'lucide-react';

type DomainStatus = {
  domain: string;
  type: 'primary' | 'redirect' | 'pending' | 'subdomain';
  dns: string;
  https: 'ok' | 'fail' | 'pending';
  serves: boolean;
  status: 'active' | 'pending' | 'redirect';
  note?: string;
};

const DOMAINS: DomainStatus[] = [
  {
    domain: 'fusionyfogon.com',
    type: 'primary',
    dns: 'Netlify Edge',
    https: 'ok',
    serves: true,
    status: 'active',
    note: 'Dominio canónico (principal para SEO)',
  },
  {
    domain: 'fusionyfogon.co',
    type: 'redirect',
    dns: 'GoDaddy (162.215.226.x)',
    https: 'fail',
    serves: false,
    status: 'pending',
    note: 'DNS apunta a GoDaddy, no a Netlify. Cambiar CNAME a netlify.app',
  },
  {
    domain: 'fusionyfogon.com.co',
    type: 'redirect',
    dns: 'GoDaddy (162.215.226.x)',
    https: 'fail',
    serves: false,
    status: 'pending',
    note: 'Mismo problema que .co — configurar redirect 301 al .com',
  },
  {
    domain: 'fusionyfogon.netlify.app',
    type: 'subdomain',
    dns: 'Netlify (automático)',
    https: 'ok',
    serves: true,
    status: 'redirect',
    note: 'Subdominio de deploy — redirige al .com',
  },
];

const TIPO_NEGOCIO = [
  {
    id: 'restaurante',
    nombre: 'Restaurante / Comidas rápidas',
    icon: UtensilsCrossed,
    color: '#CC6600',
    descripcion: 'Catálogo de platos, pedidos online, reservas de mesa',
    modulos: ['Catálogo de platos', 'Pedidos con pago', 'Reservas de mesa', 'WhatsApp', 'Catering opcional'],
    schemaSeo: 'Restaurant',
    labels: { plato: 'Plato', categoria: 'Categoría', pedido: 'Pedido', reserva: 'Reserva' },
  },
  {
    id: 'spa',
    nombre: 'Spa de uñas / Manicure',
    icon: Flower2,
    color: '#EC4899',
    descripcion: 'Catálogo de servicios, citas por profesional, agenda',
    modulos: ['Catálogo de servicios', 'Citas con profesional', 'Agenda del día', 'WhatsApp', 'Recordatorios'],
    schemaSeo: 'HealthAndBeautyBusiness',
    labels: { plato: 'Servicio', categoria: 'Tipo de servicio', pedido: 'Venta', reserva: 'Cita' },
  },
  {
    id: 'tienda',
    nombre: 'Tienda / Retail',
    icon: ShoppingBag,
    color: '#3B82F6',
    descripcion: 'Productos con stock, carrito, envíos, pagos online',
    modulos: ['Catálogo de productos', 'Carrito + checkout', 'Gestión de stock', 'Envíos', 'Pagos online'],
    schemaSeo: 'Store',
    labels: { plato: 'Producto', categoria: 'Categoría', pedido: 'Pedido', reserva: '—' },
  },
  {
    id: 'mixto',
    nombre: 'Mixto (productos + servicios)',
    icon: Building2,
    color: '#8B5CF6',
    descripcion: 'Cafetería con talleres, restaurante con catering, etc.',
    modulos: ['Catálogo mixto', 'Pedidos + Citas', 'Carrito', 'Reservas', 'WhatsApp'],
    schemaSeo: 'LocalBusiness',
    labels: { plato: 'Ítem', categoria: 'Categoría', pedido: 'Pedido', reserva: 'Reserva' },
  },
];

export function DominiosNegocioView() {
  const [tipoNegocio, setTipoNegocio] = useState('restaurante');
  const [showWizard, setShowWizard] = useState(false);
  const [copied, setCopied] = useState(false);

  const selectedTipo = TIPO_NEGOCIO.find((t) => t.id === tipoNegocio)!;

  const copyToClipboard = (text: string) => {
    navigator.clipboard?.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Dominios & Negocio</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Configuración de dominios, modelo de despliegue y tipo de negocio — esto define cómo se adapta la plantilla
        </p>
      </div>

      {/* Dominios actuales */}
      <div className="surface rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-semibold flex items-center gap-2">
            <Globe className="w-4 h-4" /> Dominios del negocio
          </h2>
          <button className="text-xs bg-primary text-primary-foreground px-3 py-1.5 rounded-lg hover:opacity-90 flex items-center gap-1.5">
            + Agregar dominio
          </button>
        </div>

        <div className="space-y-2">
          {DOMAINS.map((d) => (
            <div key={d.domain} className="surface-2 rounded-lg p-3 flex items-center gap-3">
              <div
                className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  d.https === 'ok'
                    ? 'bg-emerald-500/15 text-emerald-400'
                    : d.https === 'fail'
                    ? 'bg-red-500/15 text-red-400'
                    : 'bg-amber-500/15 text-amber-400'
                }`}
              >
                {d.https === 'ok' ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="text-sm font-medium font-mono">{d.domain}</p>
                  {d.type === 'primary' && (
                    <span className="text-[9px] bg-primary text-primary-foreground px-1.5 py-0.5 rounded-full font-bold">
                      PRINCIPAL
                    </span>
                  )}
                  {d.type === 'redirect' && (
                    <span className="text-[9px] bg-blue-500/15 text-blue-400 px-1.5 py-0.5 rounded-full font-medium">
                      REDIRECT 301
                    </span>
                  )}
                  {d.type === 'subdomain' && (
                    <span className="text-[9px] surface px-1.5 py-0.5 rounded-full font-medium text-muted-foreground">
                      SUBDOMINIO
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-muted-foreground mt-0.5">
                  DNS: {d.dns} · HTTPS: {d.https === 'ok' ? '✓' : d.https === 'fail' ? '✗ falla' : 'pendiente'} ·{' '}
                  {d.serves ? 'sirve la web' : 'no responde'}
                </p>
                {d.note && <p className="text-[10px] text-amber-400 mt-1">{d.note}</p>}
              </div>
              <div className="flex items-center gap-1">
                {d.https === 'fail' && (
                  <button className="text-[10px] bg-amber-500/15 text-amber-400 px-2 py-1 rounded-md hover:bg-amber-500 hover:text-white">
                    Configurar
                  </button>
                )}
                {d.type === 'primary' && <span className="text-[10px] text-emerald-400">✓ Canonical SEO</span>}
              </div>
            </div>
          ))}
        </div>

        {/* Pending action callout */}
        <div className="mt-3 surface-2 rounded-lg p-3 flex items-start gap-2 text-xs">
          <AlertCircle className="w-3.5 h-3.5 text-amber-400 mt-0.5 flex-shrink-0" />
          <span className="text-muted-foreground">
            <strong className="text-amber-400">2 dominios pendientes.</strong> Los dominios <code className="text-foreground">.co</code> y{' '}
            <code className="text-foreground">.com.co</code> no están conectados a Netlify. Mira las instrucciones
            abajo para configurarlos con redirect 301 al .com.
          </span>
        </div>
      </div>

      {/* Redirects 301 rules */}
      <div className="surface rounded-xl p-5">
        <h2 className="text-sm font-semibold mb-1 flex items-center gap-2">
          <ArrowRight className="w-4 h-4" /> Reglas de redirect 301
        </h2>
        <p className="text-xs text-muted-foreground mb-4">
          Evita contenido duplicado en Google. Todos los dominios alternativos deben apuntar al canonical (.com).
        </p>

        <div className="surface-2 rounded-lg p-4 font-mono text-[11px] overflow-x-auto">
          <pre className="text-muted-foreground whitespace-pre">
{`# netlify.toml — colocado en la raíz del repo

[[redirects]]
  from = "https://fusionyfogon.co/*"
  to = "https://fusionyfogon.com/:splat"
  status = 301
  force = true

[[redirects]]
  from = "https://fusionyfogon.com.co/*"
  to = "https://fusionyfogon.com/:splat"
  status = 301
  force = true

[[redirects]]
  from = "https://fusionyfogon.netlify.app/*"
  to = "https://fusionyfogon.com/:splat"
  status = 301
  force = true`}
          </pre>
        </div>

        <div className="flex items-center gap-2 mt-3">
          <button
            onClick={() => copyToClipboard('redirects-config')}
            className="surface-2 text-xs px-3 py-1.5 rounded-lg hover:border-primary/30 flex items-center gap-1.5"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            {copied ? 'Copiado' : 'Copiar configuración'}
          </button>
          <a
            href="https://docs.netlify.com/routing/redirects/"
            target="_blank"
            rel="noreferrer"
            className="text-xs text-primary hover:underline flex items-center gap-1"
          >
            Docs Netlify redirects <ExternalLink className="w-3 h-3" />
          </a>
        </div>

        {/* Preview */}
        <div className="mt-4 surface-2 rounded-lg p-3">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Preview del comportamiento</p>
          <div className="space-y-1.5 text-xs font-mono">
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">usuario escribe:</span>
              <code className="surface px-2 py-0.5 rounded">fusionyfogon.co/menu</code>
              <ArrowRight className="w-3 h-3 text-primary" />
              <code className="bg-primary/15 text-primary px-2 py-0.5 rounded">fusionyfogon.com/menu</code>
              <span className="text-emerald-400 text-[10px]">301</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">usuario escribe:</span>
              <code className="surface px-2 py-0.5 rounded">fusionyfogon.com.co</code>
              <ArrowRight className="w-3 h-3 text-primary" />
              <code className="bg-primary/15 text-primary px-2 py-0.5 rounded">fusionyfogon.com</code>
              <span className="text-emerald-400 text-[10px]">301</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">usuario escribe:</span>
              <code className="surface px-2 py-0.5 rounded">fusionyfogon.netlify.app</code>
              <ArrowRight className="w-3 h-3 text-primary" />
              <code className="bg-primary/15 text-primary px-2 py-0.5 rounded">fusionyfogon.com</code>
              <span className="text-emerald-400 text-[10px]">301</span>
            </div>
          </div>
        </div>
      </div>

      {/* Modo rubro */}
      <div className="surface rounded-xl p-5">
        <div className="flex items-center justify-between mb-1">
          <h2 className="text-sm font-semibold flex items-center gap-2">
            <Sparkles className="w-4 h-4" /> Tipo de negocio
          </h2>
          <span className="text-[10px] text-muted-foreground">
            Define qué módulos se activan y cómo se llaman
          </span>
        </div>
        <p className="text-xs text-muted-foreground mb-4">
          La plantilla se adapta automáticamente según el rubro — misma base, diferentes módulos activos
        </p>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {TIPO_NEGOCIO.map((t) => {
            const Icon = t.icon;
            const isActive = tipoNegocio === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setTipoNegocio(t.id)}
                className={`surface-2 rounded-xl p-4 text-left transition-all ${
                  isActive ? 'ring-2 ring-primary' : 'hover:border-primary/30'
                }`}
              >
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center mb-3"
                  style={{ background: `${t.color}20`, color: t.color }}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <p className="text-sm font-semibold mb-1">{t.nombre}</p>
                <p className="text-[10px] text-muted-foreground leading-relaxed">{t.descripcion}</p>
                {isActive && (
                  <span className="inline-flex items-center gap-1 mt-2 text-[10px] text-primary font-medium">
                    <Check className="w-3 h-3" /> Seleccionado
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Detalle del rubro seleccionado */}
        <div className="mt-4 surface-2 rounded-lg p-4">
          <div className="flex items-start justify-between mb-3 flex-wrap gap-2">
            <div>
              <p className="text-sm font-semibold flex items-center gap-2">
                <selectedTipo.icon className="w-4 h-4" style={{ color: selectedTipo.color }} />
                {selectedTipo.nombre}
              </p>
              <p className="text-[10px] text-muted-foreground mt-0.5">
                Schema SEO: <code className="text-primary">{selectedTipo.schemaSeo}</code>
              </p>
            </div>
            <button className="text-[10px] surface px-2 py-1 rounded-md hover:border-primary/30">
              Ver demo de este rubro
            </button>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2">
                Módulos que se activan
              </p>
              <div className="flex flex-wrap gap-1">
                {selectedTipo.modulos.map((m) => (
                  <span
                    key={m}
                    className="text-[10px] px-2 py-1 rounded-full"
                    style={{ background: `${selectedTipo.color}15`, color: selectedTipo.color }}
                  >
                    {m}
                  </span>
                ))}
              </div>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2">
                Etiquetas adaptadas
              </p>
              <div className="grid grid-cols-2 gap-1 text-[11px]">
                {Object.entries(selectedTipo.labels).map(([k, v]) => (
                  <div key={k} className="flex items-center gap-2">
                    <span className="text-muted-foreground">{k}:</span>
                    <span className="font-medium">{v}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modelo de despliegue */}
      <div className="surface rounded-xl p-5">
        <h2 className="text-sm font-semibold mb-1 flex items-center gap-2">
          <Rocket className="w-4 h-4" /> Modelo de despliegue
        </h2>
        <p className="text-xs text-muted-foreground mb-4">
          Cómo se replica esta plantilla para nuevos negocios
        </p>

        <div className="grid lg:grid-cols-2 gap-3">
          <div className="surface-2 rounded-xl p-4 ring-2 ring-primary">
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-primary" />
              <p className="text-sm font-semibold">A — Fork por tenant (recomendado)</p>
              <span className="text-[9px] bg-primary text-primary-foreground px-1.5 py-0.5 rounded-full font-bold ml-auto">
                ACTIVO
              </span>
            </div>
            <p className="text-[11px] text-muted-foreground leading-relaxed mb-3">
              Cada nuevo negocio obtiene su propio deploy en su propia cuenta Netlify (Free tier, $0). Aislamiento
              total de datos, sin costo recurrente para ti, sin riesgo cruzado.
            </p>
            <div className="space-y-1 text-[11px]">
              <p className="flex items-center gap-1.5 text-emerald-400">
                <Check className="w-3 h-3" /> Cero costo recurrente
              </p>
              <p className="flex items-center gap-1.5 text-emerald-400">
                <Check className="w-3 h-3" /> Datos aislados por tenant
              </p>
              <p className="flex items-center gap-1.5 text-emerald-400">
                <Check className="w-3 h-3" /> Cero soporte 24/7
              </p>
              <p className="flex items-center gap-1.5 text-emerald-400">
                <Check className="w-3 h-3" /> Cobro simple (único o anual)
              </p>
            </div>
          </div>

          <div className="surface-2 rounded-xl p-4 opacity-60">
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-muted-foreground" />
              <p className="text-sm font-semibold">B — SaaS multi-tenant</p>
              <span className="text-[9px] surface px-1.5 py-0.5 rounded-full font-medium text-muted-foreground ml-auto">
                DESACTIVADO
              </span>
            </div>
            <p className="text-[11px] text-muted-foreground leading-relaxed mb-3">
              Un solo sitio, múltiples dominios detectando el tenant. Tú eres el proveedor y cobras suscripción. Mayor
              complejidad técnica, pero más control.
            </p>
            <div className="space-y-1 text-[11px]">
              <p className="flex items-center gap-1.5 text-muted-foreground">
                <X className="w-3 h-3" /> Requiere Netlify Pro ($19/mes)
              </p>
              <p className="flex items-center gap-1.5 text-muted-foreground">
                <X className="w-3 h-3" /> Soporte 24/7 de tu lado
              </p>
              <p className="flex items-center gap-1.5 text-muted-foreground">
                <X className="w-3 h-3" /> Mayor complejidad técnica
              </p>
              <p className="flex items-center gap-1.5 text-muted-foreground">
                <X className="w-3 h-3" /> Liability de data de terceros
              </p>
            </div>
          </div>
        </div>

        <div className="mt-3 surface-2 rounded-lg p-3 flex items-start gap-2 text-xs">
          <Info className="w-3.5 h-3.5 text-primary mt-0.5 flex-shrink-0" />
          <span className="text-muted-foreground">
            <strong className="text-foreground">Por qué Modelo A:</strong> cada dueño es responsable de su propio
            sitio y data. Si un negocio crece, escala solo sin afectar a otros. Tú solo vendes la plantilla y das
            soporte de actualizaciones.
          </span>
        </div>
      </div>

      {/* Deploy para nuevos dueños */}
      <div className="surface rounded-xl p-5">
        <h2 className="text-sm font-semibold mb-1 flex items-center gap-2">
          <Wand2 className="w-4 h-4" /> Onboarding de nuevo negocio
        </h2>
        <p className="text-xs text-muted-foreground mb-4">
          Cuando un nuevo dueño quiera instalar la plantilla, este es el flujo
        </p>

        <div className="grid sm:grid-cols-3 gap-3 mb-4">
          {[
            { paso: 1, titulo: 'Deploy a Netlify', desc: 'Click en el botón "Deploy to Netlify" del repo GitHub', tiempo: '1 min' },
            { paso: 2, titulo: 'Wizard de setup', desc: 'Selecciona rubro, sube logo, configura contacto', tiempo: '5 min' },
            { paso: 3, titulo: 'Conecta dominio', desc: 'Agrega su propio dominio en Netlify', tiempo: '10 min' },
          ].map((p) => (
            <div key={p.paso} className="surface-2 rounded-lg p-3 relative">
              <span className="absolute -top-2 -left-2 w-6 h-6 rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center">
                {p.paso}
              </span>
              <p className="text-sm font-medium mt-2">{p.titulo}</p>
              <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed">{p.desc}</p>
              <p className="text-[9px] text-primary mt-2 font-mono">⏱ {p.tiempo}</p>
            </div>
          ))}
        </div>

        {/* Deploy button mock */}
        <div className="surface-2 rounded-lg p-4 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#00C7B7] flex items-center justify-center">
              <Rocket className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-sm font-medium">Deploy to Netlify</p>
              <p className="text-[10px] text-muted-foreground">
                Botón que va en el README del repo — nuevo dueño lo click y tiene su sitio en 1 min
              </p>
            </div>
          </div>
          <a
            href="https://app.netlify.com/start"
            target="_blank"
            rel="noreferrer"
            className="bg-[#00C7B7] text-white text-xs font-medium px-4 py-2 rounded-lg hover:opacity-90 flex items-center gap-1.5"
          >
            <Rocket className="w-3.5 h-3.5" /> Deploy
          </a>
        </div>

        <div className="mt-3 grid sm:grid-cols-2 gap-3">
          <div className="surface-2 rounded-lg p-3 text-xs">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Para el nuevo dueño</p>
            <p className="text-foreground">
              Necesita su propia cuenta Netlify (gratis) + dominio propio (~$10/año). Tú le vendes la plantilla una
              vez. No hay costo recurrente para ninguno de los dos.
            </p>
          </div>
          <div className="surface-2 rounded-lg p-3 text-xs">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Para ti (vendedor)</p>
            <p className="text-foreground">
              Mantienes el repo GitHub. Cuando actualizas la plantilla, los tenants pueden hacer pull de los cambios.
              Opcional: cobrar suscripción anual por updates y soporte.
            </p>
          </div>
        </div>
      </div>

      {/* CTA Wizard */}
      <div className="surface rounded-xl p-5 bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border-primary/20">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg brand-gradient flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-sm font-semibold">¿Quieres ver el wizard de onboarding en acción?</p>
              <p className="text-[11px] text-muted-foreground">
                Simula agregar un nuevo negocio (ej. un spa de uñas) y mira cómo se adapta la plantilla
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowWizard(true)}
            className="bg-primary text-primary-foreground text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90 flex items-center gap-2"
          >
            <Wand2 className="w-4 h-4" /> Abrir wizard de demo
          </button>
        </div>
      </div>

      {/* Wizard modal */}
      {showWizard && <OnboardingWizard onClose={() => setShowWizard(false)} />}
    </div>
  );
}

function OnboardingWizard({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState(1);
  const [tipo, setTipo] = useState('');
  const [nombre, setNombre] = useState('');

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="surface rounded-2xl p-6 max-w-lg w-full">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg brand-gradient flex items-center justify-center">
              <Wand2 className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-sm font-semibold">Nuevo negocio</p>
              <p className="text-[10px] text-muted-foreground">Paso {step} de 3</p>
            </div>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Progress */}
        <div className="flex gap-1 mb-5">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`h-1 flex-1 rounded-full transition-colors ${
                s <= step ? 'bg-primary' : 'bg-muted'
              }`}
            />
          ))}
        </div>

        {/* Step 1: tipo de negocio */}
        {step === 1 && (
          <div>
            <h3 className="text-base font-semibold mb-1">¿Qué tipo de negocio tienes?</h3>
            <p className="text-xs text-muted-foreground mb-4">
              Esto define qué módulos se activan y cómo se llama cada cosa
            </p>
            <div className="grid grid-cols-2 gap-2">
              {TIPO_NEGOCIO.map((t) => {
                const Icon = t.icon;
                const isActive = tipo === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => setTipo(t.id)}
                    className={`surface-2 rounded-lg p-3 text-left transition-all ${
                      isActive ? 'ring-2 ring-primary' : 'hover:border-primary/30'
                    }`}
                  >
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center mb-2"
                      style={{ background: `${t.color}20`, color: t.color }}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <p className="text-xs font-medium">{t.nombre.split(' /')[0]}</p>
                  </button>
                );
              })}
            </div>
            <div className="flex justify-end mt-5">
              <button
                disabled={!tipo}
                onClick={() => setStep(2)}
                className="bg-primary text-primary-foreground text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"
              >
                Continuar <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Step 2: nombre + rubro */}
        {step === 2 && (
          <div>
            <h3 className="text-base font-semibold mb-1">Datos básicos del negocio</h3>
            <p className="text-xs text-muted-foreground mb-4">Estos datos aparecen en el panel y en la web pública</p>
            <div className="space-y-3">
              <label className="block">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Nombre del negocio</span>
                <input
                  type="text"
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                  placeholder="Ej. Spa Bella, Don Luigi, Café Altura..."
                  className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
                />
              </label>
              <div className="grid grid-cols-2 gap-3">
                <label className="block">
                  <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Ciudad</span>
                  <input
                    type="text"
                    placeholder="Bucaramanga"
                    className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
                  />
                </label>
                <label className="block">
                  <span className="text-[10px] uppercase tracking-wider text-muted-foreground">WhatsApp</span>
                  <input
                    type="tel"
                    placeholder="+57 300 000 0000"
                    className="surface-2 w-full mt-1 px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-primary/40"
                  />
                </label>
              </div>
            </div>
            <div className="flex justify-between mt-5">
              <button
                onClick={() => setStep(1)}
                className="surface-2 text-sm py-2 px-4 rounded-lg hover:border-primary/30"
              >
                ← Atrás
              </button>
              <button
                disabled={!nombre}
                onClick={() => setStep(3)}
                className="bg-primary text-primary-foreground text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"
              >
                Continuar <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Step 3: deploy */}
        {step === 3 && (
          <div>
            <h3 className="text-base font-semibold mb-1">¡Listo para crear!</h3>
            <p className="text-xs text-muted-foreground mb-4">
              Revisa la configuración y haz click en deploy
            </p>
            <div className="surface-2 rounded-lg p-3 space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Negocio:</span>
                <span className="font-medium">{nombre}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tipo:</span>
                <span className="font-medium">{TIPO_NEGOCIO.find((t) => t.id === tipo)?.nombre}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subdominio Netlify:</span>
                <span className="font-mono text-primary">
                  {nombre.toLowerCase().replace(/\s+/g, '-')}.netlify.app
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Módulos activos:</span>
                <span className="font-medium">{TIPO_NEGOCIO.find((t) => t.id === tipo)?.modulos.length}</span>
              </div>
            </div>
            <div className="mt-3 p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg flex items-start gap-2 text-xs">
              <Check className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
              <span className="text-muted-foreground">
                <strong className="text-emerald-400">Demo:</strong> en implementación real, este botón haría deploy
                automático a tu cuenta Netlify con la plantilla configurada.
              </span>
            </div>
            <div className="flex justify-between mt-5">
              <button
                onClick={() => setStep(2)}
                className="surface-2 text-sm py-2 px-4 rounded-lg hover:border-primary/30"
              >
                ← Atrás
              </button>
              <button
                onClick={onClose}
                className="bg-primary text-primary-foreground text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90 flex items-center gap-1.5"
              >
                <Rocket className="w-4 h-4" /> Deploy (demo)
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
