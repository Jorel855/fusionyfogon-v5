'use client';

import { useState } from 'react';
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Image as ImageIcon,
  ShieldCheck,
  ChevronDown,
  ChevronRight,
  Flame as FlameIcon,
  LogOut,
  ExternalLink,
  Eye,
  EyeOff,
} from 'lucide-react';
import { TENANTS } from '@/lib/demo-data';
import { useAuth } from '@/hooks/use-auth';

type ViewKey =
  | 'dashboard'
  | 'pedidos'
  | 'reservas'
  | 'catalogo-platos'
  | 'catalogo-categorias'
  | 'catalogo-sellos'
  | 'contenido-hero'
  | 'contenido-esencia'
  | 'contenido-catering'
  | 'contenido-galeria'
  | 'contenido-pestanas'
  | 'config-dominios'
  | 'config-identidad'
  | 'config-visibilidad'
  | 'config-barra'
  | 'config-redes'
  | 'config-ubicacion'
  | 'config-seo'
  | 'config-notificaciones'
  | 'config-usuarios'
  | 'config-seguridad'
  | 'config-integraciones'
  | 'config-respaldos';

type NavGroup = {
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  items: { key: ViewKey; label: string; badge?: number }[];
};

const NAV: NavGroup[] = [
  {
    label: 'Dashboard',
    icon: LayoutDashboard,
    items: [{ key: 'dashboard', label: 'Resumen del día' }],
  },
  {
    label: 'Operación',
    icon: ShoppingCart,
    items: [
      { key: 'pedidos', label: 'Pedidos', badge: 2 },
      { key: 'reservas', label: 'Reservas', badge: 2 },
    ],
  },
  {
    label: 'Catálogo',
    icon: Package,
    items: [
      { key: 'catalogo-platos', label: 'Platos' },
      { key: 'catalogo-categorias', label: 'Categorías' },
      { key: 'catalogo-sellos', label: 'Sellos de confianza' },
    ],
  },
  {
    label: 'Contenido',
    icon: ImageIcon,
    items: [
      { key: 'contenido-hero', label: 'Hero / Portada' },
      { key: 'contenido-esencia', label: 'Esencia' },
      { key: 'contenido-catering', label: 'Catering' },
      { key: 'contenido-galeria', label: 'Galería de fotos' },
      { key: 'contenido-pestanas', label: 'Pestañas extras' },
    ],
  },
  {
    label: 'Configuración',
    icon: ShieldCheck,
    items: [
      { key: 'config-dominios', label: 'Dominios & Negocio' },
      { key: 'config-identidad', label: 'Identidad visual' },
      { key: 'config-visibilidad', label: 'Visibilidad & Permisos' },
      { key: 'config-barra', label: 'Barra superior' },
      { key: 'config-redes', label: 'Redes sociales' },
      { key: 'config-ubicacion', label: 'Ubicación y horarios' },
      { key: 'config-seo', label: 'SEO' },
      { key: 'config-notificaciones', label: 'Notificaciones WhatsApp' },
      { key: 'config-usuarios', label: 'Usuarios y roles' },
      { key: 'config-seguridad', label: 'Seguridad' },
      { key: 'config-integraciones', label: 'Integraciones' },
      { key: 'config-respaldos', label: 'Respaldos' },
    ],
  },
];

export function AdminShell({
  view,
  onView,
  tenant,
  onTenant,
  children,
}: {
  view: ViewKey;
  onView: (v: ViewKey) => void;
  tenant: string;
  onTenant: (t: string) => void;
  children: React.ReactNode;
}) {
  const [collapsed, setCollapsed] = useState<string[]>([]);
  const [tenantOpen, setTenantOpen] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);

  const currentTenant = TENANTS.find((t) => t.id === tenant) || TENANTS[0];
  const { user, logout } = useAuth();

  const toggle = (label: string) => {
    setCollapsed((c) => (c.includes(label) ? c.filter((x) => x !== label) : [...c, label]));
  };

  const findGroupLabel = (key: ViewKey): string => {
    for (const g of NAV) {
      if (g.items.some((i) => i.key === key)) return g.label;
    }
    return '';
  };
  const currentLabel = NAV.flatMap((g) => g.items).find((i) => i.key === view)?.label || '';
  const currentGroup = findGroupLabel(view);

  return (
    <div className="min-h-screen flex bg-background">
      {/* Sidebar */}
      <aside
        className={`${
          mobileNav ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0 fixed lg:sticky top-0 left-0 z-40 w-72 h-screen bg-sidebar border-r border-sidebar-border flex flex-col transition-transform`}
      >
        {/* Brand */}
        <div className="p-5 border-b border-sidebar-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl brand-gradient flex items-center justify-center brand-glow">
              <FlameIcon className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Panel Admin</p>
              <p className="text-sm font-semibold truncate">Plantilla Multi-Tenant</p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {NAV.map((group) => {
            const isCollapsed = collapsed.includes(group.label);
            const isGroupActive = group.items.some((i) => i.key === view);
            const Icon = group.icon;
            return (
              <div key={group.label} className="mb-1">
                <button
                  onClick={() => toggle(group.label)}
                  className={`w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold uppercase tracking-wider rounded-lg transition-colors ${
                    isGroupActive ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="flex-1 text-left">{group.label}</span>
                  {isCollapsed ? <ChevronRight className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                </button>
                {!isCollapsed && (
                  <div className="mt-1 ml-7 space-y-0.5 border-l border-sidebar-border pl-2">
                    {group.items.map((item) => (
                      <button
                        key={item.key}
                        onClick={() => {
                          onView(item.key);
                          setMobileNav(false);
                        }}
                        className={`w-full flex items-center gap-2 px-3 py-2 text-sm rounded-md transition-all ${
                          view === item.key
                            ? 'bg-primary/10 text-primary font-medium border border-primary/20'
                            : 'text-muted-foreground hover:bg-sidebar-accent hover:text-foreground'
                        }`}
                      >
                        <span className="flex-1 text-left truncate">{item.label}</span>
                        {item.badge ? (
                          <span className="bg-primary text-primary-foreground text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
                            {item.badge}
                          </span>
                        ) : null}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-3 border-t border-sidebar-border space-y-2">
          <div className="flex items-center gap-2 px-3 py-2 rounded-lg surface-2">
            <div className="w-8 h-8 rounded-full brand-gradient flex items-center justify-center text-xs font-bold text-white">
              {user?.nombre?.charAt(0).toUpperCase() || 'A'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium truncate">{user?.nombre || 'Admin'}</p>
              <p className="text-[10px] text-muted-foreground">
                {user?.rol || 'Admin'} · {user?.email?.split('@')[0] || 'admin'}
              </p>
            </div>
            <button
              onClick={async () => {
                await logout()
                window.location.reload()
              }}
              className="text-muted-foreground hover:text-red-400"
              title="Cerrar sesión"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
          <p className="text-[10px] text-center text-muted-foreground">v5.0 · Producción</p>
        </div>
      </aside>

      {/* Mobile overlay */}
      {mobileNav && (
        <div className="fixed inset-0 bg-black/60 z-30 lg:hidden" onClick={() => setMobileNav(false)} />
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Topbar */}
        <header className="sticky top-0 z-20 h-16 border-b border-border bg-background/80 backdrop-blur-md flex items-center px-4 lg:px-6 gap-3">
          <button
            onClick={() => setMobileNav((v) => !v)}
            className="lg:hidden p-2 rounded-md hover:bg-muted"
            aria-label="Menú"
          >
            <ChevronRight className="w-5 h-5" />
          </button>

          {/* Breadcrumb */}
          <div className="hidden sm:flex items-center gap-2 text-sm text-muted-foreground">
            <span>{currentGroup}</span>
            <ChevronRight className="w-3 h-3" />
            <span className="text-foreground font-medium">{currentLabel}</span>
          </div>

          <div className="flex-1" />

          {/* Live update indicator */}
          <div className="hidden md:flex items-center gap-1.5 text-[10px] surface-2 px-2.5 py-1.5 rounded-lg">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 pulse-live" />
            <span className="text-emerald-400 font-medium">Live</span>
            <span className="text-muted-foreground">SSE · cambios publicados al instante</span>
          </div>

          {/* Tenant switcher */}
          <div className="relative">
            <button
              onClick={() => setTenantOpen((v) => !v)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg surface-2 hover:border-primary/30 transition-colors"
            >
              <div
                className="w-7 h-7 rounded-md flex items-center justify-center text-white text-xs font-bold"
                style={{ background: currentTenant.color }}
              >
                {currentTenant.nombre.charAt(0)}
              </div>
              <div className="hidden sm:block text-left">
                <p className="text-xs font-medium leading-tight">{currentTenant.nombre}</p>
                <p className="text-[10px] text-muted-foreground leading-tight">{currentTenant.rubro}</p>
              </div>
              <ChevronDown className="w-4 h-4 text-muted-foreground" />
            </button>
            {tenantOpen && (
              <>
                <div className="fixed inset-0 z-30" onClick={() => setTenantOpen(false)} />
                <div className="absolute right-0 top-full mt-2 w-72 surface rounded-xl shadow-2xl overflow-hidden z-40">
                  <div className="p-2 border-b border-border">
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground px-2 py-1">
                      Cambiar negocio
                    </p>
                  </div>
                  <div className="p-1">
                    {TENANTS.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => {
                          if (!t.isCreate) {
                            onTenant(t.id);
                            setTenantOpen(false);
                          }
                        }}
                        className={`w-full flex items-center gap-3 px-2 py-2 rounded-md hover:bg-muted text-left ${
                          t.id === tenant ? 'bg-primary/10' : ''
                        } ${t.isCreate ? 'border-t border-border mt-1 pt-2 text-primary' : ''}`}
                      >
                        <div
                          className="w-8 h-8 rounded-md flex items-center justify-center text-white text-xs font-bold"
                          style={{ background: t.color }}
                        >
                          {t.isCreate ? '+' : t.nombre.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{t.nombre}</p>
                          <p className="text-[10px] text-muted-foreground truncate">{t.rubro}</p>
                        </div>
                        {t.plan && (
                          <span className="text-[9px] uppercase font-bold text-muted-foreground">{t.plan}</span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>

          <a
            href="https://fusionyfogon.com/"
            target="_blank"
            rel="noreferrer"
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg surface-2 hover:border-primary/30 text-xs"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            Ver web
          </a>
        </header>

        {/* Content */}
        <main className="flex-1 p-4 lg:p-8 overflow-x-hidden">{children}</main>
      </div>
    </div>
  );
}

export type { ViewKey };
