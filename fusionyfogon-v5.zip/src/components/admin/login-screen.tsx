'use client'

import { useState } from 'react'
import { Flame, Mail, Lock, User as UserIcon, Loader2, AlertCircle, Check, ArrowRight } from 'lucide-react'
import { useAuth } from '@/hooks/use-auth'

export function LoginScreen() {
  const { needsSetup, login, setup } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [nombre, setNombre] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    const result = needsSetup
      ? await setup(nombre, email, password)
      : await login(email, password)

    if (result.ok) {
      // Forzar reload para que el middleware lea la cookie y re-renderice
      window.location.reload()
    } else {
      setError(result.error || 'Error desconocido')
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl brand-gradient flex items-center justify-center mx-auto mb-4 brand-glow">
            <Flame className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold">
            {needsSetup ? 'Configuración inicial' : 'Panel Administrativo'}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            {needsSetup
              ? 'Crea el primer usuario administrador'
              : 'Inicia sesión para continuar'}
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="surface rounded-2xl p-6 space-y-4">
          {needsSetup && (
            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3 flex items-start gap-2 text-xs">
              <AlertCircle className="w-3.5 h-3.5 text-blue-400 mt-0.5 flex-shrink-0" />
              <span className="text-muted-foreground">
                <strong className="text-foreground">Setup inicial:</strong> No hay usuarios
                administradores todavía. Crea el primero para empezar. En producción esto se
                reemplaza por Netlify Identity (login con email magic link).
              </span>
            </div>
          )}

          {needsSetup && (
            <label className="block">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                Nombre completo
              </span>
              <div className="relative mt-1">
                <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                  placeholder="Jorel Kales"
                  required
                  className="surface-2 w-full pl-9 pr-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-primary/40"
                />
              </div>
            </label>
          )}

          <label className="block">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
              Email
            </span>
            <div className="relative mt-1">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@fusionyfogon.com"
                required
                className="surface-2 w-full pl-9 pr-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-primary/40"
              />
            </div>
          </label>

          <label className="block">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
              Contraseña
            </span>
            <div className="relative mt-1">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={needsSetup ? 'Mínimo 6 caracteres' : '••••••••'}
                required
                minLength={needsSetup ? 6 : undefined}
                className="surface-2 w-full pl-9 pr-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-primary/40"
              />
            </div>
          </label>

          {error && (
            <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 flex items-center gap-2 text-xs text-red-400">
              <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-primary text-primary-foreground font-medium py-2.5 rounded-lg hover:opacity-90 disabled:opacity-40 flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" /> Procesando...
              </>
            ) : (
              <>
                {needsSetup ? 'Crear cuenta admin' : 'Iniciar sesión'}
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>

          {!needsSetup && (
            <div className="text-center text-xs text-muted-foreground">
              <button type="button" className="hover:text-primary">
                ¿Olvidaste tu contraseña?
              </button>
            </div>
          )}
        </form>

        {/* Info footer */}
        <div className="mt-6 text-center text-[10px] text-muted-foreground space-y-1">
          <p>
            <Check className="w-3 h-3 inline text-emerald-400" /> Sesión cifrada con JWT (7 días)
          </p>
          <p>
            <Check className="w-3 h-3 inline text-emerald-400" /> Contraseña hasheada con bcrypt
          </p>
          <p>
            <Check className="w-3 h-3 inline text-emerald-400" /> Roles: Admin · Editor · Cajero · Cocina
          </p>
        </div>
      </div>
    </div>
  )
}
