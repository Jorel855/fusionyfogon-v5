'use client'

import { useEffect } from 'react'

export function PWARegister() {
  useEffect(() => {
    if (typeof window === 'undefined') return
    if (!('serviceWorker' in navigator)) return

    // Solo registrar en producción (en dev causa problemas con cache)
    if (process.env.NODE_ENV !== 'production') return

    const register = async () => {
      try {
        const reg = await navigator.serviceWorker.register('/sw.js', {
          scope: '/',
          updateViaCache: 'none',
        })

        // Escucha actualizaciones del SW
        reg.addEventListener('updatefound', () => {
          const newWorker = reg.installing
          if (!newWorker) return
          newWorker.addEventListener('statechange', () => {
            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
              // Nueva versión disponible — notifica al usuario
              console.log('[PWA] Nueva versión disponible. Recarga para actualizar.')
              // Dispara evento personalizado que el admin puede escuchar
              window.dispatchEvent(new CustomEvent('sw-update-available'))
            }
          })
        })

        // Listen for messages from SW
        navigator.serviceWorker.addEventListener('message', (event) => {
          if (event.data?.type === 'SYNC_COMPLETE') {
            console.log('[PWA] Background sync completed:', event.data.tag)
            window.dispatchEvent(new CustomEvent('sw-sync-complete', { detail: event.data }))
          }
        })
      } catch (err) {
        console.error('[PWA] SW registration failed:', err)
      }
    }

    // Registra después de que la página carga (no bloquea FCP)
    window.addEventListener('load', register)

    return () => window.removeEventListener('load', register)
  }, [])

  return null
}
