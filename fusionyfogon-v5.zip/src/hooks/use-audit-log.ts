'use client'

import { useState, useEffect, useCallback } from 'react'

const TOKEN_KEY = 'fyf_admin_token'

export type AuditLog = {
  id: string
  usuario: string
  accion: string
  entidad: string
  entidadId: string | null
  detalle: string
  fecha: string
}

export function useAuditLog(limit: number = 50) {
  const [logs, setLogs] = useState<AuditLog[]>([])
  const [loading, setLoading] = useState(true)

  const fetchLogs = useCallback(async () => {
    setLoading(true)
    try {
      const token = typeof window !== 'undefined' ? localStorage.getItem(TOKEN_KEY) : null
      const res = await fetch(`/api/audit-log?limit=${limit}`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      })
      const d = await res.json()
      if (d.ok) setLogs(d.logs)
    } catch {
      // ignore
    } finally {
      setLoading(false)
    }
  }, [limit])

  useEffect(() => {
    fetchLogs()
  }, [fetchLogs])

  return { logs, loading, refetch: fetchLogs }
}
