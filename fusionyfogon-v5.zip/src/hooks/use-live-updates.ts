'use client'

import { useEffect, useCallback, useRef } from 'react'

type EventType = 'menu:updated' | 'sellos:updated' | 'pedido:created' | 'pedido:updated' | 'reserva:created' | 'empresa:updated'

type LiveUpdateCallback = (event: { channel: EventType; [key: string]: any }) => void

/**
 * Hook para suscribirse a actualizaciones en tiempo real.
 *
 * Estrategia dual:
 * 1. Server-Sent Events (SSE) — intenta conexión en tiempo real
 * 2. Polling inteligente (fallback) — si SSE falla, consulta cada 30s
 *
 * En producción con Netlify, el polling garantiza que los cambios
 * se reflejen aunque el SSE no cruce entre instancias serverless.
 */
export function useLiveUpdates(onUpdate: LiveUpdateCallback) {
  const stableCallback = useCallback(onUpdate, [onUpdate])
  const lastCheckRef = useRef<number>(Date.now())

  useEffect(() => {
    if (typeof window === 'undefined') return

    let eventSource: EventSource | null = null
    let pollingInterval: NodeJS.Timeout | null = null

    // Estrategia 1: SSE (intento de tiempo real)
    try {
      eventSource = new EventSource('/api/events')
      eventSource.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data)
          if (data.channel) {
            stableCallback(data)
            lastCheckRef.current = Date.now()
          }
        } catch (err) {
          // Ignorar heartbeats
        }
      }
      eventSource.onerror = () => {
        // SSE falló — el polling tomará el relevo
      }
    } catch (e) {
      // EventSource no soportado — usar solo polling
    }

    // Estrategia 2: Polling inteligente cada 30 segundos
    // Esto garantiza que los cambios se reflejen aunque SSE no funcione
    pollingInterval = setInterval(async () => {
      try {
        // Consultar si hay cambios comparando timestamps
        const res = await fetch('/api/last-update', {
          headers: { 'Cache-Control': 'no-cache' },
        })
        if (res.ok) {
          const data = await res.json()
          if (data.ok && data.timestamp > lastCheckRef.current) {
            // Hubo cambios — disparar evento genérico
            stableCallback({
              channel: data.channel || 'menu:updated',
              timestamp: data.timestamp,
              source: 'polling',
            })
            lastCheckRef.current = Date.now()
          }
        }
      } catch (e) {
        // Silencioso — el polling es best-effort
      }
    }, 30000) // cada 30 segundos

    return () => {
      if (eventSource) eventSource.close()
      if (pollingInterval) clearInterval(pollingInterval)
    }
  }, [stableCallback])
}
