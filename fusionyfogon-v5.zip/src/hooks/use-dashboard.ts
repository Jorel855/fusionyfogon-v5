'use client'

import { useState, useEffect, useCallback } from 'react'

const TOKEN_KEY = 'fyf_admin_token'

export type DashboardData = {
  kpis: {
    ventasHoy: number
    pedidosHoy: number
    reservasHoy: number
    visitasHoy: number
    totalPedidos: number
  }
  ventas30dias: { fecha: string; total: number }[]
  topPlatos: { id: string; nombre: string; ventas: number; precio: number }[]
  pedidosPendientes: {
    id: string
    codigo: string
    cliente: string
    detalle: string
    total: number
    telefono: string | null
    fecha: string
  }[]
  proximasReservas: {
    id: string
    codigo: string
    nombre: string
    fecha: string
    hora: string
    personas: number
    estado: string
    celular: string
  }[]
}

export function useDashboard() {
  const [data, setData] = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchDashboard = useCallback(async () => {
    setLoading(true)
    try {
      const token = typeof window !== 'undefined' ? localStorage.getItem(TOKEN_KEY) : null
      const res = await fetch('/api/dashboard', {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      })
      const d = await res.json()
      if (d.ok) {
        setData(d)
        setError(null)
      } else {
        setError(d.error || 'Error')
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Error de red')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchDashboard()
  }, [fetchDashboard])

  return { data, loading, error, refetch: fetchDashboard }
}
