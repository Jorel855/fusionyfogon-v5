'use client'

import { useState, useEffect, useCallback } from 'react'

export type Reserva = {
  id: string
  codigo: string
  nombre: string
  celular: string
  email: string | null
  fecha: string
  hora: string
  personas: number
  estado: string
  profesional: string | null
  servicioId: string | null
  notas: string | null
}

export function useReservas() {
  const [reservas, setReservas] = useState<Reserva[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchReservas = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/reservas')
      const d = await res.json()
      if (d.ok) setReservas(d.reservas)
      setError(null)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Error')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchReservas()
  }, [fetchReservas])

  return { reservas, loading, error, refetch: fetchReservas }
}
