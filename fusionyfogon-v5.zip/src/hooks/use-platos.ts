'use client'

import { useState, useEffect, useCallback } from 'react'

const TOKEN_KEY = 'fyf_admin_token'

export type Plato = {
  id: string
  slug: string
  nombre: string
  descripcion: string | null
  precio: number
  badge: string | null
  imagenUrl: string | null
  visible: boolean
  orden: number
  ventas: number
  categoria: { id: string; slug: string; nombre: string; icono: string } | null
  programa: { activo: boolean; desde: string | null; hasta: string | null } | null
}

export function usePlatos() {
  const [platos, setPlatos] = useState<Plato[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const authHeaders = (): HeadersInit => {
    const token = typeof window !== 'undefined' ? localStorage.getItem(TOKEN_KEY) : null
    return token ? { Authorization: `Bearer ${token}` } : {}
  }

  const fetchPlatos = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/platos', { headers: authHeaders() })
      const d = await res.json()
      if (d.ok) setPlatos(d.platos)
      setError(null)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Error')
    } finally {
      setLoading(false)
    }
  }, [])

  const toggleVisible = useCallback(async (id: string, visible: boolean) => {
    setPlatos((prev) => prev.map((p) => (p.id === id ? { ...p, visible } : p)))
    const res = await fetch(`/api/platos/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ visible, usuario: 'Admin' }),
    })
    return res.ok
  }, [authHeaders])

  const actualizarPrograma = useCallback(
    async (id: string, programa: { activo: boolean; desde?: string; hasta?: string }) => {
      const res = await fetch(`/api/platos/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({ programa, usuario: 'Admin' }),
      })
      if (res.ok) {
        setPlatos((prev) =>
          prev.map((p) =>
            p.id === id
              ? { ...p, programa: { activo: programa.activo, desde: programa.desde || null, hasta: programa.hasta || null } }
              : p
          )
        )
      }
      return res.ok
    },
    [authHeaders]
  )

  useEffect(() => {
    fetchPlatos()
  }, [fetchPlatos])

  return { platos, loading, error, refetch: fetchPlatos, toggleVisible, actualizarPrograma }
}
