'use client'

import { useState, useEffect, useCallback } from 'react'

export type AuthUser = {
  id: string
  email: string
  nombre: string
  rol: 'Admin' | 'Editor' | 'Cajero' | 'Cocina'
}

const TOKEN_KEY = 'fyf_admin_token'

export function useAuth() {
  const [user, setUser] = useState<AuthUser | null>(null)
  const [loading, setLoading] = useState(true)
  const [needsSetup, setNeedsSetup] = useState(false)

  // Verifica si hay sesión al montar
  useEffect(() => {
    // Primero verifica si hay que hacer setup
    fetch('/api/auth/status')
      .then((r) => r.json())
      .then((data) => {
        if (data.ok && data.needsSetup) {
          setNeedsSetup(true)
          setLoading(false)
          return
        }
        // Si hay admin, verifica si hay sesión
        const token = localStorage.getItem(TOKEN_KEY)
        if (!token) {
          setLoading(false)
          return
        }
        fetch('/api/auth/me', {
          headers: { Authorization: `Bearer ${token}` },
        })
          .then((r) => r.json())
          .then((data) => {
            if (data.ok) {
              setUser(data.user)
            } else {
              localStorage.removeItem(TOKEN_KEY)
            }
          })
          .catch(() => {
            localStorage.removeItem(TOKEN_KEY)
          })
          .finally(() => setLoading(false))
      })
      .catch(() => setLoading(false))
  }, [])

  const login = useCallback(async (email: string, password: string) => {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    })
    const data = await res.json()
    if (data.ok) {
      localStorage.setItem(TOKEN_KEY, data.token)
      // Cookie para que el middleware la lea (httpOnly=false porque la lee el cliente)
      document.cookie = `${TOKEN_KEY}=${data.token}; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Lax`
      setUser(data.user)
      return { ok: true }
    }
    return { ok: false, error: data.error }
  }, [])

  const setup = useCallback(async (nombre: string, email: string, password: string) => {
    const res = await fetch('/api/auth/setup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre, email, password }),
    })
    const data = await res.json()
    if (data.ok) {
      localStorage.setItem(TOKEN_KEY, data.token)
      document.cookie = `${TOKEN_KEY}=${data.token}; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Lax`
      setUser(data.user)
      return { ok: true }
    }
    return { ok: false, error: data.error }
  }, [])

  const logout = useCallback(async () => {
    const token = localStorage.getItem(TOKEN_KEY)
    if (token) {
      fetch('/api/auth/logout', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      }).catch(() => {})
    }
    localStorage.removeItem(TOKEN_KEY)
    // Borrar cookie
    document.cookie = `${TOKEN_KEY}=; path=/; max-age=0`
    setUser(null)
  }, [])

  // Helper para hacer fetch autenticado
  const authFetch = useCallback(async (url: string, options: RequestInit = {}) => {
    const token = localStorage.getItem(TOKEN_KEY)
    if (!token) throw new Error('No autenticado')
    return fetch(url, {
      ...options,
      headers: {
        ...options.headers,
        Authorization: `Bearer ${token}`,
      },
    })
  }, [])

  return { user, loading, needsSetup, setNeedsSetup, login, setup, logout, authFetch }
}
