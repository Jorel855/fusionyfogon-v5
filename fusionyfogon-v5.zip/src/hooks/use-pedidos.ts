'use client'

import { useState, useEffect, useCallback } from 'react'

const TOKEN_KEY = 'fyf_admin_token'

export type Pedido = {
  id: string
  codigo: string
  cliente: string
  telefono: string | null
  direccion: string | null
  notas: string | null
  detalle: string
  total: number
  estado: 'Pendiente' | 'Confirmado' | 'Preparacion' | 'Listo' | 'Entregado' | 'Cancelado'
  whatsappEnviado: boolean
  whatsappLeido: boolean
  origen: string
  fecha: string
}

export function usePedidos() {
  const [pedidos, setPedidos] = useState<Pedido[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const authHeaders = (): HeadersInit => {
    const token = typeof window !== 'undefined' ? localStorage.getItem(TOKEN_KEY) : null
    return token ? { Authorization: `Bearer ${token}` } : {}
  }

  const fetchPedidos = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/pedidos', { headers: authHeaders() })
      const data = await res.json()
      if (data.ok) {
        setPedidos(data.pedidos)
        setError(null)
      } else {
        setError(data.error || 'Error desconocido')
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Error de red')
    } finally {
      setLoading(false)
    }
  }, [])

  const cambiarEstado = useCallback(async (id: string, estado: Pedido['estado']) => {
    const res = await fetch(`/api/pedidos/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ estado, usuario: 'Admin' }),
    })
    const data = await res.json()
    if (data.ok) {
      setPedidos((prev) => prev.map((p) => (p.id === id ? { ...p, estado, whatsappEnviado: data.pedido?.whatsappEnviado ?? p.whatsappEnviado } : p)))
      return true
    }
    return false
  }, [])

  useEffect(() => {
    fetchPedidos()
  }, [fetchPedidos])

  return { pedidos, loading, error, refetch: fetchPedidos, cambiarEstado }
}
