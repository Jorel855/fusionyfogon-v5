'use client'

import { useState, useEffect, useCallback } from 'react'

const TOKEN_KEY = 'fyf_admin_token'

export type Sello = {
  id: string
  emoji: string
  texto: string
  orden: number
  visible: boolean
}

export function useSellos() {
  const [sellos, setSellos] = useState<Sello[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const authHeaders = (): HeadersInit => {
    const token = typeof window !== 'undefined' ? localStorage.getItem(TOKEN_KEY) : null
    return token ? { Authorization: `Bearer ${token}` } : {}
  }

  const fetchSellos = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/sellos', { headers: authHeaders() })
      const d = await res.json()
      if (d.ok) setSellos(d.sellos)
      setError(null)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Error')
    } finally {
      setLoading(false)
    }
  }, [])

  const toggleVisible = useCallback(async (id: string, visible: boolean) => {
    setSellos((prev) => prev.map((s) => (s.id === id ? { ...s, visible } : s)))
    await fetch(`/api/sellos/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ visible }),
    })
  }, [authHeaders])

  const mover = useCallback(
    async (id: string, dir: 'up' | 'down') => {
      setSellos((prev) => {
        const idx = prev.findIndex((s) => s.id === id)
        if (idx < 0) return prev
        const newIdx = dir === 'up' ? idx - 1 : idx + 1
        if (newIdx < 0 || newIdx >= prev.length) return prev
        const copy = [...prev]
        ;[copy[idx], copy[newIdx]] = [copy[newIdx], copy[idx]]
        copy.forEach((s, i) => {
          fetch(`/api/sellos/${s.id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json', ...authHeaders() },
            body: JSON.stringify({ orden: i }),
          })
        })
        return copy
      })
    },
    [authHeaders]
  )

  useEffect(() => {
    fetchSellos()
  }, [fetchSellos])

  return { sellos, loading, error, refetch: fetchSellos, toggleVisible, mover }
}
