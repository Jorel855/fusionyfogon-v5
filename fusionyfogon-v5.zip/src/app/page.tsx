'use client'

import { useState, useEffect, useCallback } from 'react'
import {
  Flame, ShoppingCart, CalendarCheck, ChefHat, MapPin, MessageCircle,
  Phone, Clock, Mail, Facebook, Instagram, ArrowLeft, Plus, Minus, X,
  Check, Leaf, TreePine, Utensils, Star, ChevronRight, AlertCircle,
  Loader2, Send,
} from 'lucide-react'
import { useLiveUpdates } from '@/hooks/use-live-updates'

// ============================================
// TIPOS
// ============================================
type Empresa = {
  nombre: string; tagline: string | null; telefono: string | null;
  whatsapp: string | null; email: string | null; direccion: string | null;
  horarios: string | null; facebook: string | null; instagram: string | null;
  tiktok: string | null; mapsUrl: string | null;
}
type Sello = { emoji: string; texto: string }
type Plato = {
  id: string; nombre: string; descripcion: string | null; precio: number;
  badge: string | null; imagen: string | null; categoria: string | null;
}
type Categoria = { id: string; nombre: string; icono: string }
type Screen = 'home' | 'carta' | 'carrito' | 'checkout' | 'reservas' | 'agenda' | 'esencia' | 'catering' | 'contacto'

// ============================================
// COMPONENTE PRINCIPAL
// ============================================
export default function HomePage() {
  const [screen, setScreen] = useState<Screen>('home')
  const [empresa, setEmpresa] = useState<Empresa | null>(null)
  const [sellos, setSellos] = useState<Sello[]>([])
  const [platos, setPlatos] = useState<Plato[]>([])
  const [categorias, setCategorias] = useState<Categoria[]>([])
  const [loading, setLoading] = useState(true)
  const [carrito, setCarrito] = useState<{[id: string]: { plato: Plato; cantidad: number }}>({})

  useEffect(() => {
    fetch('/api/menu/all')
      .then((r) => r.json())
      .then((data) => {
        if (data.ok) {
          setSellos(data.sellos || [])
          setPlatos(data.menu?.platos?.filter((p: Plato) => p.visible !== false) || [])
          setCategorias(data.menu?.categorias?.filter((c: Categoria) => c.visible !== false) || [])
        }
      }).catch(() => {})
    fetch('/api/empresa')
      .then((r) => r.json())
      .then((data) => { if (data.ok) setEmpresa(data.empresa) })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  const whatsappUrl = empresa?.whatsapp
    ? `https://wa.me/${empresa.whatsapp.replace(/[^0-9]/g, '')}`
    : 'https://wa.me/573508029292'

  const carritoCount = Object.values(carrito).reduce((a, b) => a + b.cantidad, 0)
  const carritoTotal = Object.values(carrito).reduce((a, b) => a + b.cantidad * b.plato.precio, 0)

  // 🔄 Sincronización en tiempo real: cuando el admin hace cambios, se refrescan los datos
  const fetchData = useCallback(() => {
    fetch('/api/menu/all')
      .then((r) => r.json())
      .then((data) => {
        if (data.ok) {
          setSellos(data.sellos || [])
          setPlatos(data.menu?.platos?.filter((p: Plato) => p.visible !== false) || [])
          setCategorias(data.menu?.categorias?.filter((c: Categoria) => c.visible !== false) || [])
        }
      })
      .catch(() => {})
    fetch('/api/empresa')
      .then((r) => r.json())
      .then((data) => { if (data.ok) setEmpresa(data.empresa) })
      .catch(() => {})
  }, [])

  useLiveUpdates((event) => {
    if (event.channel === 'menu:updated' || event.channel === 'sellos:updated' || event.channel === 'empresa:updated') {
      // Refrescar datos cuando el admin hace cambios
      fetchData()
    }
  })

  const addToCart = (plato: Plato) => {
    setCarrito((prev) => ({
      ...prev,
      [plato.id]: { plato, cantidad: (prev[plato.id]?.cantidad || 0) + 1 }
    }))
  }
  const removeFromCart = (id: string) => {
    setCarrito((prev) => {
      const next = { ...prev }
      if (next[id]?.cantidad > 1) next[id].cantidad--
      else delete next[id]
      return next
    })
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Flame className="w-16 h-16 text-primary mx-auto mb-4 flame-flicker" />
          <p className="text-sm text-muted-foreground">Cargando...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {screen === 'home' && (
        <HomeScreen
          empresa={empresa}
          sellos={sellos}
          onNavigate={setScreen}
          whatsappUrl={whatsappUrl}
        />
      )}
      {screen === 'carta' && (
        <CartaScreen
          platos={platos}
          categorias={categorias}
          carrito={carrito}
          carritoCount={carritoCount}
          carritoTotal={carritoTotal}
          onAdd={addToCart}
          onRemove={removeFromCart}
          onBack={() => setScreen('home')}
          onVerPedido={() => setScreen('carrito')}
        />
      )}
      {screen === 'carrito' && (
        <CarritoScreen
          carrito={carrito}
          carritoTotal={carritoTotal}
          onRemove={removeFromCart}
          onBack={() => setScreen('carta')}
          onCheckout={() => setScreen('checkout')}
        />
      )}
      {screen === 'checkout' && (
        <CheckoutScreen
          carrito={carrito}
          carritoTotal={carritoTotal}
          empresa={empresa}
          onBack={() => setScreen('carrito')}
          onSuccess={() => { setCarrito({}); setScreen('home') }}
        />
      )}
      {screen === 'reservas' && (
        <ReservasScreen empresa={empresa} onBack={() => setScreen('home')} />
      )}
      {screen === 'agenda' && (
        <AgendaScreen empresa={empresa} onBack={() => setScreen('home')} />
      )}
      {screen === 'esencia' && (
        <EsenciaScreen empresa={empresa} onBack={() => setScreen('home')} />
      )}
      {screen === 'catering' && (
        <CateringScreen empresa={empresa} whatsappUrl={whatsappUrl} onBack={() => setScreen('home')} />
      )}
      {screen === 'contacto' && (
        <ContactoScreen empresa={empresa} whatsappUrl={whatsappUrl} onBack={() => setScreen('home')} />
      )}
    </div>
  )
}

// ============================================
// PANTALLA 1: HOME
// ============================================
function HomeScreen({ empresa, sellos, onNavigate, whatsappUrl }: {
  empresa: Empresa | null
  sellos: Sello[]
  onNavigate: (s: Screen) => void
  whatsappUrl: string
}) {
  return (
    <div className="screen-enter min-h-screen flex flex-col items-center justify-center px-6 py-12 max-w-md mx-auto">
      {/* Logo */}
      <div className="text-center mb-10">
        <div className="w-28 h-28 rounded-3xl brand-gradient flex items-center justify-center mx-auto mb-6 brand-glow flame-flicker">
          <Flame className="w-14 h-14 text-white" />
        </div>
        <h1 className="text-3xl font-bold tracking-wider mb-2 font-display">
          {empresa?.nombre || 'FUSIÓN Y FOGÓN'}
        </h1>
        <p className="text-sm text-muted-foreground tracking-widest uppercase font-display">
          {empresa?.tagline || 'Sabores que unen culturas'}
        </p>
      </div>

      {/* Sellos de confianza */}
      {sellos.length > 0 && (
        <div className="flex flex-wrap gap-2 justify-center mb-8">
          {sellos.map((s, i) => (
            <span key={i} className="text-[10px] bg-primary/10 border border-primary/20 rounded-full px-2.5 py-1 flex items-center gap-1">
              <span>{s.emoji}</span>
              <span className="font-medium">{s.texto}</span>
            </span>
          ))}
        </div>
      )}

      {/* Botones principales */}
      <div className="w-full space-y-3">
        <button
          onClick={() => onNavigate('carta')}
          className="home-btn w-full py-5 rounded-2xl flex items-center gap-4 px-6 text-left"
        >
          <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
            <ShoppingCart className="w-6 h-6 text-primary" />
          </div>
          <div className="flex-1">
            <p className="text-base font-semibold font-display tracking-wide">VER MENÚ Y HACER PEDIDO</p>
            <p className="text-[11px] text-muted-foreground">Ahumados, chorizos y más</p>
          </div>
          <ChevronRight className="w-5 h-5 text-muted-foreground" />
        </button>

        <button
          onClick={() => onNavigate('agenda')}
          className="home-btn w-full py-5 rounded-2xl flex items-center gap-4 px-6 text-left"
        >
          <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
            <CalendarCheck className="w-6 h-6 text-primary" />
          </div>
          <div className="flex-1">
            <p className="text-base font-semibold font-display tracking-wide">SOLICITAR DISPONIBILIDAD</p>
            <p className="text-[11px] text-muted-foreground">Agenda y disponibilidad</p>
          </div>
          <ChevronRight className="w-5 h-5 text-muted-foreground" />
        </button>

        <button
          onClick={() => onNavigate('esencia')}
          className="home-btn w-full py-5 rounded-2xl flex items-center gap-4 px-6 text-left"
        >
          <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
            <Flame className="w-6 h-6 text-primary" />
          </div>
          <div className="flex-1">
            <p className="text-base font-semibold font-display tracking-wide">NUESTRA ESENCIA</p>
            <p className="text-[11px] text-muted-foreground">Historia, misión y visión</p>
          </div>
          <ChevronRight className="w-5 h-5 text-muted-foreground" />
        </button>

        <button
          onClick={() => onNavigate('catering')}
          className="home-btn w-full py-5 rounded-2xl flex items-center gap-4 px-6 text-left"
        >
          <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
            <ChefHat className="w-6 h-6 text-primary" />
          </div>
          <div className="flex-1">
            <p className="text-base font-semibold font-display tracking-wide">EXPERIENCIAS Y CATERING</p>
            <p className="text-[11px] text-muted-foreground">Ahumados en vivo para eventos</p>
          </div>
          <ChevronRight className="w-5 h-5 text-muted-foreground" />
        </button>

        <button
          onClick={() => onNavigate('contacto')}
          className="home-btn w-full py-5 rounded-2xl flex items-center gap-4 px-6 text-left"
        >
          <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
            <MapPin className="w-6 h-6 text-primary" />
          </div>
          <div className="flex-1">
            <p className="text-base font-semibold font-display tracking-wide">CONTACTO Y UBICACIÓN</p>
            <p className="text-[11px] text-muted-foreground">Cómo llegar y horarios</p>
          </div>
          <ChevronRight className="w-5 h-5 text-muted-foreground" />
        </button>

        <button
          onClick={() => onNavigate('reservas')}
          className="home-btn w-full py-5 rounded-2xl flex items-center gap-4 px-6 text-left"
        >
          <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
            <CalendarCheck className="w-6 h-6 text-primary" />
          </div>
          <div className="flex-1">
            <p className="text-base font-semibold font-display tracking-wide">RESERVA DE MESA</p>
            <p className="text-[11px] text-muted-foreground">Reserva por fecha y hora</p>
          </div>
          <ChevronRight className="w-5 h-5 text-muted-foreground" />
        </button>

        <a
          href={whatsappUrl}
          target="_blank"
          rel="noreferrer"
          className="home-btn-whatsapp w-full py-5 rounded-2xl flex items-center gap-4 px-6 text-left transition-all"
        >
          <div className="w-12 h-12 rounded-xl bg-[#25D366]/20 flex items-center justify-center flex-shrink-0">
            <MessageCircle className="w-6 h-6 text-[#25D366]" />
          </div>
          <div className="flex-1">
            <p className="text-base font-semibold font-display tracking-wide">WHATSAPP DIRECTO</p>
            <p className="text-[11px] text-muted-foreground">Escríbenos ahora</p>
          </div>
          <ChevronRight className="w-5 h-5 text-muted-foreground" />
        </a>
      </div>

      {/* Iconos de redes sociales */}
      {(empresa?.facebook || empresa?.instagram || empresa?.tiktok) && (
        <div className="flex items-center justify-center gap-3 mt-8">
          {empresa?.facebook && (
            <a href={empresa.facebook} target="_blank" rel="noreferrer"
              className="w-11 h-11 rounded-full surface-2 flex items-center justify-center hover:border-primary/40 transition-colors"
              title="Facebook">
              <Facebook className="w-5 h-5 text-[#1877F2]" />
            </a>
          )}
          {empresa?.instagram && (
            <a href={empresa.instagram} target="_blank" rel="noreferrer"
              className="w-11 h-11 rounded-full surface-2 flex items-center justify-center hover:border-primary/40 transition-colors"
              title="Instagram">
              <Instagram className="w-5 h-5 text-[#E4405F]" />
            </a>
          )}
          {empresa?.tiktok && (
            <a href={empresa.tiktok} target="_blank" rel="noreferrer"
              className="w-11 h-11 rounded-full surface-2 flex items-center justify-center hover:border-primary/40 transition-colors"
              title="TikTok">
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5.8 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1.84-.1z"/></svg>
            </a>
          )}
          <a href={whatsappUrl} target="_blank" rel="noreferrer"
            className="w-11 h-11 rounded-full surface-2 flex items-center justify-center hover:border-primary/40 transition-colors"
            title="WhatsApp">
            <MessageCircle className="w-5 h-5 text-[#25D366]" />
          </a>
        </div>
      )}

      {/* Footer */}
      <div className="mt-8 text-center text-[10px] text-muted-foreground space-y-1">
        <p>{empresa?.direccion || 'Finca El Jazmín - Vereda Puyana, Lebrija - Santander'}</p>
        <p>WhatsApp: {empresa?.whatsapp || '+57 350 802 9292'} | Email: {empresa?.email || 'contacto@fusionyfogon.com'}</p>
        <p className="text-primary/60 mt-2">⚡ Programado por Jorel Kales · Diseño & Sistema Web</p>
      </div>
    </div>
  )
}

// ============================================
// PANTALLA 2: CARTA
// ============================================
function CartaScreen({ platos, categorias, carrito, carritoCount, carritoTotal, onAdd, onRemove, onBack, onVerPedido }: {
  platos: Plato[]
  categorias: Categoria[]
  carrito: {[id: string]: { plato: Plato; cantidad: number }}
  carritoCount: number
  carritoTotal: number
  onAdd: (p: Plato) => void
  onRemove: (id: string) => void
  onBack: () => void
  onVerPedido: () => void
}) {
  const [activeCat, setActiveCat] = useState<string>(categorias[0]?.id || '')

  const platosFiltrados = activeCat
    ? platos.filter((p) => p.categoria === activeCat)
    : platos

  return (
    <div className="screen-enter min-h-screen pb-28">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-background/90 backdrop-blur-md border-b border-border">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center gap-3">
          <button onClick={onBack} className="p-2 rounded-lg hover:bg-muted">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-semibold font-display tracking-wide flex-1">Nuestra Carta</h1>
        </div>
        {/* Categorías tabs */}
        <div className="max-w-md mx-auto px-4 pb-3 flex gap-2 overflow-x-auto">
          {categorias.map((c) => (
            <button
              key={c.id}
              onClick={() => setActiveCat(c.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                activeCat === c.id
                  ? 'bg-primary text-primary-foreground'
                  : 'surface-2 text-muted-foreground hover:text-foreground'
              }`}
            >
              <span>{c.icono}</span>
              <span>{c.nombre}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Grid de platos */}
      <div className="max-w-md mx-auto px-4 py-4 grid grid-cols-2 gap-3">
        {platosFiltrados.map((p) => (
          <div key={p.id} className="surface rounded-xl overflow-hidden">
            <div className="aspect-square relative overflow-hidden bg-gradient-to-br from-primary/20 to-secondary">
              {p.imagen && !p.imagen.startsWith('data:') ? (
                <img src={p.imagen} alt={p.nombre} className="w-full h-full object-cover" />
              ) : (
                <div className="absolute inset-0 flex items-center justify-center text-5xl opacity-50">
                  {categorias.find((c) => c.id === p.categoria)?.icono || '🍽️'}
                </div>
              )}
              {p.badge && (
                <span className="absolute top-2 left-2 bg-black/70 backdrop-blur text-[9px] font-bold px-2 py-0.5 rounded-full text-white">
                  {p.badge}
                </span>
              )}
            </div>
            <div className="p-3">
              <h3 className="text-sm font-semibold leading-tight mb-1 line-clamp-2">{p.nombre}</h3>
              {p.descripcion && (
                <p className="text-[10px] text-muted-foreground mb-2 line-clamp-2">{p.descripcion}</p>
              )}
              <div className="flex items-center justify-between mb-2">
                <span className="text-base font-bold text-primary">${p.precio.toLocaleString('es-CO')}</span>
              </div>
              {carrito[p.id] ? (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onRemove(p.id)}
                    className="flex-1 surface-2 py-1.5 rounded-lg text-xs font-medium hover:bg-muted flex items-center justify-center gap-1"
                  >
                    <Minus className="w-3 h-3" /> {carrito[p.id].cantidad}
                  </button>
                  <button
                    onClick={() => onAdd(p)}
                    className="flex-1 bg-primary text-primary-foreground py-1.5 rounded-lg text-xs font-medium flex items-center justify-center gap-1"
                  >
                    <Plus className="w-3 h-3" /> Agregar
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => onAdd(p)}
                  className="w-full bg-primary text-primary-foreground py-1.5 rounded-lg text-xs font-medium flex items-center justify-center gap-1"
                >
                  <Plus className="w-3 h-3" /> Agregar
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Carrito flotante */}
      {carritoCount > 0 && (
        <div className="fixed bottom-4 left-4 right-4 max-w-md mx-auto z-30">
          <button
            onClick={onVerPedido}
            className="w-full bg-primary text-primary-foreground py-4 rounded-2xl flex items-center justify-between px-5 shadow-2xl brand-glow"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-primary-foreground/20 flex items-center justify-center text-xs font-bold">
                {carritoCount}
              </div>
              <span className="font-semibold font-display tracking-wide">Ver pedido</span>
            </div>
            <span className="font-bold">${carritoTotal.toLocaleString('es-CO')}</span>
          </button>
        </div>
      )}
    </div>
  )
}

// ============================================
// PANTALLA 3: CARRITO
// ============================================
function CarritoScreen({ carrito, carritoTotal, onRemove, onBack, onCheckout }: {
  carrito: {[id: string]: { plato: Plato; cantidad: number }}
  carritoTotal: number
  onRemove: (id: string) => void
  onBack: () => void
  onCheckout: () => void
}) {
  const items = Object.values(carrito)

  return (
    <div className="screen-enter min-h-screen pb-28">
      <div className="sticky top-0 z-20 bg-background/90 backdrop-blur-md border-b border-border">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center gap-3">
          <button onClick={onBack} className="p-2 rounded-lg hover:bg-muted">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-semibold font-display tracking-wide flex-1">Tu pedido</h1>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 py-4">
        {items.length === 0 ? (
          <div className="text-center py-20">
            <ShoppingCart className="w-16 h-16 text-muted-foreground/50 mx-auto mb-4" />
            <p className="text-sm text-muted-foreground">Tu carrito está vacío</p>
          </div>
        ) : (
          <>
            <div className="space-y-2 mb-6">
              {items.map(({ plato, cantidad }) => (
                <div key={plato.id} className="surface rounded-xl p-3 flex items-center gap-3">
                  <div className="w-14 h-14 rounded-lg bg-primary/10 flex items-center justify-center text-2xl flex-shrink-0">
                    {plato.categoria === 'ahumados' ? '🥩' : plato.categoria === 'embutidos' ? '🌭' : '🍽️'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium leading-tight">{plato.nombre}</p>
                    <p className="text-xs text-primary font-semibold">${plato.precio.toLocaleString('es-CO')} c/u</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onRemove(plato.id)}
                      className="w-7 h-7 rounded-md surface-2 flex items-center justify-center hover:bg-muted"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="text-sm font-semibold w-6 text-center">{cantidad}</span>
                    <div className="text-right">
                      <p className="text-sm font-bold">${(plato.precio * cantidad).toLocaleString('es-CO')}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="surface rounded-xl p-4 mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Subtotal</span>
                <span className="text-sm">${carritoTotal.toLocaleString('es-CO')}</span>
              </div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Domicilio</span>
                <span className="text-sm text-emerald-400">A coordinar</span>
              </div>
              <div className="border-t border-border pt-2 mt-2 flex items-center justify-between">
                <span className="text-base font-semibold">Total</span>
                <span className="text-xl font-bold text-primary">${carritoTotal.toLocaleString('es-CO')}</span>
              </div>
            </div>
          </>
        )}
      </div>

      {items.length > 0 && (
        <div className="fixed bottom-4 left-4 right-4 max-w-md mx-auto z-30">
          <button
            onClick={onCheckout}
            className="w-full bg-primary text-primary-foreground py-4 rounded-2xl flex items-center justify-center gap-2 shadow-2xl brand-glow font-semibold font-display tracking-wide"
          >
            <Check className="w-5 h-5" /> Confirmar pedido
          </button>
        </div>
      )}
    </div>
  )
}

// ============================================
// PANTALLA 4: CHECKOUT
// ============================================
function CheckoutScreen({ carrito, carritoTotal, empresa, onBack, onSuccess }: {
  carrito: {[id: string]: { plato: Plato; cantidad: number }}
  carritoTotal: number
  empresa: Empresa | null
  onBack: () => void
  onSuccess: () => void
}) {
  const [submitting, setSubmitting] = useState(false)
  const [metodo, setMetodo] = useState<'recoger' | 'domicilio'>('recoger')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    const form = e.currentTarget as HTMLFormElement
    const data = new FormData(form)
    const items = Object.values(carrito)
    const detalle = items.map(({ plato, cantidad }) => `${cantidad}x ${plato.nombre}`).join(', ')

    const res = await fetch('/api/pedidos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        cliente: data.get('nombre'),
        telefono: data.get('telefono'),
        direccion: data.get('direccion') || 'Recoger en el local',
        notas: data.get('notas'),
        detalle,
        total: carritoTotal,
        origen: 'web',
      }),
    })
    const result = await res.json()
    setSubmitting(false)
    if (result.ok) {
      // Abrir WhatsApp con el resumen
      const whatsappUrl = empresa?.whatsapp
        ? `https://wa.me/${empresa.whatsapp.replace(/[^0-9]/g, '')}`
        : 'https://wa.me/573508029292'
      const mensaje = `¡Hola! Quiero hacer un pedido:\n\n${detalle}\n\nTotal: $${carritoTotal.toLocaleString('es-CO')}\nNombre: ${data.get('nombre')}\nTel: ${data.get('telefono')}\n${metodo === 'domicilio' ? 'Domicilio: ' + data.get('direccion') : 'Recogeré en el local'}`
      window.open(whatsappUrl + `?text=${encodeURIComponent(mensaje)}`, '_blank')
      onSuccess()
    } else {
      alert('Error: ' + result.error)
    }
  }

  const items = Object.values(carrito)

  return (
    <div className="screen-enter min-h-screen pb-28">
      <div className="sticky top-0 z-20 bg-background/90 backdrop-blur-md border-b border-border">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center gap-3">
          <button onClick={onBack} className="p-2 rounded-lg hover:bg-muted">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-semibold font-display tracking-wide flex-1">Tus datos</h1>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 py-4">
        {/* Resumen */}
        <div className="surface rounded-xl p-4 mb-4">
          <p className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Resumen</p>
          {items.map(({ plato, cantidad }) => (
            <div key={plato.id} className="flex items-center justify-between text-sm py-1">
              <span>{cantidad}x {plato.nombre}</span>
              <span className="font-medium">${(plato.precio * cantidad).toLocaleString('es-CO')}</span>
            </div>
          ))}
          <div className="border-t border-border pt-2 mt-2 flex items-center justify-between">
            <span className="font-semibold">Total</span>
            <span className="text-lg font-bold text-primary">${carritoTotal.toLocaleString('es-CO')}</span>
          </div>
        </div>

        {/* Método de entrega */}
        <div className="grid grid-cols-2 gap-2 mb-4">
          <button
            onClick={() => setMetodo('recoger')}
            className={`p-3 rounded-xl border text-left transition-colors ${
              metodo === 'recoger' ? 'border-primary bg-primary/10' : 'surface-2'
            }`}
          >
            <Store className="w-4 h-4 mb-1 text-primary" />
            <p className="text-xs font-medium">Recoger en local</p>
            <p className="text-[10px] text-muted-foreground">Finca El Jazmín</p>
          </button>
          <button
            onClick={() => setMetodo('domicilio')}
            className={`p-3 rounded-xl border text-left transition-colors ${
              metodo === 'domicilio' ? 'border-primary bg-primary/10' : 'surface-2'
            }`}
          >
            <MapPin className="w-4 h-4 mb-1 text-primary" />
            <p className="text-xs font-medium">A domicilio</p>
            <p className="text-[10px] text-muted-foreground">Coordinar por WhatsApp</p>
          </button>
        </div>

        {/* Formulario */}
        <form onSubmit={handleSubmit} className="space-y-3">
          <label className="block">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Nombre</span>
            <input name="nombre" type="text" required placeholder="Tu nombre"
              className="surface-2 w-full mt-1 px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-primary/40" />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Teléfono / WhatsApp</span>
            <input name="telefono" type="tel" required placeholder="+57 300 000 0000"
              className="surface-2 w-full mt-1 px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-primary/40" />
          </label>
          {metodo === 'domicilio' && (
            <label className="block">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Dirección de entrega</span>
              <textarea name="direccion" rows={2} required placeholder="Dirección completa"
                className="surface-2 w-full mt-1 px-3 py-2.5 rounded-lg text-sm resize-none focus:outline-none focus:border-primary/40" />
            </label>
          )}
          <label className="block">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Notas (opcional)</span>
            <textarea name="notas" rows={2} placeholder="Ej: sin cebolla, extra picante..."
              className="surface-2 w-full mt-1 px-3 py-2.5 rounded-lg text-sm resize-none focus:outline-none focus:border-primary/40" />
          </label>

          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-primary text-primary-foreground py-4 rounded-2xl flex items-center justify-center gap-2 font-semibold font-display tracking-wide disabled:opacity-40"
          >
            {submitting ? (
              <><Loader2 className="w-5 h-5 animate-spin" /> Enviando...</>
            ) : (
              <><Send className="w-5 h-5" /> Enviar pedido por WhatsApp</>
            )}
          </button>
          <p className="text-[10px] text-center text-muted-foreground">
            Se enviará tu pedido por WhatsApp para confirmación. Pago: efectivo o transferencia al recibir.
          </p>
        </form>
      </div>
    </div>
  )
}

function Store({ className }: { className?: string }) {
  return <MapPin className={className} />
}

// ============================================
// PANTALLA 5: RESERVAS
// ============================================
function ReservasScreen({ empresa, onBack }: { empresa: Empresa | null; onBack: () => void }) {
  const [submitting, setSubmitting] = useState(false)
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    const form = e.currentTarget as HTMLFormElement
    const data = new FormData(form)
    const res = await fetch('/api/reservas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        data: {
          nombre: data.get('nombre'),
          celular: data.get('celular'),
          fecha: data.get('fecha'),
          hora: data.get('hora'),
          personas: data.get('personas'),
        }
      }),
    })
    const result = await res.json()
    setSubmitting(false)
    if (result.ok) setSuccess(true)
    else alert('Error: ' + result.error)
  }

  if (success) {
    return (
      <div className="screen-enter min-h-screen flex items-center justify-center px-6 max-w-md mx-auto">
        <div className="text-center">
          <div className="w-20 h-20 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-4">
            <Check className="w-10 h-10 text-emerald-400" />
          </div>
          <h2 className="text-xl font-semibold mb-2 font-display tracking-wide">¡Reserva enviada!</h2>
          <p className="text-sm text-muted-foreground mb-6">Te confirmamos por WhatsApp en minutos.</p>
          <button onClick={onBack} className="bg-primary text-primary-foreground px-6 py-3 rounded-xl font-medium">
            Volver al inicio
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="screen-enter min-h-screen pb-12">
      <div className="sticky top-0 z-20 bg-background/90 backdrop-blur-md border-b border-border">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center gap-3">
          <button onClick={onBack} className="p-2 rounded-lg hover:bg-muted">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-semibold font-display tracking-wide flex-1">Reservar mesa</h1>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 py-6">
        <div className="text-center mb-6">
          <CalendarCheck className="w-12 h-12 text-primary mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Te confirmamos por WhatsApp en minutos</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <label className="block">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Nombre</span>
            <input name="nombre" type="text" required placeholder="Tu nombre"
              className="surface-2 w-full mt-1 px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-primary/40" />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Celular / WhatsApp</span>
            <input name="celular" type="tel" required placeholder="+57 300 000 0000"
              className="surface-2 w-full mt-1 px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-primary/40" />
          </label>
          <div className="grid grid-cols-3 gap-3">
            <label className="block">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Fecha</span>
              <input name="fecha" type="date" required
                className="surface-2 w-full mt-1 px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-primary/40" />
            </label>
            <label className="block">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Hora</span>
              <input name="hora" type="time" required
                className="surface-2 w-full mt-1 px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-primary/40" />
            </label>
            <label className="block">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Personas</span>
              <input name="personas" type="number" min="1" max="20" required defaultValue="2"
                className="surface-2 w-full mt-1 px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-primary/40" />
            </label>
          </div>
          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-primary text-primary-foreground py-4 rounded-2xl flex items-center justify-center gap-2 font-semibold font-display tracking-wide disabled:opacity-40"
          >
            {submitting ? (
              <><Loader2 className="w-5 h-5 animate-spin" /> Enviando...</>
            ) : (
              <><CalendarCheck className="w-5 h-5" /> Solicitar reserva</>
            )}
          </button>
        </form>
      </div>
    </div>
  )
}

// ============================================
// PANTALLA 5b: AGENDA (Solicitar disponibilidad)
// ============================================
function AgendaScreen({ empresa, onBack }: { empresa: Empresa | null; onBack: () => void }) {
  const [submitting, setSubmitting] = useState(false)
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    const form = e.currentTarget as HTMLFormElement
    const data = new FormData(form)
    // Crear como reserva con nota de "disponibilidad"
    const res = await fetch('/api/reservas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        data: {
          nombre: data.get('nombre'),
          celular: data.get('celular'),
          fecha: data.get('fecha'),
          hora: data.get('hora'),
          personas: data.get('personas'),
        },
      }),
    })
    const result = await res.json()
    setSubmitting(false)
    if (result.ok) setSuccess(true)
    else alert('Error: ' + result.error)
  }

  if (success) {
    return (
      <div className="screen-enter min-h-screen flex items-center justify-center px-6 max-w-md mx-auto">
        <div className="text-center">
          <div className="w-20 h-20 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-4">
            <Check className="w-10 h-10 text-emerald-400" />
          </div>
          <h2 className="text-xl font-semibold mb-2 font-display tracking-wide">¡Solicitud enviada!</h2>
          <p className="text-sm text-muted-foreground mb-6">Te confirmamos disponibilidad por WhatsApp.</p>
          <button onClick={onBack} className="bg-primary text-primary-foreground px-6 py-3 rounded-xl font-medium">
            Volver al inicio
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="screen-enter min-h-screen pb-12">
      <div className="sticky top-0 z-20 bg-background/90 backdrop-blur-md border-b border-border">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center gap-3">
          <button onClick={onBack} className="p-2 rounded-lg hover:bg-muted">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-semibold font-display tracking-wide flex-1">Solicitar disponibilidad</h1>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 py-6">
        <div className="text-center mb-6">
          <CalendarCheck className="w-12 h-12 text-primary mx-auto mb-3" />
          <p className="text-sm text-muted-foreground mb-2">🔥 Atendemos exclusivamente con cita previa</p>
          <p className="text-xs text-muted-foreground">Solicita tu disponibilidad y te confirmamos por WhatsApp</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <label className="block">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Nombre</span>
            <input name="nombre" type="text" required placeholder="Tu nombre"
              className="surface-2 w-full mt-1 px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-primary/40" />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Celular / WhatsApp</span>
            <input name="celular" type="tel" required placeholder="+57 300 000 0000"
              className="surface-2 w-full mt-1 px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-primary/40" />
          </label>
          <div className="grid grid-cols-3 gap-3">
            <label className="block">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Fecha</span>
              <input name="fecha" type="date" required
                className="surface-2 w-full mt-1 px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-primary/40" />
            </label>
            <label className="block">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Hora</span>
              <input name="hora" type="time" required
                className="surface-2 w-full mt-1 px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-primary/40" />
            </label>
            <label className="block">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Personas</span>
              <input name="personas" type="number" min="1" max="20" required defaultValue="2"
                className="surface-2 w-full mt-1 px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-primary/40" />
            </label>
          </div>
          <label className="block">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Tipo de evento (opcional)</span>
            <select name="notas" className="surface-2 w-full mt-1 px-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-primary/40">
              <option value="">Selecciona...</option>
              <option value="Visita con degustación">Visita con degustación</option>
              <option value="Evento privado">Evento privado</option>
              <option value="Catering">Catering</option>
              <option value="Otro">Otro</option>
            </select>
          </label>
          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-primary text-primary-foreground py-4 rounded-2xl flex items-center justify-center gap-2 font-semibold font-display tracking-wide disabled:opacity-40"
          >
            {submitting ? (
              <><Loader2 className="w-5 h-5 animate-spin" /> Enviando...</>
            ) : (
              <><CalendarCheck className="w-5 h-5" /> Solicitar disponibilidad</>
            )}
          </button>
        </form>
      </div>
    </div>
  )
}

// ============================================
// PANTALLA 6: ESENCIA
// ============================================
function EsenciaScreen({ empresa, onBack }: { empresa: Empresa | null; onBack: () => void }) {
  return (
    <div className="screen-enter min-h-screen pb-12">
      <div className="sticky top-0 z-20 bg-background/90 backdrop-blur-md border-b border-border">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center gap-3">
          <button onClick={onBack} className="p-2 rounded-lg hover:bg-muted">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-semibold font-display tracking-wide flex-1">Nuestra Esencia</h1>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* Historia */}
        <div className="surface rounded-xl p-6">
          <div className="text-3xl mb-3">🔥</div>
          <h2 className="text-base font-semibold mb-2 font-display tracking-wide">Un Siglo de Tradición en Puyana</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            En Fusión y Fogón unimos sabores que cuentan historias. Ahumamos con leña de guayabo,
            cocinamos con paciencia de fogón lento y servimos con el cariño de la cocina de la abuela.
            Cada plato es una experiencia que conecta la tradición campesina con la creatividad culinaria.
          </p>
        </div>

        {/* Misión */}
        <div className="surface rounded-xl p-6">
          <div className="text-3xl mb-3">🍃</div>
          <h2 className="text-base font-semibold mb-2 font-display tracking-wide">MISIÓN</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Llevar a la mesa de nuestras familias sabores auténticos, ahumados con técnicas tradicionales
            y ingredientes de la región, creando experiencias memorables alrededor del fogón.
          </p>
        </div>

        {/* Visión */}
        <div className="surface rounded-xl p-6">
          <div className="text-3xl mb-3">🌟</div>
          <h2 className="text-base font-semibold mb-2 font-display tracking-wide">VISIÓN 2030</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Ser el ahumadero artesanal más reconocido de Santander, referente en turismo vivencial
            gastronómico y embajador de la cultura santandereana en Colombia.
          </p>
        </div>

        {/* Valores */}
        <div className="surface rounded-xl p-6">
          <h2 className="text-base font-semibold mb-3 font-display tracking-wide">Nuestros valores</h2>
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center">
              <div className="text-2xl mb-1">🌿</div>
              <p className="text-[10px] text-muted-foreground">Ingredientes locales</p>
            </div>
            <div className="text-center">
              <div className="text-2xl mb-1">🔥</div>
              <p className="text-[10px] text-muted-foreground">Leña de guayabo</p>
            </div>
            <div className="text-center">
              <div className="text-2xl mb-1">❤️</div>
              <p className="text-[10px] text-muted-foreground">Tradición familiar</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// ============================================
// PANTALLA 7: CATERING
// ============================================
function CateringScreen({ empresa, whatsappUrl, onBack }: {
  empresa: Empresa | null
  whatsappUrl: string
  onBack: () => void
}) {
  return (
    <div className="screen-enter min-h-screen pb-12">
      <div className="sticky top-0 z-20 bg-background/90 backdrop-blur-md border-b border-border">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center gap-3">
          <button onClick={onBack} className="p-2 rounded-lg hover:bg-muted">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-semibold font-display tracking-wide flex-1">Experiencias y Catering</h1>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 py-6 space-y-4">
        <div className="text-center mb-6">
          <ChefHat className="w-12 h-12 text-primary mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Llevamos el fogón a tu evento</p>
        </div>

        <div className="surface rounded-xl p-5">
          <div className="text-3xl mb-3">🔥</div>
          <h3 className="text-base font-semibold mb-2 font-display tracking-wide">Ahumados al Barril en Vivo</h3>
          <p className="text-sm text-muted-foreground mb-3">
            Espectáculo de ahumado en vivo para tu evento. Costillares, lomos y panceta cocinados
            al barril con leña de guayabo.
          </p>
          <ul className="text-xs text-muted-foreground space-y-1">
            <li>• Para eventos desde 20 personas</li>
            <li>• Duración: 4-6 horas</li>
            <li>• Incluye montaje y presentación</li>
          </ul>
        </div>

        <div className="surface rounded-xl p-5">
          <div className="text-3xl mb-3">🥩</div>
          <h3 className="text-base font-semibold mb-2 font-display tracking-wide">Estación de Charcutería</h3>
          <p className="text-sm text-muted-foreground mb-3">
            Tablas campesinas con chorizos artesanales, ahumados y acompañamientos de la región.
          </p>
          <ul className="text-xs text-muted-foreground space-y-1">
            <li>• Tablas para 10-50 personas</li>
            <li>• Chorizos, lomos, panceta, quesos</li>
            <li>• Acompañamientos regionales</li>
          </ul>
        </div>

        <a
          href={whatsappUrl + '?text=Hola,%20quiero%20cotizar%20catering%20para%20un%20evento'}
          target="_blank"
          rel="noreferrer"
          className="block w-full bg-primary text-primary-foreground py-4 rounded-2xl text-center font-semibold font-display tracking-wide"
        >
          💬 Cotizar catering
        </a>
      </div>
    </div>
  )
}

// ============================================
// PANTALLA 8: CONTACTO
// ============================================
function ContactoScreen({ empresa, whatsappUrl, onBack }: {
  empresa: Empresa | null
  whatsappUrl: string
  onBack: () => void
}) {
  return (
    <div className="screen-enter min-h-screen pb-12">
      <div className="sticky top-0 z-20 bg-background/90 backdrop-blur-md border-b border-border">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center gap-3">
          <button onClick={onBack} className="p-2 rounded-lg hover:bg-muted">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-semibold font-display tracking-wide flex-1">Contacto y Ubicación</h1>
        </div>
      </div>

      <div className="max-w-md mx-auto px-4 py-6 space-y-3">
        <div className="surface rounded-xl p-5 flex items-start gap-3">
          <MapPin className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Dirección</p>
            <p className="text-sm">{empresa?.direccion || 'Finca El Jazmín, Vereda Puyana, Lebrija - Santander'}</p>
          </div>
        </div>

        <div className="surface rounded-xl p-5 flex items-start gap-3">
          <Clock className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Horarios</p>
            <p className="text-sm">{empresa?.horarios || 'Jueves a Domingo y Festivos: 11:30 AM - 8:30 PM'}</p>
          </div>
        </div>

        {empresa?.telefono && (
          <div className="surface rounded-xl p-5 flex items-start gap-3">
            <Phone className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Teléfono</p>
              <p className="text-sm">{empresa.telefono}</p>
            </div>
          </div>
        )}

        {empresa?.email && (
          <div className="surface rounded-xl p-5 flex items-start gap-3">
            <Mail className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Email</p>
              <p className="text-sm">{empresa.email}</p>
            </div>
          </div>
        )}

        <a href={whatsappUrl} target="_blank" rel="noreferrer"
          className="surface rounded-xl p-5 flex items-center gap-3 hover:border-primary/30">
          <MessageCircle className="w-5 h-5 text-[#25D366]" />
          <div className="flex-1">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">WhatsApp</p>
            <p className="text-sm">{empresa?.whatsapp || '+57 350 802 9292'}</p>
          </div>
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
        </a>

        {empresa?.mapsUrl && (
          <a href={empresa.mapsUrl} target="_blank" rel="noreferrer"
            className="surface rounded-xl p-5 flex items-center gap-3 hover:border-primary/30">
            <MapPin className="w-5 h-5 text-primary" />
            <div className="flex-1">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Google Maps</p>
              <p className="text-sm">Cómo llegar</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </a>
        )}

        {empresa?.facebook && (
          <a href={empresa.facebook} target="_blank" rel="noreferrer"
            className="surface rounded-xl p-5 flex items-center gap-3 hover:border-primary/30">
            <Facebook className="w-5 h-5 text-[#1877F2]" />
            <div className="flex-1">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Facebook</p>
              <p className="text-sm">@fusionyfogon</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </a>
        )}

        {empresa?.instagram && (
          <a href={empresa.instagram} target="_blank" rel="noreferrer"
            className="surface rounded-xl p-5 flex items-center gap-3 hover:border-primary/30">
            <Instagram className="w-5 h-5 text-[#E4405F]" />
            <div className="flex-1">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Instagram</p>
              <p className="text-sm">@fusionyfogon</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </a>
        )}
      </div>
    </div>
  )
}
