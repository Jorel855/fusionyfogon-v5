import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant, nextCodigo } from '@/lib/tenant'
import { emitPedidoCreated } from '@/lib/events'

// GET /api/pedidos — list pedidos
// Query params: ?estado=Pendiente (filter)  ?limit=50
export async function GET(req: NextRequest) {
  const tenant = await ensureTenant()
  const { searchParams } = new URL(req.url)
  const estado = searchParams.get('estado')
  const limit = parseInt(searchParams.get('limit') || '50')

  const pedidos = await db.pedido.findMany({
    where: {
      tenantId: tenant.id,
      ...(estado ? { estado } : {}),
    },
    orderBy: { createdAt: 'desc' },
    take: limit,
  })

  return NextResponse.json({
    ok: true,
    pedidos: pedidos.map((p) => ({
      id: p.id,
      codigo: p.codigo,
      cliente: p.cliente,
      telefono: p.telefono,
      direccion: p.direccion,
      notas: p.notas,
      detalle: p.detalle,
      total: p.total / 100,
      estado: p.estado,
      whatsappEnviado: p.whatsappEnviado,
      whatsappLeido: p.whatsappLeido,
      origen: p.origen,
      fecha: p.createdAt.toISOString(),
    })),
  })
}

// POST /api/pedidos — create pedido (from web or admin)
export async function POST(req: NextRequest) {
  const tenant = await ensureTenant()
  const body = await req.json()

  // Validate required fields
  if (!body.cliente || !body.detalle || !body.total) {
    return NextResponse.json(
      { ok: false, error: 'Faltan campos requeridos: cliente, detalle, total' },
      { status: 400 }
    )
  }

  const codigo = await nextCodigo(tenant.id, 'Pedido')

  const pedido = await db.pedido.create({
    data: {
      tenantId: tenant.id,
      codigo,
      cliente: body.cliente,
      telefono: body.telefono || null,
      direccion: body.direccion || null,
      notas: body.notas || null,
      detalle: typeof body.detalle === 'string' ? body.detalle : JSON.stringify(body.detalle),
      total: Math.round(body.total * 100), // convertir a centavos
      estado: 'Pendiente',
      origen: body.origen || 'web',
    },
  })

  // TODO: disparar WhatsApp automático aquí (cuando esté conectado WhatsApp Cloud API)

  // 🔔 Emitir evento para que el admin se actualice en tiempo real
  emitPedidoCreated(tenant.id, pedido.id)

  return NextResponse.json({
    ok: true,
    pedido: {
      id: pedido.id,
      codigo: pedido.codigo,
      estado: pedido.estado,
    },
  })
}
