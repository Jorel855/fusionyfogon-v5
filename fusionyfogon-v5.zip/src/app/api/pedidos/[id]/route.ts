import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant, formatCOP } from '@/lib/tenant'
import { requireRole } from '@/lib/auth'

// PATCH /api/pedidos/[id] — update estado (triggers WhatsApp notification)
// Requiere permiso pedidos:write (Admin, Editor, Cajero)
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const authResult = await requireRole(req, 'pedidos:write')
  if (authResult instanceof NextResponse) return authResult

  const tenant = await ensureTenant()
  const { id } = await params
  const body = await req.json()

  const existing = await db.pedido.findFirst({
    where: { id, tenantId: tenant.id },
  })
  if (!existing) {
    return NextResponse.json({ ok: false, error: 'Pedido no encontrado' }, { status: 404 })
  }

  const updated = await db.pedido.update({
    where: { id },
    data: {
      ...(body.estado ? { estado: body.estado } : {}),
      ...(body.whatsappEnviado !== undefined ? { whatsappEnviado: body.whatsappEnviado } : {}),
      ...(body.whatsappLeido !== undefined ? { whatsappLeido: body.whatsappLeido } : {}),
      ...(body.whatsappMensajeId ? { whatsappMensajeId: body.whatsappMensajeId } : {}),
    },
  })

  // Si cambió el estado → dispara WhatsApp automático
  if (body.estado && body.estado !== existing.estado) {
    const plantilla = await db.plantillaWhatsApp.findUnique({
      where: { tenantId_estado: { tenantId: tenant.id, estado: body.estado } },
    })

    if (plantilla?.activa && existing.telefono) {
      // Reemplaza variables
      const mensaje = plantilla.cuerpo
        .replace(/{{nombre}}/g, existing.cliente)
        .replace(/{{id}}/g, existing.codigo)
        .replace(/{{total}}/g, formatCOP(existing.total))
        .replace(/{{detalle}}/g, existing.detalle)
        .replace(/{{tiempo}}/g, '30 minutos')
        .replace(/{{direccion}}/g, existing.direccion || '')
        .replace(/{{motivo}}/g, body.motivo || 'No especificado')
        .replace(/{{link_resena}}/g, 'g.page/r/fusion-fogon/review')

      // Llama al endpoint de WhatsApp (internal)
      const whatsappRes = await fetch(`${req.nextUrl.origin}/api/whatsapp/send`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          telefono: existing.telefono,
          mensaje,
          plantillaEstado: body.estado,
          pedidoId: id,
        }),
      })

      const whatsappData = await whatsappRes.json()
      if (whatsappData.ok) {
        await db.pedido.update({
          where: { id },
          data: { whatsappEnviado: true },
        })
      }
    }

    // Audit log
    await db.auditLog.create({
      data: {
        tenantId: tenant.id,
        usuarioNombre: body.usuario || 'Sistema',
        accion: 'update',
        entidad: 'pedido',
        entidadId: id,
        detalle: `Estado: ${existing.estado} → ${body.estado}${existing.telefono ? ' · WhatsApp enviado' : ''}`,
      },
    })
  }

  return NextResponse.json({
    ok: true,
    pedido: {
      id: updated.id,
      codigo: updated.codigo,
      estado: updated.estado,
      whatsappEnviado: updated.whatsappEnviado,
    },
  })
}
