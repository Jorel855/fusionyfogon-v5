import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'

// GET /api/platos
export async function GET(req: NextRequest) {
  const tenant = await ensureTenant()
  const { searchParams } = new URL(req.url)
  const soloVisibles = searchParams.get('visibles') === 'true'

  const platos = await db.plato.findMany({
    where: {
      tenantId: tenant.id,
      ...(soloVisibles ? { visible: true } : {}),
    },
    orderBy: [{ orden: 'asc' }, { createdAt: 'asc' }],
    include: { categoria: true },
  })

  return NextResponse.json({
    ok: true,
    platos: platos.map((p) => ({
      id: p.id,
      slug: p.slug,
      nombre: p.nombre,
      descripcion: p.descripcion,
      precio: p.precio / 100,
      badge: p.badge,
      imagenUrl: p.imagenUrl,
      visible: p.visible,
      orden: p.orden,
      ventas: p.ventas,
      categoria: p.categoria
        ? { id: p.categoria.id, slug: p.categoria.slug, nombre: p.categoria.nombre, icono: p.categoria.icono }
        : null,
      programa: p.programaActivo
        ? { activo: true, desde: p.programaDesde, hasta: p.programaHasta }
        : null,
    })),
  })
}

// POST /api/platos
export async function POST(req: NextRequest) {
  const tenant = await ensureTenant()
  const body = await req.json()
  if (!body.nombre || body.precio === undefined) {
    return NextResponse.json({ ok: false, error: 'Faltan nombre y precio' }, { status: 400 })
  }

  const slug =
    body.slug ||
    body.nombre
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')

  const created = await db.plato.create({
    data: {
      tenantId: tenant.id,
      categoriaId: body.categoriaId || null,
      nombre: body.nombre,
      descripcion: body.descripcion || null,
      precio: Math.round(body.precio * 100),
      badge: body.badge || null,
      imagenUrl: body.imagenUrl || null,
      visible: body.visible !== false,
      slug,
      programaActivo: body.programa?.activo || false,
      programaDesde: body.programa?.desde ? new Date(body.programa.desde) : null,
      programaHasta: body.programa?.hasta ? new Date(body.programa.hasta) : null,
    },
  })

  return NextResponse.json({ ok: true, plato: { id: created.id, slug: created.slug } })
}
