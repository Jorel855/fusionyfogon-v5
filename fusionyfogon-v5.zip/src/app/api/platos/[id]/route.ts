import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'
import { requireRole } from '@/lib/auth'
import { emitMenuUpdated } from '@/lib/events'

// PATCH /api/platos/[id] — requiere platos:write
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const authResult = await requireRole(req, 'platos:write')
  if (authResult instanceof NextResponse) return authResult

  const tenant = await ensureTenant()
  const { id } = await params
  const body = await req.json()
  const existing = await db.plato.findFirst({ where: { id, tenantId: tenant.id } })
  if (!existing) return NextResponse.json({ ok: false, error: 'No encontrado' }, { status: 404 })

  const updated = await db.plato.update({
    where: { id },
    data: {
      ...(body.nombre ? { nombre: body.nombre } : {}),
      ...(body.descripcion !== undefined ? { descripcion: body.descripcion } : {}),
      ...(body.precio !== undefined ? { precio: Math.round(body.precio * 100) } : {}),
      ...(body.badge !== undefined ? { badge: body.badge } : {}),
      ...(body.imagenUrl !== undefined ? { imagenUrl: body.imagenUrl } : {}),
      ...(body.visible !== undefined ? { visible: body.visible } : {}),
      ...(body.orden !== undefined ? { orden: body.orden } : {}),
      ...(body.categoriaId !== undefined ? { categoriaId: body.categoriaId } : {}),
      ...(body.programa !== undefined
        ? {
            programaActivo: body.programa.activo || false,
            programaDesde: body.programa.desde ? new Date(body.programa.desde) : null,
            programaHasta: body.programa.hasta ? new Date(body.programa.hasta) : null,
          }
        : {}),
    },
  })

  // Audit
  if (body.visible !== undefined && body.visible !== existing.visible) {
    await db.auditLog.create({
      data: {
        tenantId: tenant.id,
        usuarioNombre: body.usuario || 'Admin',
        accion: 'update',
        entidad: 'plato',
        entidadId: id,
        detalle: `${body.visible ? 'Mostró' : 'Ocultó'} plato "${existing.nombre}"`,
      },
    })
  }

  // 🔔 Emitir evento para sincronización en tiempo real con la web pública
  emitMenuUpdated(tenant.id, id)

  return NextResponse.json({ ok: true, plato: { id: updated.id } })
}

// DELETE /api/platos/[id] — requiere platos:write (solo Admin en producción)
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const authResult = await requireRole(req, 'platos:write')
  if (authResult instanceof NextResponse) return authResult

  const tenant = await ensureTenant()
  const { id } = await params
  const existing = await db.plato.findFirst({ where: { id, tenantId: tenant.id } })
  if (!existing) return NextResponse.json({ ok: false, error: 'No encontrado' }, { status: 404 })

  await db.plato.delete({ where: { id } })
  await db.auditLog.create({
    data: {
      tenantId: tenant.id,
      usuarioNombre: 'Admin',
      accion: 'delete',
      entidad: 'plato',
      entidadId: id,
      detalle: `Eliminó plato "${existing.nombre}"`,
    },
  })

  // 🔔 Emitir evento para sincronización en tiempo real
  emitMenuUpdated(tenant.id, id)

  return NextResponse.json({ ok: true })
}
