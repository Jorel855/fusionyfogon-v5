import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'
import { requireRole } from '@/lib/auth'

// GET /api/backup — lista todos los backups (cualquier autenticado)
export async function GET(req: NextRequest) {
  // Permitir GET sin auth para descarga pública de backups vía URL firmada (futuro)
  // Por ahora, cualquier autenticado puede ver la lista
  const authResult = await requireRole(req, 'pedidos:read')
  if (authResult instanceof NextResponse) return authResult

  const tenant = await ensureTenant()
  const { searchParams } = new URL(req.url)
  const backupId = searchParams.get('id')
  const downloadLatest = searchParams.get('download') === 'latest'

  if (backupId || downloadLatest) {
    const backup = backupId
      ? await db.backup.findFirst({ where: { id: backupId, tenantId: tenant.id } })
      : await db.backup.findFirst({
          where: { tenantId: tenant.id },
          orderBy: { createdAt: 'desc' },
        })

    if (!backup) {
      return NextResponse.json({ ok: false, error: 'Backup no encontrado' }, { status: 404 })
    }

    return new NextResponse(backup.contenido, {
      headers: {
        'Content-Type': 'application/json',
        'Content-Disposition': `attachment; filename="backup-${tenant.slug}-${backup.id}.json"`,
      },
    })
  }

  // Lista de backups
  const backups = await db.backup.findMany({
    where: { tenantId: tenant.id },
    orderBy: { createdAt: 'desc' },
    take: 30,
  })

  return NextResponse.json({
    ok: true,
    backups: backups.map((b) => ({
      id: b.id,
      tipo: b.tipo,
      autor: b.autor,
      size: b.size,
      fecha: b.createdAt.toISOString(),
    })),
  })
}

// POST /api/backup — crea un backup manual (solo Admin o Editor)
export async function POST(req: NextRequest) {
  const authResult = await requireRole(req, 'content:write')
  if (authResult instanceof NextResponse) return authResult

  const tenant = await ensureTenant()
  const body = await req.json()

  // Exporta TODA la data del tenant
  const [empresa, categorias, platos, pedidos, reservas, sellos, pestanas, plantillas] = await Promise.all([
    db.empresa.findUnique({ where: { tenantId: tenant.id } }),
    db.categoria.findMany({ where: { tenantId: tenant.id } }),
    db.plato.findMany({ where: { tenantId: tenant.id } }),
    db.pedido.findMany({ where: { tenantId: tenant.id } }),
    db.reserva.findMany({ where: { tenantId: tenant.id } }),
    db.sello.findMany({ where: { tenantId: tenant.id } }),
    db.pestanaExtra.findMany({ where: { tenantId: tenant.id } }),
    db.plantillaWhatsApp.findMany({ where: { tenantId: tenant.id } }),
  ])

  const contenido = JSON.stringify(
    {
      version: '5.0',
      tenant: { slug: tenant.slug, nombre: tenant.nombre, rubro: tenant.rubro },
      exportedAt: new Date().toISOString(),
      data: { empresa, categorias, platos, pedidos, reservas, sellos, pestanas, plantillas },
    },
    null,
    2
  )

  const backup = await db.backup.create({
    data: {
      tenantId: tenant.id,
      tipo: body.tipo || 'manual',
      autor: body.autor || 'Admin',
      size: contenido.length,
      contenido,
    },
  })

  // Mantiene solo los últimos 30 (rotación)
  const total = await db.backup.count({ where: { tenantId: tenant.id } })
  if (total > 30) {
    const viejos = await db.backup.findMany({
      where: { tenantId: tenant.id },
      orderBy: { createdAt: 'desc' },
      skip: 30,
      select: { id: true },
    })
    await db.backup.deleteMany({ where: { id: { in: viejos.map((v) => v.id) } } })
  }

  return NextResponse.json({
    ok: true,
    backup: { id: backup.id, size: backup.size, fecha: backup.createdAt.toISOString() },
  })
}
