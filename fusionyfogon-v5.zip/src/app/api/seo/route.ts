import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'

// GET /api/seo — devuelve meta tags + JSON-LD para la home
// GET /api/seo?slug=xxx — devuelve meta tags + JSON-LD para un plato específico
export async function GET(req: NextRequest) {
  const tenant = await ensureTenant()
  const { searchParams } = new URL(req.url)
  const slug = searchParams.get('slug')
  const seccion = searchParams.get('seccion') // 'carta' | 'catering' | 'esencia' | 'contacto'

  const empresa = await db.empresa.findUnique({ where: { tenantId: tenant.id } })
  if (!empresa) {
    return NextResponse.json({ ok: false, error: 'Empresa no encontrada' }, { status: 404 })
  }

  // Usar dominio real (env var) o el configurado en empresa
  const baseUrl = process.env.NEXTAUTH_URL || process.env.URL || `https://${empresa.dominioPrincipal || 'fusionyfogon.com'}`
  const cleanBaseUrl = baseUrl.replace(/\/$/, '')

  // Meta tags base
  const meta: any = {
    title: empresa.seoTitle || `${empresa.nombre} | ${empresa.tagline || ''}`,
    description: empresa.seoDescription || '',
    keywords: empresa.seoKeyword || '',
    canonical: cleanBaseUrl,
    ogType: 'website',
    ogImage: empresa.logoUrl || `${cleanBaseUrl}/icons/icon-512.png`,
    ogUrl: cleanBaseUrl,
    ogSiteName: empresa.nombre,
    twitterCard: 'summary_large_image',
    twitterTitle: empresa.seoTitle,
    twitterDescription: empresa.seoDescription,
    twitterImage: empresa.logoUrl || `${cleanBaseUrl}/icons/icon-512.png`,
  }

  // JSON-LD schemas
  const schemas: any[] = []

  // Schema 1: Restaurant / LocalBusiness
  const rubro = tenant.rubro
  const businessType =
    rubro === 'spa' ? 'HealthAndBeautyBusiness' :
    rubro === 'tienda' ? 'Store' :
    'Restaurant'

  schemas.push({
    '@context': 'https://schema.org',
    '@type': businessType,
    '@id': `${cleanBaseUrl}#business`,
    name: empresa.nombre,
    alternateName: empresa.tagline,
    description: empresa.seoDescription,
    image: empresa.logoUrl || `${cleanBaseUrl}/icons/icon-512.png`,
    logo: empresa.logoUrl || `${cleanBaseUrl}/icons/icon-192.png`,
    url: cleanBaseUrl,
    telephone: empresa.telefono,
    email: empresa.email,
    address: {
      '@type': 'PostalAddress',
      streetAddress: empresa.direccion,
      addressLocality: 'Lebrija',
      addressRegion: 'Santander',
      addressCountry: 'CO',
    },
    geo: {
      '@type': 'GeoCoordinates',
      latitude: 7.2076,
      longitude: -73.2097,
    },
    hasMap: empresa.mapsUrl,
    priceRange: '$$',
    servesCuisine: rubro === 'restaurante' ? 'Ahumados, Charcutería, Colombiana' : undefined,
    openingHoursSpecification: [
      {
        '@type': 'OpeningHoursSpecification',
        dayOfWeek: ['Thursday', 'Friday', 'Saturday', 'Sunday'],
        opens: '11:30',
        closes: '20:30',
      },
    ],
    sameAs: [empresa.facebook, empresa.instagram, empresa.tiktok].filter(Boolean),
    acceptsReservations: 'True',
    menu: `${cleanBaseUrl}/carta`,
  })

  if (slug) {
    // Detalle de un plato
    const plato = await db.plato.findFirst({
      where: { tenantId: tenant.id, slug, visible: true },
      include: { categoria: true },
    })
    if (plato) {
      meta.title = `${plato.seoTitle || plato.nombre} | ${empresa.nombre}`
      meta.description = plato.seoDescription || plato.descripcion || ''
      meta.canonical = `${cleanBaseUrl}/p/${plato.slug}`

      // Schema MenuItem
      schemas.push({
        '@context': 'https://schema.org',
        '@type': 'MenuItem',
        name: plato.nombre,
        description: plato.descripcion,
        offers: {
          '@type': 'Offer',
          price: plato.precio / 100,
          priceCurrency: empresa.moneda || 'COP',
        },
        suitableForDiet: plato.badge?.includes('Vegan') ? 'https://schema.org/VeganDiet' : undefined,
      })
    }
  } else if (seccion === 'carta') {
    // Schema Menu para la carta
    const platos = await db.plato.findMany({
      where: { tenantId: tenant.id, visible: true },
      include: { categoria: true },
    })
    const categorias = await db.categoria.findMany({
      where: { tenantId: tenant.id, visible: true },
      orderBy: { orden: 'asc' },
    })

    schemas.push({
      '@context': 'https://schema.org',
      '@type': 'Menu',
      name: `Carta de ${empresa.nombre}`,
      hasMenuSection: categorias.map((c) => ({
        '@type': 'MenuSection',
        name: c.nombre,
        hasMenuItem: platos
          .filter((p) => p.categoria?.slug === c.slug)
          .map((p) => ({
            '@type': 'MenuItem',
            name: p.nombre,
            description: p.descripcion,
            offers: {
              '@type': 'Offer',
              price: p.precio / 100,
              priceCurrency: empresa.moneda || 'COP',
            },
          })),
      })),
    })

    meta.canonical = `${cleanBaseUrl}/carta`
    meta.title = `Carta & Menú | ${empresa.nombre}`
    meta.description = `Conoce nuestra carta completa de ahumados, chorizos y más. ${empresa.nombre} en ${empresa.direccion}.`
  } else if (seccion) {
    meta.canonical = `${cleanBaseUrl}/${seccion}`
  }

  // Schema FAQPage (preguntas frecuentes)
  schemas.push({
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: [
      {
        '@type': 'Question',
        name: '¿Cómo hago un pedido?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: `Puedes pedir directamente desde nuestra web ${cleanBaseUrl}/carta o escribirnos por WhatsApp al ${empresa.telefono}.`,
        },
      },
      {
        '@type': 'Question',
        name: '¿Cómo reservo una mesa?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: `Reserva desde ${cleanBaseUrl}/reservas eligiendo fecha, hora y número de personas. Te confirmamos por WhatsApp.`,
        },
      },
      {
        '@type': 'Question',
        name: '¿Cuáles son los horarios?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: `${empresa.horarios || 'Jueves a Domingo y Festivos: 11:30 AM - 8:30 PM'}.`,
        },
      },
      {
        '@type': 'Question',
        name: '¿Dónde están ubicados?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: `${empresa.direccion}. Puedes ver el mapa en ${cleanBaseUrl}/contacto.`,
        },
      },
      {
        '@type': 'Question',
        name: '¿Hacen catering para eventos?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: `Sí, ofrecemos catering con ahumados al barril en vivo y estación de charcutería. Cotiza en ${cleanBaseUrl}/catering.`,
        },
      },
    ],
  })

  // Schema BreadcrumbList (para subpáginas)
  if (slug || seccion) {
    const items: any[] = [{ '@type': 'ListItem', position: 1, name: 'Inicio', item: cleanBaseUrl }]
    if (seccion) {
      items.push({ '@type': 'ListItem', position: 2, name: seccion, item: `${cleanBaseUrl}/${seccion}` })
    }
    if (slug) {
      items.push({ '@type': 'ListItem', position: 3, name: slug, item: `${cleanBaseUrl}/p/${slug}` })
    }
    schemas.push({
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: items,
    })
  }

  return NextResponse.json({
    ok: true,
    meta,
    schemas,
    baseUrl: cleanBaseUrl,
  })
}
