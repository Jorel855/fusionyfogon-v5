import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'
import { requireRole } from '@/lib/auth'

// POST /api/seo/notify-google — envía URL a Google Indexing API para indexación rápida
// Body: { url?: string } — si no se pasa, notifica la home
// Requiere Admin o Editor (no queremos que cualquiera dispare indexación)
export async function POST(req: NextRequest) {
  const authResult = await requireRole(req, 'content:write')
  if (authResult instanceof NextResponse) return authResult

  const tenant = await ensureTenant()
  const body = await req.json().catch(() => ({}))
  const empresa = await db.empresa.findUnique({ where: { tenantId: tenant.id } })

  if (!empresa?.dominioPrincipal) {
    return NextResponse.json(
      { ok: false, error: 'No hay dominio principal configurado' },
      { status: 400 }
    )
  }

  const url = body.url || `https://${empresa.dominioPrincipal}/`

  // Si no hay credenciales de Google Indexing API, simula
  const serviceAccountEmail = process.env.GSC_SERVICE_ACCOUNT_EMAIL
  const privateKey = process.env.GSC_PRIVATE_KEY

  if (!serviceAccountEmail || !privateKey) {
    console.log('[SEO] Demo mode — Google Indexing API no configurada')
    console.log('[SEO] URL notificada:', url)

    // Audit log
    await db.auditLog.create({
      data: {
        tenantId: tenant.id,
        usuarioNombre: 'Admin',
        accion: 'config',
        entidad: 'seo',
        detalle: `Notify Google (demo): ${url}`,
      },
    })

    return NextResponse.json({
      ok: true,
      demo: true,
      message: 'Google Indexing API no configurada. URL marcada como notificada (demo).',
      url,
    })
  }

  // Modo real — llama a Google Indexing API
  try {
    // Generar JWT (simplificado — en producción usar google-auth-library)
    const jwt = await generateGoogleJWT(serviceAccountEmail, privateKey, url)

    const res = await fetch('https://indexing.googleapis.com/v3/urlNotifications:publish', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${jwt}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        url,
        type: 'URL_UPDATED',
      }),
    })

    const data = await res.json()

    if (!res.ok) {
      return NextResponse.json(
        { ok: false, error: data.error?.message || 'Error en Indexing API' },
        { status: 500 }
      )
    }

    await db.auditLog.create({
      data: {
        tenantId: tenant.id,
        usuarioNombre: 'Admin',
        accion: 'config',
        entidad: 'seo',
        detalle: `Notify Google OK: ${url}`,
      },
    })

    return NextResponse.json({ ok: true, urlNotified: data.urlNotificationMetadata?.url })
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: e instanceof Error ? e.message : 'Error' },
      { status: 500 }
    )
  }
}

// Genera un JWT firmado con RS256 para Google API
// En producción, mejor usar google-auth-library — esto es una versión simplificada
async function generateGoogleJWT(email: string, privateKey: string, url: string): Promise<string> {
  const crypto = await import('crypto')
  const now = Math.floor(Date.now() / 1000)

  const header = { alg: 'RS256', typ: 'JWT' }
  const payload = {
    iss: email,
    scope: 'https://www.googleapis.com/auth/indexing',
    aud: 'https://oauth2.googleapis.com/token',
    exp: now + 3600,
    iat: now,
  }

  const encodedHeader = Buffer.from(JSON.stringify(header)).toString('base64url')
  const encodedPayload = Buffer.from(JSON.stringify(payload)).toString('base64url')
  const data = `${encodedHeader}.${encodedPayload}`

  const sign = crypto.createSign('RSA-SHA256')
  sign.update(data)
  const signature = sign.sign(privateKey.replace(/\\n/g, '\n'), 'base64url')

  return `${data}.${signature}`
}
