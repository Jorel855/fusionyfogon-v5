import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'

// GET /api/last-update — devuelve el timestamp del último cambio en la DB
// Usado por el polling del hook useLiveUpdates para saber si hay cambios nuevos
export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const tenant = await ensureTenant()

    // Consultar el updatedAt más reciente de las tablas principales
    const [ultimoPlato, ultimoSello, ultimoPedido, ultimaReserva, ultimaEmpresa] = await Promise.all([
      db.plato.findFirst({
        where: { tenantId: tenant.id },
        orderBy: { updatedAt: 'desc' },
        select: { updatedAt: true },
      }),
      db.sello.findFirst({
        where: { tenantId: tenant.id },
        orderBy: { updatedAt: 'desc' },
        select: { updatedAt: true },
      }),
      db.pedido.findFirst({
        where: { tenantId: tenant.id },
        orderBy: { createdAt: 'desc' },
        select: { createdAt: true },
      }),
      db.reserva.findFirst({
        where: { tenantId: tenant.id },
        orderBy: { createdAt: 'desc' },
        select: { createdAt: true },
      }),
      db.empresa.findUnique({
        where: { tenantId: tenant.id },
        select: { updatedAt: true },
      }),
    ])

    // Encontrar el timestamp más reciente
    const timestamps = [
      ultimoPlato?.updatedAt?.getTime() || 0,
      ultimoSello?.updatedAt?.getTime() || 0,
      ultimoPedido?.createdAt?.getTime() || 0,
      ultimaReserva?.createdAt?.getTime() || 0,
      ultimaEmpresa?.updatedAt?.getTime() || 0,
    ]

    const maxTimestamp = Math.max(...timestamps)

    // Determinar qué cambió
    let channel = 'menu:updated'
    if (maxTimestamp === ultimoPedido?.createdAt?.getTime()) channel = 'pedido:created'
    else if (maxTimestamp === ultimaReserva?.createdAt?.getTime()) channel = 'reserva:created'
    else if (maxTimestamp === ultimoSello?.updatedAt?.getTime()) channel = 'sellos:updated'
    else if (maxTimestamp === ultimaEmpresa?.updatedAt?.getTime()) channel = 'empresa:updated'

    return NextResponse.json({
      ok: true,
      timestamp: maxTimestamp,
      channel,
    })
  } catch (e) {
    return NextResponse.json({ ok: false, timestamp: 0 })
  }
}
