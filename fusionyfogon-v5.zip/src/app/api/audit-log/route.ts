import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'

// GET /api/audit-log
export async function GET(req: NextRequest) {
  const tenant = await ensureTenant()
  const { searchParams } = new URL(req.url)
  const limit = parseInt(searchParams.get('limit') || '50')

  const logs = await db.auditLog.findMany({
    where: { tenantId: tenant.id },
    orderBy: { createdAt: 'desc' },
    take: limit,
  })

  return NextResponse.json({
    ok: true,
    logs: logs.map((l) => ({
      id: l.id,
      usuario: l.usuarioNombre,
      accion: l.accion,
      entidad: l.entidad,
      entidadId: l.entidadId,
      detalle: l.detalle,
      fecha: l.createdAt.toISOString(),
    })),
  })
}
