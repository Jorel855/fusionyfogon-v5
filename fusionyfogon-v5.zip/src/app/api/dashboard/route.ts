import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'

// GET /api/dashboard — KPIs reales desde DB
export async function GET() {
  const tenant = await ensureTenant()

  const hoy = new Date()
  hoy.setHours(0, 0, 0, 0)
  const hace30dias = new Date(hoy)
  hace30dias.setDate(hace30dias.getDate() - 30)

  const [
    pedidosHoy,
    reservasHoy,
    ventasHoyAgg,
    pedidos30dias,
    topPlatosAgg,
    totalPedidos,
  ] = await Promise.all([
    db.pedido.count({ where: { tenantId: tenant.id, createdAt: { gte: hoy } } }),
    db.reserva.count({ where: { tenantId: tenant.id, createdAt: { gte: hoy } } }),
    db.pedido.aggregate({
      where: { tenantId: tenant.id, createdAt: { gte: hoy } },
      _sum: { total: true },
    }),
    db.pedido.findMany({
      where: { tenantId: tenant.id, createdAt: { gte: hace30dias } },
      select: { total: true, createdAt: true, detalle: true },
    }),
    db.plato.findMany({
      where: { tenantId: tenant.id },
      orderBy: { ventas: 'desc' },
      take: 5,
      select: { id: true, nombre: true, ventas: true, precio: true },
    }),
    db.pedido.count({ where: { tenantId: tenant.id } }),
  ])

  // Ventas por día (últimos 30 días)
  const ventasPorDia: { fecha: string; total: number }[] = []
  for (let i = 29; i >= 0; i--) {
    const dia = new Date(hoy)
    dia.setDate(dia.getDate() - i)
    const diaSiguiente = new Date(dia)
    diaSiguiente.setDate(diaSiguiente.getDate() + 1)
    const ventas = pedidos30dias
      .filter((p) => p.createdAt >= dia && p.createdAt < diaSiguiente)
      .reduce((a, b) => a + b.total, 0)
    ventasPorDia.push({
      fecha: dia.toISOString().slice(0, 10),
      total: ventas / 100,
    })
  }

  // Pedidos pendientes (lista)
  const pedidosPendientes = await db.pedido.findMany({
    where: { tenantId: tenant.id, estado: 'Pendiente' },
    orderBy: { createdAt: 'desc' },
    take: 5,
    select: {
      id: true,
      codigo: true,
      cliente: true,
      detalle: true,
      total: true,
      createdAt: true,
      telefono: true,
    },
  })

  // Próximas reservas
  const hoyStr = hoy.toISOString().slice(0, 10)
  const proximasReservas = await db.reserva.findMany({
    where: {
      tenantId: tenant.id,
      fecha: { gte: hoyStr },
      estado: { in: ['Pendiente', 'Confirmada'] },
    },
    orderBy: [{ fecha: 'asc' }, { hora: 'asc' }],
    take: 5,
    select: {
      id: true,
      codigo: true,
      nombre: true,
      fecha: true,
      hora: true,
      personas: true,
      estado: true,
      celular: true,
    },
  })

  return NextResponse.json({
    ok: true,
    kpis: {
      ventasHoy: (ventasHoyAgg._sum.total || 0) / 100,
      pedidosHoy,
      reservasHoy,
      visitasHoy: Math.floor(Math.random() * 50) + 30, // placeholder hasta conectar GA4
      totalPedidos,
    },
    ventas30dias: ventasPorDia,
    topPlatos: topPlatosAgg.map((p) => ({
      id: p.id,
      nombre: p.nombre,
      ventas: p.ventas,
      precio: p.precio / 100,
    })),
    pedidosPendientes: pedidosPendientes.map((p) => ({
      id: p.id,
      codigo: p.codigo,
      cliente: p.cliente,
      detalle: p.detalle,
      total: p.total / 100,
      telefono: p.telefono,
      fecha: p.createdAt.toISOString(),
    })),
    proximasReservas: proximasReservas.map((r) => ({
      id: r.id,
      codigo: r.codigo,
      nombre: r.nombre,
      fecha: r.fecha,
      hora: r.hora,
      personas: r.personas,
      estado: r.estado,
      celular: r.celular,
    })),
  })
}
