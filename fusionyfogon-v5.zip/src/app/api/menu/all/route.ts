import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'

// GET /api/menu/all — replicates fyf40 action=all
export async function GET() {
  const tenant = await ensureTenant()
  const [categorias, platos, sellos, empresa] = await Promise.all([
    db.categoria.findMany({
      where: { tenantId: tenant.id },
      orderBy: { orden: 'asc' },
    }),
    db.plato.findMany({
      where: { tenantId: tenant.id },
      orderBy: { orden: 'asc' },
      include: { categoria: true },
    }),
    db.sello.findMany({
      where: { tenantId: tenant.id, visible: true },
      orderBy: { orden: 'asc' },
    }),
    db.empresa.findUnique({ where: { tenantId: tenant.id } }),
  ])

  return NextResponse.json({
    ok: true,
    tenant: { id: tenant.id, nombre: tenant.nombre, rubro: tenant.rubro },
    menu: {
      categorias: categorias.map((c) => ({
        id: c.slug,
        nombre: c.nombre,
        icono: c.icono,
        visible: c.visible,
      })),
      platos: platos.map((p) => ({
        id: p.id,
        slug: p.slug,
        categoria: p.categoria?.slug || null,
        nombre: p.nombre,
        descripcion: p.descripcion,
        precio: p.precio / 100,
        badge: p.badge,
        imagen: p.imagenUrl,
        visible: p.visible,
        ventas: p.ventas,
        programa: p.programaActivo
          ? { activo: true, desde: p.programaDesde, hasta: p.programaHasta }
          : null,
      })),
    },
    empresa: empresa
      ? {
          info: {
            nombre: empresa.nombre,
            tagline: empresa.tagline,
            telefono: empresa.telefono,
            whatsapp: empresa.whatsapp,
            email: empresa.email,
            direccion: empresa.direccion,
            horarios: empresa.horarios,
            facebook: empresa.facebook,
            instagram: empresa.instagram,
            tiktok: empresa.tiktok,
            mapsUrl: empresa.mapsUrl,
            dominioPrincipal: empresa.dominioPrincipal,
          },
          identidad: {
            colorPrimario: empresa.colorPrimario,
            colorSecundario: empresa.colorSecundario,
            colorFondo: empresa.colorFondo,
            colorTexto: empresa.colorTexto,
            logoUrl: empresa.logoUrl,
          },
          seo: {
            title: empresa.seoTitle,
            description: empresa.seoDescription,
            keyword: empresa.seoKeyword,
          },
        }
      : null,
    sellos: sellos.map((s) => ({ emoji: s.emoji, texto: s.texto })),
  })
}
