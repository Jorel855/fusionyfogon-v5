import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'
import { requireRole } from '@/lib/auth'
import { emitSellosUpdated } from '@/lib/events'

// PATCH /api/sellos/[id] — requiere sellos:write
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const authResult = await requireRole(req, 'sellos:write')
  if (authResult instanceof NextResponse) return authResult

  const tenant = await ensureTenant()
  const { id } = await params
  const body = await req.json()
  const existing = await db.sello.findFirst({ where: { id, tenantId: tenant.id } })
  if (!existing) return NextResponse.json({ ok: false, error: 'No encontrado' }, { status: 404 })

  const updated = await db.sello.update({
    where: { id },
    data: {
      ...(body.emoji ? { emoji: body.emoji } : {}),
      ...(body.texto ? { texto: body.texto } : {}),
      ...(body.visible !== undefined ? { visible: body.visible } : {}),
      ...(body.orden !== undefined ? { orden: body.orden } : {}),
    },
  })

  // 🔔 Emitir evento para sincronización en tiempo real
  emitSellosUpdated(tenant.id)

  return NextResponse.json({ ok: true, sello: updated })
}

// DELETE /api/sellos/[id] — requiere sellos:write
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const authResult = await requireRole(req, 'sellos:write')
  if (authResult instanceof NextResponse) return authResult

  const tenant = await ensureTenant()
  const { id } = await params
  const existing = await db.sello.findFirst({ where: { id, tenantId: tenant.id } })
  if (!existing) return NextResponse.json({ ok: false, error: 'No encontrado' }, { status: 404 })
  await db.sello.delete({ where: { id } })

  // 🔔 Emitir evento
  emitSellosUpdated(tenant.id)

  return NextResponse.json({ ok: true })
}
