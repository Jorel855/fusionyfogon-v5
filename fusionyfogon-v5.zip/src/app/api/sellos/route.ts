import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'

// GET /api/sellos
export async function GET() {
  const tenant = await ensureTenant()
  const sellos = await db.sello.findMany({
    where: { tenantId: tenant.id },
    orderBy: { orden: 'asc' },
  })
  return NextResponse.json({
    ok: true,
    sellos: sellos.map((s) => ({
      id: s.id,
      emoji: s.emoji,
      texto: s.texto,
      orden: s.orden,
      visible: s.visible,
    })),
  })
}

// POST /api/sellos
export async function POST(req: NextRequest) {
  const tenant = await ensureTenant()
  const body = await req.json()
  if (!body.emoji || !body.texto) {
    return NextResponse.json({ ok: false, error: 'Faltan emoji y texto' }, { status: 400 })
  }
  const maxOrden = await db.sello.max({ where: { tenantId: tenant.id }, _max: { orden: true } })
  const created = await db.sello.create({
    data: {
      tenantId: tenant.id,
      emoji: body.emoji,
      texto: body.texto,
      orden: (maxOrden._max.orden || -1) + 1,
      visible: body.visible !== false,
    },
  })
  return NextResponse.json({ ok: true, sello: created })
}
