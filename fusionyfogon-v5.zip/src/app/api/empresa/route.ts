import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'
import { requireRole } from '@/lib/auth'

// GET /api/empresa — config del negocio (público: lo lee la web pública)
export async function GET() {
  const tenant = await ensureTenant()
  const empresa = await db.empresa.findUnique({
    where: { tenantId: tenant.id },
    include: { tenant: true },
  })
  if (!empresa) {
    return NextResponse.json({ ok: false, error: 'Empresa no encontrada' }, { status: 404 })
  }
  return NextResponse.json({
    ok: true,
    empresa: {
      nombre: empresa.nombre,
      tagline: empresa.tagline,
      telefono: empresa.telefono,
      whatsapp: empresa.whatsapp,
      email: empresa.email,
      direccion: empresa.direccion,
      horarios: empresa.horarios,
      facebook: empresa.facebook,
      instagram: empresa.instagram,
      tiktok: empresa.tiktok,
      mapsUrl: empresa.mapsUrl,
      identidad: {
        colorPrimario: empresa.colorPrimario,
        colorSecundario: empresa.colorSecundario,
        colorFondo: empresa.colorFondo,
        colorTexto: empresa.colorTexto,
        logoUrl: empresa.logoUrl,
        faviconUrl: empresa.faviconUrl,
      },
      seo: {
        title: empresa.seoTitle,
        description: empresa.seoDescription,
        keyword: empresa.seoKeyword,
      },
      dominios: {
        principal: empresa.dominioPrincipal,
        redirects: empresa.dominiosRedirect ? JSON.parse(empresa.dominiosRedirect) : [],
      },
      idioma: empresa.idioma,
      moneda: empresa.moneda,
      zonaHoraria: empresa.zonaHoraria,
      rubro: tenant.rubro,
    },
  })
}

// PUT /api/empresa — actualizar config (solo Admin o Editor)
export async function PUT(req: NextRequest) {
  const authResult = await requireRole(req, 'content:write')
  if (authResult instanceof NextResponse) return authResult

  const tenant = await ensureTenant()
  const body = await req.json()

  const data: any = {}
  const f = body.empresa || body

  if (f.nombre) data.nombre = f.nombre
  if (f.tagline !== undefined) data.tagline = f.tagline
  if (f.telefono !== undefined) data.telefono = f.telefono
  if (f.whatsapp !== undefined) data.whatsapp = f.whatsapp
  if (f.email !== undefined) data.email = f.email
  if (f.direccion !== undefined) data.direccion = f.direccion
  if (f.horarios !== undefined) data.horarios = f.horarios
  if (f.facebook !== undefined) data.facebook = f.facebook
  if (f.instagram !== undefined) data.instagram = f.instagram
  if (f.tiktok !== undefined) data.tiktok = f.tiktok
  if (f.mapsUrl !== undefined) data.mapsUrl = f.mapsUrl

  if (f.identidad) {
    if (f.identidad.colorPrimario) data.colorPrimario = f.identidad.colorPrimario
    if (f.identidad.colorSecundario) data.colorSecundario = f.identidad.colorSecundario
    if (f.identidad.colorFondo) data.colorFondo = f.identidad.colorFondo
    if (f.identidad.colorTexto) data.colorTexto = f.identidad.colorTexto
    if (f.identidad.logoUrl !== undefined) data.logoUrl = f.identidad.logoUrl
    if (f.identidad.faviconUrl !== undefined) data.faviconUrl = f.identidad.faviconUrl
  }

  if (f.seo) {
    if (f.seo.title !== undefined) data.seoTitle = f.seo.title
    if (f.seo.description !== undefined) data.seoDescription = f.seo.description
    if (f.seo.keyword !== undefined) data.seoKeyword = f.seo.keyword
  }

  if (f.dominios) {
    if (f.dominios.principal) data.dominioPrincipal = f.dominios.principal
    if (f.dominios.redirects) data.dominiosRedirect = JSON.stringify(f.dominios.redirects)
  }

  if (f.idioma) data.idioma = f.idioma
  if (f.moneda) data.moneda = f.moneda
  if (f.zonaHoraria) data.zonaHoraria = f.zonaHoraria

  if (f.rubro && tenant.rubro !== f.rubro) {
    await db.tenant.update({ where: { id: tenant.id }, data: { rubro: f.rubro } })
  }

  const updated = await db.empresa.update({
    where: { tenantId: tenant.id },
    data,
  })

  // Audit log
  await db.auditLog.create({
    data: {
      tenantId: tenant.id,
      usuarioNombre: body.usuario || 'Admin',
      accion: 'config',
      entidad: 'empresa',
      entidadId: updated.id,
      detalle: 'Actualizó configuración del negocio',
    },
  })

  return NextResponse.json({ ok: true, empresa: { nombre: updated.nombre } })
}
