import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'

// POST /api/whatsapp/send — envía mensaje WhatsApp Cloud API
// Body: { telefono, mensaje, plantillaEstado, pedidoId }
export async function POST(req: NextRequest) {
  const tenant = await ensureTenant()
  const body = await req.json()

  const token = process.env.WHATSAPP_TOKEN
  const phoneId = process.env.WHATSAPP_PHONE_ID

  // Si no hay credenciales, simula envío (modo demo)
  if (!token || !phoneId) {
    console.log('[WhatsApp] Demo mode — credenciales no configuradas')
    console.log('[WhatsApp] Para:', body.telefono)
    console.log('[WhatsApp] Mensaje:', body.mensaje?.substring(0, 100))

    // Marca como enviado en la DB
    if (body.pedidoId) {
      await db.pedido.update({
        where: { id: body.pedidoId },
        data: { whatsappEnviado: true },
      })
    }

    return NextResponse.json({
      ok: true,
      demo: true,
      message: 'Modo demo: WhatsApp Cloud API no configurado. Mensaje simulado.',
      to: body.telefono,
    })
  }

  // Envío real a WhatsApp Cloud API
  try {
    const res = await fetch(`https://graph.facebook.com/v18.0/${phoneId}/messages`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        to: body.telefono.replace(/[^0-9]/g, ''),
        type: 'text',
        text: { body: body.mensaje },
      }),
    })

    const data = await res.json()

    if (!res.ok) {
      return NextResponse.json(
        { ok: false, error: data.error?.message || 'Error enviando WhatsApp' },
        { status: 500 }
      )
    }

    // Marca como enviado en DB
    if (body.pedidoId) {
      await db.pedido.update({
        where: { id: body.pedidoId },
        data: {
          whatsappEnviado: true,
          whatsappMensajeId: data.messages?.[0]?.id,
        },
      })
    }

    return NextResponse.json({ ok: true, messageId: data.messages?.[0]?.id })
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: e instanceof Error ? e.message : 'Error de red' },
      { status: 500 }
    )
  }
}
