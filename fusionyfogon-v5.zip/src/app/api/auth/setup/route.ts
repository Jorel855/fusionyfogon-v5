import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { db } from '@/lib/db'
import { ensureTenant, DEFAULT_TENANT_SLUG } from '@/lib/tenant'
import { signToken, hasAdminUser } from '@/lib/auth'

// POST /api/auth/setup — crea el primer usuario Admin
// Solo funciona si NO existe ningún admin aún (first-run setup)
export async function POST(req: NextRequest) {
  const tenant = await ensureTenant(DEFAULT_TENANT_SLUG)

  // Verifica que no haya admin ya
  if (await hasAdminUser()) {
    return NextResponse.json(
      { ok: false, error: 'Ya existe un administrador. Usa /api/auth/login.' },
      { status: 400 }
    )
  }

  const body = await req.json()
  const { email, password, nombre } = body

  if (!email || !password || !nombre) {
    return NextResponse.json(
      { ok: false, error: 'Faltan nombre, email y contraseña' },
      { status: 400 }
    )
  }

  if (password.length < 6) {
    return NextResponse.json(
      { ok: false, error: 'La contraseña debe tener al menos 6 caracteres' },
      { status: 400 }
    )
  }

  // Crea el primer usuario Admin
  const passwordHash = await bcrypt.hash(password, 10)
  const usuario = await db.usuario.create({
    data: {
      tenantId: tenant.id,
      email: email.toLowerCase(),
      nombre,
      rol: 'Admin',
      passwordHash,
      activo: true,
      ultimoAcceso: new Date(),
    },
  })

  // Audit log
  await db.auditLog.create({
    data: {
      tenantId: tenant.id,
      usuarioNombre: nombre,
      accion: 'auth',
      entidad: 'usuario',
      entidadId: usuario.id,
      detalle: `Setup inicial — Admin creado: ${email}`,
    },
  })

  const token = signToken({
    id: usuario.id,
    email: usuario.email,
    nombre: usuario.nombre,
    rol: 'Admin',
    tenantId: tenant.id,
  })

  return NextResponse.json({
    ok: true,
    token,
    user: {
      id: usuario.id,
      email: usuario.email,
      nombre: usuario.nombre,
      rol: 'Admin',
    },
  })
}
