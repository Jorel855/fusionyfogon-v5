import { NextRequest, NextResponse } from 'next/server'
import { verifyToken, getTokenFromRequest } from '@/lib/auth'

// GET /api/auth/me — devuelve el usuario actual desde el token
export async function GET(req: NextRequest) {
  const token = getTokenFromRequest(req)
  if (!token) {
    return NextResponse.json({ ok: false, error: 'No autenticado' }, { status: 401 })
  }

  const user = verifyToken(token)
  if (!user) {
    return NextResponse.json({ ok: false, error: 'Token inválido' }, { status: 401 })
  }

  return NextResponse.json({
    ok: true,
    user: {
      id: user.id,
      email: user.email,
      nombre: user.nombre,
      rol: user.rol,
    },
  })
}
