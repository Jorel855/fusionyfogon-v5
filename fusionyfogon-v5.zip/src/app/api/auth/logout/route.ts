import { NextRequest, NextResponse } from 'next/server'
import { verifyToken, getTokenFromRequest } from '@/lib/auth'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'

// POST /api/auth/logout — registra el logout en audit log
export async function POST(req: NextRequest) {
  const token = getTokenFromRequest(req)
  if (token) {
    const user = verifyToken(token)
    if (user) {
      const tenant = await ensureTenant()
      await db.auditLog.create({
        data: {
          tenantId: tenant.id,
          usuarioNombre: user.nombre,
          accion: 'auth',
          entidad: 'usuario',
          entidadId: user.id,
          detalle: 'Cierre de sesión',
        },
      })
    }
  }

  return NextResponse.json({ ok: true })
}
