import { NextResponse } from 'next/server'
import { hasAdminUser } from '@/lib/auth'

// GET /api/auth/status — devuelve si hay admin configurado o hace falta setup
export async function GET() {
  const hasAdmin = await hasAdminUser()
  return NextResponse.json({
    ok: true,
    needsSetup: !hasAdmin,
    authEnabled: true,
  })
}
