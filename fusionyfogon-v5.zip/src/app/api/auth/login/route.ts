import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { db } from '@/lib/db'
import { ensureTenant, DEFAULT_TENANT_SLUG } from '@/lib/tenant'
import { signToken } from '@/lib/auth'

// POST /api/auth/login — login con email + password
export async function POST(req: NextRequest) {
  const tenant = await ensureTenant(DEFAULT_TENANT_SLUG)
  const body = await req.json()
  const { email, password } = body

  if (!email || !password) {
    return NextResponse.json(
      { ok: false, error: 'Faltan email y contraseña' },
      { status: 400 }
    )
  }

  const usuario = await db.usuario.findFirst({
    where: { tenantId: tenant.id, email: email.toLowerCase(), activo: true },
  })

  if (!usuario || !usuario.passwordHash) {
    return NextResponse.json(
      { ok: false, error: 'Credenciales inválidas' },
      { status: 401 }
    )
  }

  const valid = await bcrypt.compare(password, usuario.passwordHash)
  if (!valid) {
    return NextResponse.json(
      { ok: false, error: 'Credenciales inválidas' },
      { status: 401 }
    )
  }

  // Actualiza ultimo acceso
  await db.usuario.update({
    where: { id: usuario.id },
    data: { ultimoAcceso: new Date() },
  })

  // Audit log
  await db.auditLog.create({
    data: {
      tenantId: tenant.id,
      usuarioNombre: usuario.nombre,
      accion: 'auth',
      entidad: 'usuario',
      entidadId: usuario.id,
      detalle: `Inicio de sesión`,
    },
  })

  const token = signToken({
    id: usuario.id,
    email: usuario.email,
    nombre: usuario.nombre,
    rol: usuario.rol as any,
    tenantId: tenant.id,
  })

  return NextResponse.json({
    ok: true,
    token,
    user: {
      id: usuario.id,
      email: usuario.email,
      nombre: usuario.nombre,
      rol: usuario.rol,
    },
  })
}
