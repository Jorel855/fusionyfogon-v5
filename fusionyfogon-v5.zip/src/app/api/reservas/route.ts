import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant, nextCodigo } from '@/lib/tenant'
import { emitReservaCreated } from '@/lib/events'

// GET /api/reservas
export async function GET(req: NextRequest) {
  const tenant = await ensureTenant()
  const { searchParams } = new URL(req.url)
  const fecha = searchParams.get('fecha')

  const reservas = await db.reserva.findMany({
    where: {
      tenantId: tenant.id,
      ...(fecha ? { fecha } : {}),
    },
    orderBy: [{ fecha: 'asc' }, { hora: 'asc' }],
  })

  return NextResponse.json({
    ok: true,
    reservas: reservas.map((r) => ({
      id: r.id,
      codigo: r.codigo,
      nombre: r.nombre,
      celular: r.celular,
      email: r.email,
      fecha: r.fecha,
      hora: r.hora,
      personas: r.personas,
      estado: r.estado,
      profesional: r.profesional,
      servicioId: r.servicioId,
      notas: r.notas,
    })),
  })
}

// POST /api/reservas — replicates fyf40 action=reserva_nuevo
export async function POST(req: NextRequest) {
  const tenant = await ensureTenant()
  const body = await req.json()

  // Validate
  const data = body.data || body
  if (!data.nombre || !data.celular || !data.fecha || !data.hora || !data.personas) {
    return NextResponse.json(
      { ok: false, error: 'Faltan campos: nombre, celular, fecha, hora, personas' },
      { status: 400 }
    )
  }

  const codigo = await nextCodigo(tenant.id, 'Reserva')

  const reserva = await db.reserva.create({
    data: {
      tenantId: tenant.id,
      codigo,
      nombre: data.nombre,
      celular: data.celular,
      email: data.email || null,
      fecha: data.fecha,
      hora: data.hora,
      personas: parseInt(data.personas),
      estado: 'Pendiente',
      profesional: data.profesional || null,
      servicioId: data.servicioId || null,
      notas: data.notas || null,
    },
  })

  // 🔔 Emitir evento para que el admin se actualice en tiempo real
  emitReservaCreated(tenant.id, reserva.id)

  return NextResponse.json({
    ok: true,
    reserva: {
      id: reserva.id,
      codigo: reserva.codigo,
      estado: reserva.estado,
    },
  })
}
