import { NextRequest } from 'next/server'
import { eventBus } from '@/lib/events'

// GET /api/events — Server-Sent Events para sincronización en tiempo real
// La web pública se conecta aquí y recibe notificaciones cuando el admin hace cambios
export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  const encoder = new TextEncoder()

  const stream = new ReadableStream({
    start(controller) {
      // Envía evento inicial de conexión
      controller.enqueue(
        encoder.encode(`data: ${JSON.stringify({ type: 'connected', timestamp: Date.now() })}\n\n`)
      )

      // Suscribe a todos los eventos
      const unsubscribe = eventBus.subscribe('*', (data) => {
        try {
          controller.enqueue(
            encoder.encode(`data: ${JSON.stringify(data)}\n\n`)
          )
        } catch (e) {
          // Controller cerrado
        }
      })

      // Heartbeat cada 30 segundos para mantener conexión viva
      const heartbeat = setInterval(() => {
        try {
          controller.enqueue(
            encoder.encode(`: heartbeat\n\n`)
          )
        } catch (e) {
          clearInterval(heartbeat)
        }
      }, 30000)

      // Cleanup cuando el cliente se desconecta
      req.signal.addEventListener('abort', () => {
        unsubscribe()
        clearInterval(heartbeat)
        try {
          controller.close()
        } catch (e) {}
      })
    },
  })

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',
    },
  })
}
