import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'

// GET /api/categorias
export async function GET() {
  const tenant = await ensureTenant()
  const categorias = await db.categoria.findMany({
    where: { tenantId: tenant.id },
    orderBy: { orden: 'asc' },
    include: { _count: { select: { platos: true } } },
  })
  return NextResponse.json({
    ok: true,
    categorias: categorias.map((c) => ({
      id: c.id,
      slug: c.slug,
      nombre: c.nombre,
      icono: c.icono,
      orden: c.orden,
      visible: c.visible,
      platosCount: c._count.platos,
    })),
  })
}

// POST /api/categorias
export async function POST(req: NextRequest) {
  const tenant = await ensureTenant()
  const body = await req.json()
  if (!body.slug || !body.nombre) {
    return NextResponse.json({ ok: false, error: 'Faltan slug y nombre' }, { status: 400 })
  }
  const maxOrden = await db.categoria.max({ where: { tenantId: tenant.id }, _max: { orden: true } })
  const created = await db.categoria.create({
    data: {
      tenantId: tenant.id,
      slug: body.slug,
      nombre: body.nombre,
      icono: body.icono || '🍽️',
      orden: (maxOrden._max.orden || -1) + 1,
      visible: body.visible !== false,
    },
  })
  return NextResponse.json({ ok: true, categoria: created })
}
