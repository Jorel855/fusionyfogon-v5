import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'

// PATCH /api/categorias/[id]
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const tenant = await ensureTenant()
  const { id } = await params
  const body = await req.json()
  const existing = await db.categoria.findFirst({ where: { id, tenantId: tenant.id } })
  if (!existing) return NextResponse.json({ ok: false, error: 'No encontrada' }, { status: 404 })

  const updated = await db.categoria.update({
    where: { id },
    data: {
      ...(body.nombre ? { nombre: body.nombre } : {}),
      ...(body.icono ? { icono: body.icono } : {}),
      ...(body.visible !== undefined ? { visible: body.visible } : {}),
      ...(body.orden !== undefined ? { orden: body.orden } : {}),
    },
  })
  return NextResponse.json({ ok: true, categoria: updated })
}

// DELETE /api/categorias/[id]
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const tenant = await ensureTenant()
  const { id } = await params
  const existing = await db.categoria.findFirst({ where: { id, tenantId: tenant.id } })
  if (!existing) return NextResponse.json({ ok: false, error: 'No encontrada' }, { status: 404 })

  await db.categoria.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
