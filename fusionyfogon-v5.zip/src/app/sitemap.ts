import { MetadataRoute } from 'next'
import { db } from '@/lib/db'
import { ensureTenant } from '@/lib/tenant'

// /sitemap.xml — generado dinámicamente desde DB
// Usa el dominio real donde esté deployado (no asume fusionyfogon.com)
export const dynamic = 'force-dynamic'
export const revalidate = 3600 // regenera cada hora

function getBaseUrl(): string {
  // 1. Variable de entorno NEXTAUTH_URL (configurada en Netlify)
  if (process.env.NEXTAUTH_URL) {
    return process.env.NEXTAUTH_URL.replace(/\/$/, '')
  }
  // 2. URL que Netlify inyecta automáticamente
  if (process.env.URL) {
    return process.env.URL.replace(/\/$/, '')
  }
  // 3. Fallback por defecto
  return 'https://fusionyfogon.com'
}

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const tenant = await ensureTenant()
  const baseUrl = getBaseUrl()

  const [empresa, categorias, platos] = await Promise.all([
    db.empresa.findUnique({ where: { tenantId: tenant.id } }),
    db.categoria.findMany({ where: { tenantId: tenant.id, visible: true } }),
    db.plato.findMany({
      where: { tenantId: tenant.id, visible: true },
      include: { categoria: true },
    }),
  ])

  const now = new Date()

  const entries: MetadataRoute.Sitemap = [
    // Home
    {
      url: baseUrl,
      lastModified: now,
      changeFrequency: 'daily',
      priority: 1,
    },
  ]

  // Categorías visibles
  for (const cat of categorias) {
    entries.push({
      url: `${baseUrl}/categoria/${cat.slug}`,
      lastModified: now,
      changeFrequency: 'weekly',
      priority: 0.8,
    })
  }

  // Platos visibles
  for (const p of platos) {
    if (p.slug) {
      entries.push({
        url: `${baseUrl}/p/${p.slug}`,
        lastModified: p.updatedAt,
        changeFrequency: 'weekly',
        priority: 0.7,
      })
    }
  }

  // Páginas estáticas (secciones de la home)
  const paginasEstaticas = ['/carta', '/reservas', '/catering', '/esencia', '/contacto']
  for (const p of paginasEstaticas) {
    entries.push({
      url: `${baseUrl}${p}`,
      lastModified: now,
      changeFrequency: 'monthly',
      priority: 0.6,
    })
  }

  return entries
}
