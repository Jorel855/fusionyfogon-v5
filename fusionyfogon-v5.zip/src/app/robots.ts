import { MetadataRoute } from 'next'
import { ensureTenant } from '@/lib/tenant'

// /robots.txt
// Usa el dominio real donde esté deployado
export const dynamic = 'force-dynamic'

function getBaseUrl(): string {
  if (process.env.NEXTAUTH_URL) {
    return process.env.NEXTAUTH_URL.replace(/\/$/, '')
  }
  if (process.env.URL) {
    return process.env.URL.replace(/\/$/, '')
  }
  return 'https://fusionyfogon.com'
}

export default async function robots(): Promise<MetadataRoute.Robots> {
  const baseUrl = getBaseUrl()

  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: ['/admin', '/api/', '/_next/'],
      },
    ],
    sitemap: `${baseUrl}/sitemap.xml`,
    host: baseUrl,
  }
}
