'use client';

import { useState } from 'react';
import { AdminShell, type ViewKey } from '@/components/admin/admin-shell';
import { LoginScreen } from '@/components/admin/login-screen';
import { DashboardView } from '@/components/admin/views/dashboard';
import { PedidosView } from '@/components/admin/views/pedidos';
import { ReservasView } from '@/components/admin/views/reservas';
import { CatalogoView } from '@/components/admin/views/catalogo';
import { IdentidadView } from '@/components/admin/views/identidad';
import { SeoView } from '@/components/admin/views/seo';
import { RespaldosView } from '@/components/admin/views/respaldos';
import { IntegracionesView } from '@/components/admin/views/integraciones';
import { UsuariosView } from '@/components/admin/views/usuarios';
import { DominiosNegocioView } from '@/components/admin/views/dominios-negocio';
import { NotificacionesView } from '@/components/admin/views/notificaciones';
import { VisibilidadPermisosView } from '@/components/admin/views/visibilidad-permisos';
import { PestanasView } from '@/components/admin/views/pestanas';
import { SellosView } from '@/components/admin/views/sellos';
import { PlaceholderView } from '@/components/admin/views/placeholder';
import { useAuth } from '@/hooks/use-auth';
import { Loader2 } from 'lucide-react';

export default function Home() {
  const [view, setView] = useState<ViewKey>('dashboard');
  const [tenant, setTenant] = useState('fyf');
  const { user, loading, needsSetup } = useAuth();

  const handleNavigate = (v: string) => setView(v as ViewKey);

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-primary animate-spin mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Verificando sesión...</p>
        </div>
      </div>
    );
  }

  // No autenticado → login (o setup si no hay admin)
  if (!user) {
    return <LoginScreen />;
  }

  const render = () => {
    switch (view) {
      case 'dashboard':
        return <DashboardView onNavigate={handleNavigate} />;
      case 'pedidos':
        return <PedidosView />;
      case 'reservas':
        return <ReservasView />;
      case 'catalogo-platos':
        return <CatalogoView />;
      case 'config-identidad':
        return <IdentidadView />;
      case 'config-visibilidad':
        return <VisibilidadPermisosView />;
      case 'config-dominios':
        return <DominiosNegocioView />;
      case 'config-seo':
        return <SeoView />;
      case 'config-notificaciones':
        return <NotificacionesView />;
      case 'config-respaldos':
        return <RespaldosView />;
      case 'config-integraciones':
        return <IntegracionesView />;
      case 'config-usuarios':
        return <UsuariosView />;
      case 'catalogo-categorias':
        return <PlaceholderView title="Categorías" description="CRUD de categorías con drag & drop de orden y emoji." />;
      case 'catalogo-sellos':
        return <SellosView />;
      case 'contenido-hero':
        return <PlaceholderView title="Hero / Portada" description="Editor visual del hero: logo, título, tagline, fondo." />;
      case 'contenido-esencia':
        return <PlaceholderView title="Esencia" description="Misión, visión, historia — bloques editables con fotos." />;
      case 'contenido-catering':
        return <PlaceholderView title="Catering" description="Servicios de catering con precios y fotos." />;
      case 'contenido-galeria':
        return <PlaceholderView title="Galería de fotos" description="Drag & drop de fotos con resize automático." />;
      case 'contenido-pestanas':
        return <PestanasView />;
      case 'config-barra':
        return <PlaceholderView title="Barra superior" description="Modo (logo+nombre, solo logo, solo nombre) y tamaño." />;
      case 'config-redes':
        return <PlaceholderView title="Redes sociales" description="Facebook, Instagram, TikTok, Maps con iconos personalizados." />;
      case 'config-ubicacion':
        return <PlaceholderView title="Ubicación y horarios" description="Dirección, horarios, teléfono, WhatsApp, Maps embed." />;
      case 'config-seguridad':
        return <PlaceholderView title="Seguridad" description="PIN con rate-limiting · 2FA · Sesiones activas." />;
      default:
        return <DashboardView onNavigate={handleNavigate} />;
    }
  };

  return (
    <AdminShell view={view} onView={setView} tenant={tenant} onTenant={setTenant}>
      {render()}
    </AdminShell>
  );
}
