import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { PWARegister } from "@/components/pwa-register";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

// Metadata base — sobreescrita dinámicamente por cada página
// metadataBase usa el dominio real donde esté deployado
function getMetadataBase(): URL {
  const url = process.env.NEXTAUTH_URL || process.env.URL || 'https://fusionyfogon.com'
  return new URL(url.replace(/\/$/, ''))
}

export const metadata: Metadata = {
  metadataBase: getMetadataBase(),
  title: {
    default: "FUSIÓN Y FOGÓN | Ahumados & Experiencias. Lebrija, Santander",
    template: "%s | FUSIÓN Y FOGÓN",
  },
  description:
    "Restaurante y charcutería artesanal en Lebrija, Santander. Ahumados a la leña de guayabo, costillares al barril, cóctel tropical y catering campestre. Pedidos por WhatsApp.",
  keywords: ["ahumados", "lebrija", "santander", "charcutería", "catering", "restaurante"],
  authors: [{ name: "Fusión y Fogón" }],
  creator: "Fusión y Fogón",
  publisher: "Fusión y Fogón",
  applicationName: "Fusión y Fogón",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Fusión y Fogón",
  },
  formatDetection: {
    telephone: true,
    address: true,
    email: true,
  },
  icons: {
    icon: [
      { url: "/icons/icon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/icons/icon-180.png", sizes: "180x180", type: "image/png" },
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-256.png", sizes: "256x256", type: "image/png" },
      { url: "/icons/icon-384.png", sizes: "384x384", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [
      { url: "/icons/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
    ],
    shortcut: "/icons/favicon.ico",
    other: [
      { rel: "apple-touch-icon-precomposed", url: "/icons/apple-touch-icon.png" },
    ],
  },
  openGraph: {
    type: "website",
    locale: "es_CO",
    url: "https://fusionyfogon.com",
    siteName: "Fusión y Fogón",
    title: "FUSIÓN Y FOGÓN | Ahumados & Experiencias",
    description:
      "Ahumería artesanal en leña de guayabo, catering campestre y turismo vivencial en Lebrija, Santander.",
    images: [
      {
        url: "/icons/icon-512.png",
        width: 512,
        height: 512,
        alt: "Fusión y Fogón",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "FUSIÓN Y FOGÓN | Ahumados & Experiencias",
    description:
      "Ahumería artesanal en leña de guayabo, catering campestre y turismo vivencial en Lebrija, Santander.",
    images: ["/icons/icon-512.png"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  alternates: {
    canonical: "https://fusionyfogon.com",
    languages: {
      "es-CO": "https://fusionyfogon.com",
    },
  },
  category: "food",
};

// Viewport + theme color PWA
export const viewport: Viewport = {
  themeColor: "#E27613",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  viewportFit: "cover",
};

// JSON-LD estructurado para Google (rich snippets)
const jsonLdBusiness = {
  "@context": "https://schema.org",
  "@type": "Restaurant",
  "@id": "https://fusionyfogon.com/#business",
  name: "Fusión y Fogón",
  alternateName: "Sabores que unen culturas",
  description:
    "Restaurante y charcutería artesanal en Lebrija, Santander. Ahumados a la leña de guayabo, costillares al barril, cóctel tropical y catering campestre.",
  image: "https://fusionyfogon.com/icons/icon-512.png",
  logo: "https://fusionyfogon.com/icons/icon-192.png",
  url: "https://fusionyfogon.com",
  telephone: "+57 350 802 9292",
  email: "contacto@fusionyfogon.com",
  address: {
    "@type": "PostalAddress",
    streetAddress: "Finca El Jazmín, Vereda Puyana",
    addressLocality: "Lebrija",
    addressRegion: "Santander",
    addressCountry: "CO",
  },
  geo: {
    "@type": "GeoCoordinates",
    latitude: 7.2076,
    longitude: -73.2097,
  },
  priceRange: "$$",
  servesCuisine: "Ahumados, Charcutería, Colombiana",
  openingHoursSpecification: [
    {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: ["Thursday", "Friday", "Saturday", "Sunday"],
      opens: "11:30",
      closes: "20:30",
    },
  ],
  sameAs: [
    "https://facebook.com/fusionyfogon",
    "https://instagram.com/fusionyfogon",
    "https://tiktok.com/@fusionyfogon",
  ],
  acceptsReservations: "True",
  menu: "https://fusionyfogon.com/carta",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" className="dark" suppressHydrationWarning>
      <head>
        {/* JSON-LD: negocio */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdBusiness) }}
        />
        {/* PWA: theme color para status bar (móvil) — multi-platform */}
        <meta name="theme-color" content="#E27613" />
        <meta name="msapplication-TileColor" content="#40210A" />
        <meta name="msapplication-tap-highlight" content="no" />

        {/* PWA: instalación Android */}
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="application-name" content="Fusión y Fogón" />

        {/* PWA: instalación iOS */}
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="Fusión y Fogón" />
        <link rel="apple-touch-icon" href="/icons/apple-touch-icon.png" />
        <link rel="apple-touch-icon" sizes="180x180" href="/icons/apple-touch-icon.png" />
        <link rel="apple-touch-icon" sizes="192x192" href="/icons/icon-192.png" />
        <link rel="apple-touch-icon" sizes="256x256" href="/icons/icon-256.png" />
        <link rel="apple-touch-icon" sizes="384x384" href="/icons/icon-384.png" />
        <link rel="apple-touch-icon" sizes="512x512" href="/icons/icon-512.png" />

        {/* Favicon multi-size */}
        <link rel="icon" type="image/png" sizes="32x32" href="/icons/icon-32.png" />
        <link rel="icon" type="image/png" sizes="192x192" href="/icons/icon-192.png" />
        <link rel="icon" type="image/png" sizes="512x512" href="/icons/icon-512.png" />
        <link rel="shortcut icon" href="/icons/favicon.ico" />

        {/* PWA manifest */}
        <link rel="manifest" href="/manifest.webmanifest" />

        {/* DNS prefetch para mejor performance */}
        <link rel="dns-prefetch" href="https://images.unsplash.com" />
        <link rel="preconnect" href="https://images.unsplash.com" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
        style={{ backgroundColor: '#12100E', color: '#F5EFE6' }}
      >
        {children}
        <Toaster />
        <PWARegister />
      </body>
    </html>
  );
}
