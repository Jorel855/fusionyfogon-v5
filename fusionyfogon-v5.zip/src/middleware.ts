import { NextRequest, NextResponse } from 'next/server'
import { verifyToken } from '@/lib/auth'

// ============================================
// MIDDLEWARE — protege rutas /admin/*
// ============================================
// Verifica JWT en cookie o header. Si no hay sesión, deja pasar
// (el AdminShell muestra LoginScreen automáticamente).
// No bloqueamos aquí para permitir SSR del login screen.

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl

  // Solo procesa rutas /admin/*
  if (!pathname.startsWith('/admin')) {
    return NextResponse.next()
  }

  // Rutas públicas dentro de /admin (login, setup)
  // (en el futuro podríamos tener /admin/login como ruta separada)
  // Por ahora, el AdminShell maneja el login client-side

  // Verificar token si existe (para inyectar en headers del request)
  const token =
    req.cookies.get('fyf_admin_token')?.value ||
    req.headers.get('authorization')?.replace('Bearer ', '')

  if (token) {
    const user = verifyToken(token)
    if (user) {
      // Inyectar info del usuario en headers para que las APIs lo usen
      const requestHeaders = new Headers(req.headers)
      requestHeaders.set('x-user-id', user.id)
      requestHeaders.set('x-user-rol', user.rol)
      requestHeaders.set('x-user-email', user.email)
      requestHeaders.set('x-tenant-id', user.tenantId)
      return NextResponse.next({
        request: { headers: requestHeaders },
      })
    }
  }

  // Sin token o token inválido: dejamos pasar (el AdminShell muestra login)
  return NextResponse.next()
}

export const config = {
  matcher: ['/admin/:path*'],
}
