// netlify/functions/scheduled-sitemap.ts
// Cron: cada 6 horas
// Revalida el sitemap.xml para que Google siempre tenga la versión fresca

export const handler = async (event: any) => {
  console.log('[scheduled-sitemap] Revalidando sitemap...', new Date().toISOString())

  try {
    // Next.js ISR revalida el sitemap automáticamente con revalidate=3600
    // Aquí forzamos la regeneración llamando al endpoint con ?preview=1
    const baseUrl = process.env.URL || 'https://fusionyfogon.com'
    const res = await fetch(`${baseUrl}/sitemap.xml`, {
      headers: { 'Cache-Control': 'no-cache' },
    })

    if (!res.ok) {
      throw new Error(`Sitemap fetch failed: ${res.status}`)
    }

    // Ping a Google para que re-lea el sitemap
    await fetch(
      `https://www.google.com/ping?sitemap=${encodeURIComponent(`${baseUrl}/sitemap.xml`)}`
    ).catch(() => {})

    // Ping a Bing también
    await fetch(
      `https://www.bing.com/ping?sitemap=${encodeURIComponent(`${baseUrl}/sitemap.xml`)}`
    ).catch(() => {})

    return {
      statusCode: 200,
      body: JSON.stringify({
        ok: true,
        message: 'Sitemap revalidado y ping a Google/Bing enviado',
        timestamp: new Date().toISOString(),
      }),
    }
  } catch (error) {
    console.error('[scheduled-sitemap] Error:', error)
    return {
      statusCode: 500,
      body: JSON.stringify({ ok: false, error: error instanceof Error ? error.message : 'Error' }),
    }
  }
}
