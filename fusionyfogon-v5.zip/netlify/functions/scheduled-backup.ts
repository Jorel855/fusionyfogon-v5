// netlify/functions/scheduled-backup.ts
// Cron: diario a las 3 AM America/Bogota (8 AM UTC)
// Exporta toda la data del tenant a JSON y la guarda como Backup en DB

import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()

export const handler = async (event: any) => {
  console.log('[scheduled-backup] Iniciando backup automático...', new Date().toISOString())

  try {
    const tenants = await db.tenant.findMany()

    for (const tenant of tenants) {
      const [empresa, categorias, platos, pedidos, reservas, sellos, pestanas, plantillas] = await Promise.all([
        db.empresa.findUnique({ where: { tenantId: tenant.id } }),
        db.categoria.findMany({ where: { tenantId: tenant.id } }),
        db.plato.findMany({ where: { tenantId: tenant.id } }),
        db.pedido.findMany({ where: { tenantId: tenant.id } }),
        db.reserva.findMany({ where: { tenantId: tenant.id } }),
        db.sello.findMany({ where: { tenantId: tenant.id } }),
        db.pestanaExtra.findMany({ where: { tenantId: tenant.id } }),
        db.plantillaWhatsApp.findMany({ where: { tenantId: tenant.id } }),
      ])

      const contenido = JSON.stringify(
        {
          version: '5.0',
          tenant: { slug: tenant.slug, nombre: tenant.nombre, rubro: tenant.rubro },
          exportedAt: new Date().toISOString(),
          data: { empresa, categorias, platos, pedidos, reservas, sellos, pestanas, plantillas },
        },
        null,
        2
      )

      const backup = await db.backup.create({
        data: {
          tenantId: tenant.id,
          tipo: 'auto-diario',
          autor: 'Sistema (cron)',
          size: contenido.length,
          contenido,
        },
      })

      // Rotación: mantiene solo los últimos 30
      const total = await db.backup.count({ where: { tenantId: tenant.id } })
      if (total > 30) {
        const viejos = await db.backup.findMany({
          where: { tenantId: tenant.id },
          orderBy: { createdAt: 'desc' },
          skip: 30,
          select: { id: true },
        })
        await db.backup.deleteMany({ where: { id: { in: viejos.map((v) => v.id) } } })
      }

      console.log(`[scheduled-backup] Tenant ${tenant.slug}: backup ${backup.id} creado (${backup.size} bytes)`)
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        ok: true,
        message: `Backup completado para ${tenants.length} tenant(s)`,
        timestamp: new Date().toISOString(),
      }),
    }
  } catch (error) {
    console.error('[scheduled-backup] Error:', error)
    return {
      statusCode: 500,
      body: JSON.stringify({ ok: false, error: error instanceof Error ? error.message : 'Error' }),
    }
  } finally {
    await db.$disconnect()
  }
}
