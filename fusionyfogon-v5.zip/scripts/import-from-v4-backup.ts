/**
 * Script de importación: lee el JSON de respaldo actual de Fusión y Fogón
 * (el que se descarga desde el panel v4.5) y lo carga en la base de datos nueva.
 *
 * Uso:
 *   bun run scripts/import-from-v4-backup.ts <ruta-al-json>
 *
 * Si no se pasa ruta, descarga el backup desde la API real de fyf40.
 *
 * El script es IDEMPOTENTE: si lo corres 2 veces, no duplica datos.
 */

import { db } from '../src/lib/db'
import { ensureTenant, DEFAULT_TENANT_SLUG } from '../src/lib/tenant'

type BackupV4 = {
  menu?: {
    categorias?: {
      id: string
      nombre: string
      icono: string
      visible?: boolean
    }[]
    platos?: {
      id: number
      categoria: string
      nombre: string
      precio: number
      badge?: string
      descripcion: string
      imagen: string
      visible: boolean
    }[]
  }
  empresa?: {
    info?: {
      nombre: string
      nombreColor?: string
      nombreSize?: string
      telefono?: string
      whatsapp?: string
      email?: string
      direccion?: string
      horarios?: string
      facebook?: string
      instagram?: string
      tiktok?: string
      mapsUrl?: string
    }
    esencia?: { titulo: string; texto: string; foto?: string; visible?: boolean }[]
    catering?: { titulo: string; descripcion: string; precio?: string; icono: string; foto?: string; visible?: boolean }[]
  }
  pedidos?: any[]
  reservas?: any[]
}

async function importFromBackup(backup: BackupV4) {
  console.log('🚀 Iniciando importación desde backup v4...')
  const tenant = await ensureTenant(DEFAULT_TENANT_SLUG)
  console.log(`✅ Tenant: ${tenant.nombre} (${tenant.id})`)

  // 1. Actualizar empresa
  if (backup.empresa?.info) {
    const info = backup.empresa.info
    await db.empresa.upsert({
      where: { tenantId: tenant.id },
      create: {
        tenantId: tenant.id,
        nombre: info.nombre || tenant.nombre,
        tagline: 'Sabores que unen culturas',
        telefono: info.telefono,
        whatsapp: info.whatsapp,
        email: info.email,
        direccion: info.direccion,
        horarios: info.horarios,
        facebook: info.facebook,
        instagram: info.instagram,
        tiktok: info.tiktok,
        mapsUrl: info.mapsUrl,
      },
      update: {
        nombre: info.nombre || tenant.nombre,
        telefono: info.telefono,
        whatsapp: info.whatsapp,
        email: info.email,
        direccion: info.direccion,
        horarios: info.horarios,
        facebook: info.facebook,
        instagram: info.instagram,
        tiktok: info.tiktok,
        mapsUrl: info.mapsUrl,
      },
    })
    console.log('✅ Empresa actualizada')
  }

  // 2. Importar categorías
  if (backup.menu?.categorias) {
    for (const c of backup.menu.categorias) {
      await db.categoria.upsert({
        where: { tenantId_slug: { tenantId: tenant.id, slug: c.id } },
        create: {
          tenantId: tenant.id,
          slug: c.id,
          nombre: c.nombre,
          icono: c.icono || '🍽️',
          visible: c.visible !== false,
        },
        update: {
          nombre: c.nombre,
          icono: c.icono || '🍽️',
          visible: c.visible !== false,
        },
      })
    }
    console.log(`✅ ${backup.menu.categorias.length} categorías importadas`)
  }

  // 3. Importar platos
  if (backup.menu?.platos) {
    const categorias = await db.categoria.findMany({ where: { tenantId: tenant.id } })
    for (const p of backup.menu.platos) {
      const cat = categorias.find((c) => c.slug === p.categoria)
      const slug = p.nombre
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '')

      await db.plato.upsert({
        where: { tenantId_slug: { tenantId: tenant.id, slug } },
        create: {
          tenantId: tenant.id,
          categoriaId: cat?.id,
          nombre: p.nombre,
          descripcion: p.descripcion,
          precio: p.precio * 100, // convertir a centavos
          badge: p.badge,
          imagenUrl: p.imagen?.startsWith('data:') ? undefined : p.imagen,
          visible: p.visible,
          slug,
        },
        update: {
          categoriaId: cat?.id,
          nombre: p.nombre,
          descripcion: p.descripcion,
          precio: p.precio * 100,
          badge: p.badge,
          visible: p.visible,
        },
      })
    }
    console.log(`✅ ${backup.menu.platos.length} platos importados`)
  }

  // 4. Importar pedidos (opcional, solo si existen)
  if (backup.pedidos && backup.pedidos.length > 0) {
    let imported = 0
    for (const p of backup.pedidos) {
      // Convertir fecha "9/10/2026, 15:19:51" a ISO
      const fecha = parseFecha(p.fecha)
      const existing = await db.pedido.findFirst({
        where: { tenantId: tenant.id, codigo: p.id?.slice(-6) || 'unknown' },
      })
      if (existing) continue

      await db.pedido.create({
        data: {
          tenantId: tenant.id,
          codigo: p.id?.slice(-6) || String(1023 + imported),
          cliente: p.cliente || 'Cliente',
          telefono: p.telefono && p.telefono !== '-' ? p.telefono : null,
          direccion: p.direccion,
          notas: p.notas,
          detalle: p.detalle,
          total: p.total * 100,
          estado: p.estado || 'Pendiente',
          origen: 'admin',
          createdAt: fecha,
        },
      })
      imported++
    }
    console.log(`✅ ${imported} pedidos importados`)
  }

  // 5. Importar reservas (opcional)
  if (backup.reservas && backup.reservas.length > 0) {
    let imported = 0
    for (const r of backup.reservas) {
      const existing = await db.reserva.findFirst({
        where: { tenantId: tenant.id, codigo: r.id?.slice(-6) || 'unknown' },
      })
      if (existing) continue

      await db.reserva.create({
        data: {
          tenantId: tenant.id,
          codigo: r.id?.slice(-6) || String(1023 + imported),
          nombre: r.nombre,
          celular: r.celular,
          email: r.email,
          fecha: r.fecha,
          hora: r.hora,
          personas: r.personas,
          estado: r.estado || 'Pendiente',
        },
      })
      imported++
    }
    console.log(`✅ ${imported} reservas importadas`)
  }

  // 6. Crear plantillas WhatsApp por defecto
  const plantillasDefault = [
    {
      estado: 'Pendiente',
      titulo: 'Pedido recibido',
      cuerpo:
        '¡Hola {{nombre}}! 👋 Recibimos tu pedido #{{id}} por {{total}}. Lo estamos revisando y te confirmamos en breve. ¡Gracias por elegirnos! 🔥',
    },
    {
      estado: 'Confirmado',
      titulo: 'Pedido confirmado',
      cuerpo:
        '¡Listo {{nombre}}! ✅ Tu pedido #{{id}} está confirmado. Lo preparamos con todo el cariño. Tiempo estimado: {{tiempo}}. ¡Te avisamos cuando esté listo!',
    },
    {
      estado: 'Preparacion',
      titulo: 'En preparación',
      cuerpo:
        '{{nombre}}, tu pedido #{{id}} ya está en el fogón 🔥 ¡Humeando rico! Te avisamos cuando esté listo.',
    },
    {
      estado: 'Listo',
      titulo: 'Pedido listo',
      cuerpo: '¡Tu pedido #{{id}} está listo {{nombre}}! 🎉 Puedes pasar a recogerlo o está en camino. ¡Gracias! 🔥',
    },
    {
      estado: 'Entregado',
      titulo: 'Pedido entregado',
      cuerpo:
        '¡Esperamos que lo disfrutes {{nombre}}! 😊 ¿Nos dejas una reseña en Google? {{link_resena}} ¡Vuelve pronto!',
      activa: false,
    },
    {
      estado: 'Cancelado',
      titulo: 'Pedido cancelado',
      cuerpo:
        '{{nombre}}, lamentablemente tuvimos que cancelar tu pedido #{{id}}. Motivo: {{motivo}}. Para reembolso o dudas, escríbenos. Disculpa las molestias.',
    },
  ]

  for (const p of plantillasDefault) {
    await db.plantillaWhatsApp.upsert({
      where: { tenantId_estado: { tenantId: tenant.id, estado: p.estado } },
      create: {
        tenantId: tenant.id,
        estado: p.estado,
        titulo: p.titulo,
        cuerpo: p.cuerpo,
        activa: p.activa ?? true,
      },
      update: {},
    })
  }
  console.log(`✅ ${plantillasDefault.length} plantillas WhatsApp creadas`)

  // 7. Crear sellos por defecto si no hay
  const sellosExistentes = await db.sello.count({ where: { tenantId: tenant.id } })
  if (sellosExistentes === 0) {
    await db.sello.createMany({
      data: [
        { tenantId: tenant.id, emoji: '🔥', texto: 'Ahumado con leña de guayabo', orden: 0, visible: true },
        { tenantId: tenant.id, emoji: '🍃', texto: '100% natural, sin conservantes', orden: 1, visible: true },
        { tenantId: tenant.id, emoji: '❤️', texto: 'Receta de la abuela', orden: 2, visible: true },
        { tenantId: tenant.id, emoji: '⏰', texto: 'Cocción lenta 8 horas', orden: 3, visible: false },
      ],
    })
    console.log('✅ 4 sellos por defecto creados')
  }

  console.log('\n🎉 Importación completada!')
  console.log(`   Tenant: ${tenant.nombre}`)
  console.log(`   Próximo paso: arrancar el dev server y probar /api/menu/all`)
}

function parseFecha(s: string): Date {
  // "9/10/2026, 15:19:51" -> Date
  const m = s.match(/(\d+)\/(\d+)\/(\d+),\s*(\d+):(\d+):(\d+)/)
  if (!m) return new Date()
  return new Date(
    parseInt(m[3]),
    parseInt(m[2]) - 1,
    parseInt(m[1]),
    parseInt(m[4]),
    parseInt(m[5]),
    parseInt(m[6])
  )
}

// ============================================
// Main
// ============================================
async function main() {
  const jsonPath = process.argv[2]

  let backup: BackupV4

  if (jsonPath) {
    console.log(`📄 Leyendo backup desde archivo: ${jsonPath}`)
    const fs = await import('fs')
    backup = JSON.parse(fs.readFileSync(jsonPath, 'utf-8'))
  } else {
    console.log('🌐 Descargando backup desde API fyf40 (action=all)...')
    const res = await fetch('https://fusionyfogon.com/.netlify/functions/fyf40?action=all')
    backup = (await res.json()) as BackupV4
  }

  await importFromBackup(backup)
  await db.$disconnect()
}

main().catch((e) => {
  console.error('❌ Error:', e)
  process.exit(1)
})
