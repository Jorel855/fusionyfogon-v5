#!/usr/bin/env python3
"""
Genera iconos PWA para Fusión y Fogón.
Crea: icon-192.png, icon-512.png, icon-512-maskable.png, apple-touch-icon.png
Diseño: fondo gradiente naranja (#CC6600 → #8B4513) + llama blanca
"""
import os
from PIL import Image, ImageDraw, ImageFilter
import math

OUTPUT_DIR = "/home/z/my-project/public/icons"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Colores marca
COLOR_PRIMARY = (204, 102, 0)      # #CC6600
COLOR_SECONDARY = (139, 69, 19)    # #8B4513
COLOR_DARK = (18, 16, 14)          # #12100E
COLOR_WHITE = (255, 255, 255)

def create_gradient_background(size, color1, color2, diagonal=True):
    """Crea un fondo con gradiente diagonal."""
    img = Image.new('RGB', (size, size), color1)
    draw = ImageDraw.Draw(img)
    if diagonal:
        for i in range(size):
            # Interpolar entre color1 y color2
            ratio = i / size
            r = int(color1[0] * (1 - ratio) + color2[0] * ratio)
            g = int(color1[1] * (1 - ratio) + color2[1] * ratio)
            b = int(color1[2] * (1 - ratio) + color2[2] * ratio)
            draw.line([(i, 0), (i, size)], fill=(r, g, b))
    return img

def draw_flame(draw, size, color=COLOR_WHITE):
    """Dibuja una llama simplificada centrada."""
    cx, cy = size // 2, size // 2
    # Llama: forma de gota asimétrica
    # Usamos polígonos para crear la forma de llama
    scale = size / 512  # escala base
    
    # Llama exterior (más grande)
    flame_outer = [
        (cx, cy - 140 * scale),  # pico superior
        (cx + 60 * scale, cy - 80 * scale),
        (cx + 80 * scale, cy - 20 * scale),
        (cx + 70 * scale, cy + 60 * scale),
        (cx + 40 * scale, cy + 110 * scale),
        (cx, cy + 130 * scale),  # pico inferior
        (cx - 40 * scale, cy + 110 * scale),
        (cx - 70 * scale, cy + 60 * scale),
        (cx - 80 * scale, cy - 20 * scale),
        (cx - 60 * scale, cy - 80 * scale),
    ]
    draw.polygon(flame_outer, fill=color)
    
    # Llama interior (más oscura, da efecto de profundidad)
    flame_inner = [
        (cx, cy - 90 * scale),
        (cx + 35 * scale, cy - 40 * scale),
        (cx + 45 * scale, cy + 10 * scale),
        (cx + 30 * scale, cy + 60 * scale),
        (cx, cy + 80 * scale),
        (cx - 30 * scale, cy + 60 * scale),
        (cx - 45 * scale, cy + 10 * scale),
        (cx - 35 * scale, cy - 40 * scale),
    ]
    inner_color = (255, 200, 100)  # naranja claro
    draw.polygon(flame_inner, fill=inner_color)
    
    # Núcleo de la llama (amarillo)
    flame_core = [
        (cx, cy - 40 * scale),
        (cx + 18 * scale, cy - 10 * scale),
        (cx + 20 * scale, cy + 30 * scale),
        (cx, cy + 45 * scale),
        (cx - 20 * scale, cy + 30 * scale),
        (cx - 18 * scale, cy - 10 * scale),
    ]
    core_color = (255, 230, 150)
    draw.polygon(flame_core, fill=core_color)

def create_icon(size, maskable=False):
    """Crea un icono PWA."""
    if maskable:
        # Maskable: fondo completo + safe zone (80% del centro)
        img = create_gradient_background(size, COLOR_PRIMARY, COLOR_SECONDARY)
        draw = ImageDraw.Draw(img)
        # La llama va en el 80% central (safe zone)
        flame_size = int(size * 0.8)
        # Recortar el dibujo de la llama al safe zone
        flame_img = Image.new('RGBA', (flame_size, flame_size), (0, 0, 0, 0))
        flame_draw = ImageDraw.Draw(flame_img)
        draw_flame(flame_draw, flame_size)
        # Pegar centrado
        offset = (size - flame_size) // 2
        img.paste(flame_img, (offset, offset), flame_img)
    else:
        # Icon normal: fondo con gradiente + llama
        img = create_gradient_background(size, COLOR_PRIMARY, COLOR_SECONDARY)
        draw = ImageDraw.Draw(img)
        draw_flame(draw, size)
    
    return img

def create_apple_touch_icon(size=180):
    """Crea apple-touch-icon (fondo sólido + llama)."""
    img = Image.new('RGB', (size, size), COLOR_PRIMARY)
    draw = ImageDraw.Draw(img)
    draw_flame(draw, size)
    return img

def create_favicon(size=32):
    """Crea favicon."""
    img = create_gradient_background(size, COLOR_PRIMARY, COLOR_SECONDARY)
    draw = ImageDraw.Draw(img)
    draw_flame(draw, size)
    return img

# Generar todos los iconos
icons_to_generate = [
    ("icon-192.png", 192, False),
    ("icon-512.png", 512, False),
    ("icon-512-maskable.png", 512, True),
    ("icon-384.png", 384, False),
    ("icon-256.png", 256, False),
    ("icon-180.png", 180, False),  # Apple touch icon size
    ("icon-32.png", 32, False),    # Favicon
]

print("Generando iconos PWA para Fusión y Fogón...")

for name, size, maskable in icons_to_generate:
    img = create_icon(size, maskable)
    path = os.path.join(OUTPUT_DIR, name)
    img.save(path, "PNG", optimize=True)
    print(f"  ✅ {name} ({size}x{size})")

# Apple touch icon específico
apple_icon = create_apple_touch_icon(180)
apple_icon.save(os.path.join(OUTPUT_DIR, "apple-touch-icon.png"), "PNG", optimize=True)
print(f"  ✅ apple-touch-icon.png (180x180)")

# Favicon
favicon = create_favicon(32)
favicon.save(os.path.join(OUTPUT_DIR, "favicon-32.png"), "PNG", optimize=True)
print(f"  ✅ favicon-32.png (32x32)")

# Favicon ICO (multi-size)
favicon_16 = create_favicon(16)
favicon_32 = create_favicon(32)
favicon_48 = create_favicon(48)
favicon_16.save(os.path.join(OUTPUT_DIR, "favicon.ico"), format='ICO', sizes=[(16,16),(32,32),(48,48)])
print(f"  ✅ favicon.ico (multi-size)")

print(f"\n🎉 {len(icons_to_generate) + 3} iconos generados en {OUTPUT_DIR}")
print("\nEstos iconos hacen que la PWA sea instalable en:")
print("  - Android Chrome (icon-192, icon-512)")
print("  - Android con maskable icons (icon-512-maskable)")
print("  - iOS Safari (apple-touch-icon, icon-180)")
print("  - Desktop Chrome/Edge (icon-192, icon-512)")
print("  - Browser tab (favicon)")
